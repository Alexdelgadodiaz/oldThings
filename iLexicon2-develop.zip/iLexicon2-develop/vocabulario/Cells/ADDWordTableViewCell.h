//
//  ADDWordTableViewCell.h
//  vocabulario
//
//  Created by Alejandro Delgado Diaz on 9/5/15.
//  Copyright (c) 2015 alejandro. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ADDWordTableViewCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UITextView *word1;
@property (weak, nonatomic) IBOutlet UITextView *word2;


@end
