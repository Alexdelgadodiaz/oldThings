//
//  ADDAddWordViewController.h
//  vocabulario
//
//  Created by Alejandro Delgado Diaz on 4/5/15.
//  Copyright (c) 2015 alejandro. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ADDUtils.h"


@interface ADDAddWordViewController : UIViewController

@property (nonatomic, assign) ADDObjectToAdd objectToAdd;

@end
