# iLexicon2
New version of my app to learn vocabulary based in previous version. 
