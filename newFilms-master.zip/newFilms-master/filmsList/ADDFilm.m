//
//  ADDFilm.m
//  filmsList
//
//  Created by Alejandro Delgado Diaz on 25/2/15.
//  Copyright (c) 2015 AlejandroDD. All rights reserved.
//

#import "ADDFilm.h"

@implementation ADDFilm

- (instancetype) initWithTitle:(NSString *)title andMark:(NSString *)mark andImgURL:(NSURL *)url
{
    if (self = [super init]) {
        _title = title;
        _mark = mark;
        _imgURL = url;
    }
    
    return self;
}

- (NSComparisonResult)compare:(ADDFilm *)other
{
    return [[NSNumber numberWithFloat:other.mark.floatValue] compare:[NSNumber numberWithFloat:self.mark.floatValue]];
}


@end
