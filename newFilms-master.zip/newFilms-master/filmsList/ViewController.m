//
//  ViewController.m
//  filmsList
//
//  Created by Alejandro Delgado Diaz on 25/2/15.
//  Copyright (c) 2015 AlejandroDD. All rights reserved.
//

#import "ViewController.h"
#import "TFHpple.h"
#import "ADDFilm.h"

typedef NS_ENUM(NSInteger, parserState)
{
    inTitle,
    inDescription,
    inMark,
};

@interface ViewController () <NSXMLParserDelegate, UITableViewDataSource, UITableViewDelegate>

@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (nonatomic, strong) ADDFilm *curentFilm;
@property (nonatomic, strong) NSMutableArray *filmArray;
@property (nonatomic, strong) NSArray *filmOrdenedArray;
@property (nonatomic) BOOL inElement;
@property (nonatomic) parserState parseState;

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];

    self.filmArray = [NSMutableArray new];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    
    [self downloadDataFromFandango];
}

#pragma mark - Utils

- (NSURL *) searchForAnImageInString:(NSString *)string
{
    NSString *param = nil;
    NSRange start = [string rangeOfString:@"<img src="];
    if (start.location != NSNotFound)
    {
        param = [string substringFromIndex:start.location + start.length];
        NSRange end = [param rangeOfString:@"alt="];
        if (end.location != NSNotFound)
        {
            param = [param substringToIndex:end.location];
        }
    }
    
    NSString *newStr = [param substringWithRange:NSMakeRange(1, [param length]-3)];
    return [NSURL URLWithString:newStr];
}

- (void)downloadDataFromFandango
{
    dispatch_queue_t download = dispatch_queue_create("films", 0);
    
    __block NSData *data = nil;
    
    dispatch_async(download, ^{
        
        data = [NSData dataWithContentsOfURL:[NSURL URLWithString:@"http://www.fandango.com/rss/newmovies.rss"]];
        
        dispatch_async(dispatch_get_main_queue(), ^{
            NSXMLParser *parser = [[NSXMLParser alloc]initWithData:data];
            parser.delegate = self;
            [parser parse];
            
        });
    });
}

- (void)orderArrayToShow
{
    self.filmOrdenedArray = [self.filmArray sortedArrayUsingComparator:^NSComparisonResult(id obj1, id obj2) {
        return [(ADDFilm*)obj1 compare:(ADDFilm*)obj2];
    }];
}

#pragma mark - Lazy init

-(ADDFilm *)curentFilm
{
    if (!_curentFilm) {
        _curentFilm = [[ADDFilm alloc]init];
    }
    
    return _curentFilm;
}

#pragma mark - TableView Delegate Methods

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [self.filmOrdenedArray count];
}


- (UITableViewCell *)tableView:(UITableView *)tableView
         cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *MyIdentifier = @"filmCell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:MyIdentifier];
    
    if (cell == nil)
    {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault
                                      reuseIdentifier:MyIdentifier] ;
    }
    
    dispatch_queue_t download = dispatch_queue_create("photos", 0);
    
    __block UIImage *img = nil;
    
    dispatch_async(download, ^{
        
        NSData *data = [NSData dataWithContentsOfURL:((ADDFilm *)self.filmOrdenedArray[indexPath.row]).imgURL];
        img = [UIImage imageWithData:data];

        
        dispatch_async(dispatch_get_main_queue(), ^{
            cell.imageView.image = img;
            [self.tableView reloadData];
        });
    });
    
    cell.textLabel.text = ((ADDFilm *)self.filmOrdenedArray[indexPath.row]).title;
    
    return cell;
}

#pragma mark - NSXMLParser Delegate Methods

- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName attributes:(NSDictionary *)attributeDict
{
    if ([elementName isEqualToString:@"item"]) {
        self.inElement = YES;
    }
    
    if (self.inElement) {
        if ([elementName isEqualToString:@"title"]) {
            self.parseState = inTitle;
        }else if ([elementName isEqualToString:@"fan:fanRating"]){
            self.parseState = inMark;
        }else if ([elementName isEqualToString:@"description"]){
            self.parseState = inDescription;
        }else{
            self.parseState = -1;
        }
    }
}

-(void) parser:(NSXMLParser *)parser foundCharacters:(NSString *)string
{
    
    if (self.inElement) {
        switch (self.parseState) {
            case inTitle:
                self.curentFilm.title = string;
                break;
            case inMark:
                self.curentFilm.mark = string;
                break;
            case inDescription:
                self.curentFilm.imgURL = [self searchForAnImageInString:string];
                break;
                
            default:
                break;
        }
    }
}

- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName
{
    if ([elementName isEqualToString:@"item"]) {
        self.inElement = NO;
        [self.filmArray addObject:self.curentFilm];
        self.curentFilm = nil;
    }
}

- (void) parserDidEndDocument:(NSXMLParser *)parser
{
    [self orderArrayToShow];
    [self.tableView reloadData];
}

@end
