//
//  ADDSearchViewController.m
//  Books
//
//  Created by Alejandro Delgado Diaz on 21/5/15.
//  Copyright (c) 2015 alejandro. All rights reserved.
//

#import "ADDSearchViewController.h"
#import "ADDBookListViewController.h"
#import "ADDBookListRequest.h"
#import "ADDBook.h"

#import "MBProgressHUD.h"

@interface ADDSearchViewController ()

@property (weak, nonatomic) IBOutlet UIButton *searchButton;
@property (weak, nonatomic) IBOutlet UITextField *searchTextField;

@end

@implementation ADDSearchViewController



- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.title = @"Books";
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma Mark - Private Methods

- (IBAction)didPressSearchButton:(id)sender {
    
    if (!self.searchTextField.text.length) {
      
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Search something"
                                                        message:@"Nothing was in the text field"
                                                       delegate:self
                                              cancelButtonTitle:@"OK"
                                              otherButtonTitles:nil];
        [alert show];
        
    }else{
        
        MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
        hud.labelText = @"Loading";
        
        [[ADDBookListRequest client]bookListRequestWithTitleBook:self.searchTextField.text andhandler:^(NSArray *contentItems) {
            
            dispatch_async(dispatch_get_main_queue(), ^{
                
                UIImageView *imageView;
                UIImage *image = [UIImage imageNamed:@"37x-Checkmark.png"];
                imageView = [[UIImageView alloc] initWithImage:image];
                hud.customView = imageView ;
                hud.mode = MBProgressHUDModeCustomView;
                [hud hide:YES afterDelay:0.7];
                
                [self performSelector:@selector(pushToBookList:) withObject:contentItems afterDelay:0.8f];
                
            });
        }];
    }
}

- (void)pushToBookList:(NSArray *)bookList{
    
    ADDBookListViewController *bookListVC = [ADDBookListViewController new];
    bookListVC.booksArray = bookList;
    bookListVC.title = self.searchTextField.text;
    
    [self.navigationController pushViewController:bookListVC animated:YES];
}

@end
