//
//  ADDBookDetailsViewController.m
//  Books
//
//  Created by Alejandro Delgado Diaz on 25/5/15.
//  Copyright (c) 2015 alejandro. All rights reserved.
//

#import "ADDBookDetailsViewController.h"

@interface ADDBookDetailsViewController ()

@end

@implementation ADDBookDetailsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


#pragma mark - Table View Data Source

// Return the number of sections
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 5;
}

// Return the number of rows for each section in your static table
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 1;
}

// Return the row for the corresponding section and row
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    if (cell == nil)
    {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier];
    }
    
    switch(indexPath.section)
    {
        case 0:{
            cell.textLabel.text = self.book.bookTitle;
            return cell;
            
        }
            
        case 1:{
            
            NSString *bookAutorsString = @"";
            for (NSDictionary *bookAutor in self.book.bookAutor) {
                
                NSInteger index = [self.book.bookAutor indexOfObject:bookAutor];
                
                if (index == 0) {
                    bookAutorsString = [bookAutorsString stringByAppendingString:[NSString stringWithFormat:@"%@", bookAutor[@"name"]]];
                }else{
                    bookAutorsString = [bookAutorsString stringByAppendingString:[NSString stringWithFormat:@" & %@", bookAutor[@"name"]]];
                    
                }
            }
            cell.textLabel.text = bookAutorsString;
            return cell;
            
        }
            
        case 2:{
            NSString *bookSubjectString = @"";
            for (NSString *bookSubject in self.book.bookSubject) {
                
                bookSubjectString = [bookSubjectString stringByAppendingString:bookSubject];
                
            }
            
            cell.textLabel.text = bookSubjectString;
            return cell;
            
        }
        case 3:{
            cell.textLabel.text = self.book.bookIsbn13;
            return cell;
            
        }
        case 4:{
            cell.textLabel.text = self.book.bookPublisher;
            return cell;
        }
    }
    return nil;
}


#pragma mark - Table View Delegate

// Customize the section headings for each section
- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
    switch(section)
    {
        case 0: return @"Title";
        case 1: return @"Autor(s)";
        case 2: return @"Subject";
        case 3: return @"Book´s ISBN13";
        case 4: return @"Publisher";
    }
    
    return nil;
}

@end
