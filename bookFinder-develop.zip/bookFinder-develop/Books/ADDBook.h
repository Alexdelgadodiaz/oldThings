//
//  ADDBook.h
//  Books
//
//  Created by Alejandro Delgado Diaz on 21/5/15.
//  Copyright (c) 2015 alejandro. All rights reserved.
//

#import "MTLModel.h"
#import "MTLJSONAdapter.h"

@interface ADDBook : MTLModel <MTLJSONSerializing>

@property (nonatomic, readonly, strong) NSString *bookTitle; //ok
@property (nonatomic, readonly, strong) NSString *bookTitleLong;
@property (nonatomic, readonly, strong) NSArray *bookAutor; //ok
@property (nonatomic, readonly, strong) NSString *bookIsbn13; //ok
@property (nonatomic, readonly, strong) NSString *bookPublisher; //ok
@property (nonatomic, readonly, strong) NSArray *bookSubject; //ok


@end
