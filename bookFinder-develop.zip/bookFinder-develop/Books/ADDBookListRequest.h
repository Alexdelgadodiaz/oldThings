//
//  ADDBookListRequest.h
//  Books
//
//  Created by Alejandro Delgado Diaz on 21/5/15.
//  Copyright (c) 2015 alejandro. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ADDBookListRequest : NSObject

+ (instancetype)client;

- (void) bookListRequestWithTitleBook:(NSString *)titleBook
                           andhandler:(void (^)(NSArray *contentItems))handler;

@end
