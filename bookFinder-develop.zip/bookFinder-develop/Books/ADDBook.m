//
//  ADDBook.m
//  Books
//
//  Created by Alejandro Delgado Diaz on 21/5/15.
//  Copyright (c) 2015 alejandro. All rights reserved.
//

#import "ADDBook.h"

@implementation ADDBook

+(NSDictionary *)JSONKeyPathsByPropertyKey
{
    return @{
             @"bookTitle" : @"title",
             @"bookTitleLong" : @"title_long",
             @"bookAutor" : @"author_data",
             @"bookIsbn13" : @"isbn13",
             @"bookPublisher" : @"publisher_text",
             @"bookSubject" : @"subject_ids"
             };
}


@end
