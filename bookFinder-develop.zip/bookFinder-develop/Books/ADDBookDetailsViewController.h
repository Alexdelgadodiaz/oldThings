//
//  ADDBookDetailsViewController.h
//  Books
//
//  Created by Alejandro Delgado Diaz on 25/5/15.
//  Copyright (c) 2015 alejandro. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "ADDBook.h"

@interface ADDBookDetailsViewController : UIViewController

@property (nonatomic, strong) ADDBook *book;

@end
