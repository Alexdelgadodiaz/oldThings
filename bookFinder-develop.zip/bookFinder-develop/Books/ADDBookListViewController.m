//
//  ADDBookListViewController.m
//  Books
//
//  Created by Alejandro Delgado Diaz on 22/5/15.
//  Copyright (c) 2015 alejandro. All rights reserved.
//

#import "ADDBookListViewController.h"
#import "ADDBookDetailsViewController.h"
#import "ADDBook.h"

@interface ADDBookListViewController ()

@property (weak, nonatomic) IBOutlet UITableView *bookTableView;

@end

@implementation ADDBookListViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


#pragma mark - TableView Delegates

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{

    return [self.booksArray count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    if (cell == nil)
    {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier];
    }
    
    cell.textLabel.text =  ((ADDBook *)self.booksArray[indexPath.row]).bookTitle;
    NSArray *bookAutors = ((ADDBook *)self.booksArray[indexPath.row]).bookAutor;
    
    NSString *bookAutorsString = @"";
    for (NSDictionary *bookAutor in bookAutors) {
        
        NSInteger index = [bookAutors indexOfObject:bookAutor];

        if (index == 0) {
            bookAutorsString = [bookAutorsString stringByAppendingString:[NSString stringWithFormat:@"%@", bookAutor[@"name"]]];
        }else{
            bookAutorsString = [bookAutorsString stringByAppendingString:[NSString stringWithFormat:@" & %@", bookAutor[@"name"]]];
        }
    }
    
    cell.detailTextLabel.text = bookAutorsString;
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    ADDBookDetailsViewController *bookDetailsVC = [ADDBookDetailsViewController new];
    bookDetailsVC.book = self.booksArray[indexPath.row];
    bookDetailsVC.title = @"Details";
    
    [self.navigationController pushViewController:bookDetailsVC animated:YES];

}

@end
