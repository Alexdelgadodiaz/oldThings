//
//  ADDBookListViewController.h
//  Books
//
//  Created by Alejandro Delgado Diaz on 22/5/15.
//  Copyright (c) 2015 alejandro. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ADDBookListViewController : UIViewController

@property (nonatomic, strong) NSArray *booksArray;

@end
