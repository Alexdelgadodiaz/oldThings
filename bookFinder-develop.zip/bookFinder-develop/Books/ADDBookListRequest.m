//
//  ADDBookListRequest.m
//  Books
//
//  Created by Alejandro Delgado Diaz on 21/5/15.
//  Copyright (c) 2015 alejandro. All rights reserved.
//

#import "ADDBookListRequest.h"

#import <AFNetworking/AFNetworking.h>
#import <BlocksKit/BlocksKit.h>

#import "ADDBook.h"


@implementation ADDBookListRequest

+ (instancetype)client {
    return [ADDBookListRequest new];
}

- (void) bookListRequestWithTitleBook:(NSString *)titleBook
                           andhandler:(void (^)(NSArray *contentItems))handler{
    
    //http://isbndb.com/api/v2/json/U3W26R0N/books?q=legiones%20malditas
    
    NSURL *url = [NSURL URLWithString:@"http://isbndb.com/api/v2/json/U3W26R0N/books"];
    NSDictionary *parameters = @{@"q" : titleBook};
    
    
    [self getRequest:url
          parameters:parameters
             handler:handler];

}

- (void)getRequest:(NSURL *)URL
        parameters:(NSDictionary *)params
           handler:(void (^)(NSArray *))handler {
    
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    manager.responseSerializer.acceptableContentTypes = nil;

    
    [manager GET:URL.absoluteString parameters:params
         success:^(AFHTTPRequestOperation *operation, NSDictionary *items) {
             
             NSArray *array = items[@"data"];
             
             NSArray *booksArray = [array bk_map:^id(NSDictionary *item) {
                 
                 NSError *error = nil;
                 id books = [MTLJSONAdapter modelOfClass:[ADDBook class] fromJSONDictionary:item error:&error] ?: [NSNull null];
                 
                 if (error) {
                     NSLog(@"Failed to Parse ADDBooks: %@", error);
                 }
                 
                 return books;
             }];
             
             booksArray = [booksArray bk_reject:^BOOL(id obj) {
                 return [obj isKindOfClass:[NSNull class]];
             }];
             
             handler(booksArray);
         }
         failure:^(AFHTTPRequestOperation *operation, NSError *error) {
             NSLog(@"Failed to Call Content API: %@", error);
             handler(@[]);
         }];
}

@end
