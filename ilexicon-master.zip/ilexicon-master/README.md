ilexicon
========

Vocabulary notebook with SQLite, really simple app with 1000 downloads at AppStore, for iOS 5
