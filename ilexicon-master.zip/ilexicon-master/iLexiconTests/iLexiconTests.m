//
//  iLexiconTests.m
//  iLexiconTests
//
//  Created by Alejandro Delgado Diaz on 03/06/13.
//  Copyright (c) 2013 Alejandro. All rights reserved.
//

#import "iLexiconTests.h"

@implementation iLexiconTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in iLexiconTests");
}

@end
