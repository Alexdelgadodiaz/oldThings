//
//  iLexiconTests.h
//  iLexiconTests
//
//  Created by Alejandro Delgado Diaz on 03/06/13.
//  Copyright (c) 2013 Alejandro. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface iLexiconTests : SenTestCase

@end
