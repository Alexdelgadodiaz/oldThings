//
//  ViewController.h
//  Vocabulario
//
//  Created by Alejandro Delgado Diaz on 28/03/13.
//  Copyright (c) 2013 Alejandro. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "lenguaDAO.h"

@interface HomeViewController : UIViewController <UITableViewDelegate, UITableViewDataSource, UIGestureRecognizerDelegate, UITextViewDelegate> {
    lenguaDAO *dao;
    NSMutableArray *arrayLenguas;
    
}
@property (nonatomic, strong) lenguaDAO *dao;
@property (nonatomic, strong) NSMutableArray *arrayLenguas;
@property (nonatomic, retain) UITableView *tableViewLengua;
@property (nonatomic, strong) UIView *menuMoveView;

@property (nonatomic, retain) UIView *AddView;
@property (nonatomic, retain) UIScrollView *scrollOfAddMenu;
@property (nonatomic, retain) UIView *menuAddView;
@property (nonatomic, retain) UITextField *nombreLanguageNew;
@property (nonatomic, retain) UITextField *nombreLanguageMaster;
@property (nonatomic, retain) UITextView *addText;

@property (nonatomic, retain) UIView *InfoView;
@property (nonatomic, retain) UIScrollView *scrollOfInfoMenu;
@property (nonatomic, retain) UIView *menuInfoView;
@property (nonatomic, retain) UITextField *nombreLanguage;
@property (nonatomic, retain) UITextField *nombreMaster;
@property (nonatomic, retain) UITextView *infoText;
@property (nonatomic, readwrite) NSInteger languageID;
@property (nonatomic, retain) UILongPressGestureRecognizer *gestureInfoMenu;

@property (nonatomic, retain) UIView *searchView;
@property (nonatomic, retain) UITextField *searchBar;
@property (nonatomic, retain) UITableView *tableViewSearch;

@property (nonatomic, retain) NSMutableDictionary *dictionaryWords;
@property (nonatomic, retain) NSMutableDictionary *dictionaryWordsSupporter;

@property (nonatomic, retain) UIView *InfoViewWords;
@property (nonatomic, retain) UIScrollView *scrollOfInfoMenuWords;
@property (nonatomic, retain) UIView *menuInfoViewWords;
@property (nonatomic, retain) UILabel *idiomaMaster1;
@property (nonatomic, retain) UILabel *idiomaLearn1;
@property (nonatomic, retain) UITextField *infoWord1;
@property (nonatomic, retain) UITextField *infoWord2;
@property (nonatomic, retain) UITextView *infoTextWords;

@property (nonatomic, readwrite) NSInteger wordID;



@property (nonatomic, readwrite) BOOL menuFlag;
@property (nonatomic, readwrite) BOOL menuFlagSearch;
@property (nonatomic, readwrite) BOOL menuFlagInfo;
@property (nonatomic, readwrite) BOOL menuFlagAlpha;


@end
