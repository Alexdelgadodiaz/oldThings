//
//  wordDAO.h
//  Vocabulario
//
//  Created by Alejandro Delgado Diaz on 31/03/13.
//  Copyright (c) 2013 Alejandro. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <sqlite3.h>

@interface wordDAO : NSObject{
    sqlite3 *dataBase;
    
    //NSString *languageLista;
    //NSString *listaWords;
    
}

- (NSString *) getPathDataBase;
- (NSMutableArray *) getListOfWords: (NSInteger)listOriginId;
- (void) addWord:(NSString *)word1 word2:(NSString *)word2 lengua:(NSString *)lengua lista:(NSString *)lista comments:(NSString *)comments listOriginId:(NSInteger)listOriginId languageMaster:(NSString *)languageMaster languageID:(NSInteger)languageID;
- (void) modWord:(NSString *)word1 word2:(NSString *)word2 lengua:(NSString *)lengua lista:(NSString *)lista comments:(NSString *)comments wordID:(NSInteger)wordID;
- (void) deleteWord:(NSInteger) wordID;



//@property (nonatomic, retain) NSString *languageLista;
//@property (nonatomic, retain) NSString *listaWords;



@end