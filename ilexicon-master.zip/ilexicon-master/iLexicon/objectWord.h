//
//  objectWord.h
//  Vocabulario
//
//  Created by Alejandro Delgado Diaz on 31/03/13.
//  Copyright (c) 2013 Alejandro. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface objectWord : NSObject{
    NSString *word1;
    NSString *word2;
    NSString *languageOrigin;
    NSString *languageMaster;
    NSString *comments;
    NSInteger wordId;
    NSInteger listOriginId;
    
}

@property (nonatomic, retain) NSString *word1;
@property (nonatomic, retain) NSString *word2;
@property (nonatomic, retain) NSString *languageOrigin;
@property (nonatomic, retain) NSString *languageMaster;
@property (nonatomic, retain) NSString *comments;
@property (nonatomic, readwrite) NSInteger wordId;
@property (nonatomic, readwrite) NSInteger listOriginId;

@end