//
//  WordsViewController.h
//  Vocabulario
//
//  Created by Alejandro Delgado Diaz on 31/03/13.
//  Copyright (c) 2013 Alejandro. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "wordDAO.h"

@interface WordsViewController : UIViewController <UITableViewDelegate, UITableViewDataSource, UITextViewDelegate> {
    wordDAO *dao;
    NSMutableArray *arrayWords;
    NSMutableArray *arrayWordsSupporter;
    
    NSString *lenguaLista;
    NSString *lenguaMaster;
    NSString *lista;
    NSInteger listaOriginId;
    NSInteger languageID;
}

@property (nonatomic, retain) wordDAO *dao;
@property (nonatomic, retain) NSMutableArray *arrayWords;
@property (nonatomic, retain) NSMutableArray *arrayWordsSupporter;
@property (nonatomic, retain) UITableView *tableViewWords;
@property (nonatomic, retain) UITableView *tableViewSearch;

@property (nonatomic, retain) NSString *lenguaLista;
@property (nonatomic, retain) NSString *lenguaMaster;
@property (nonatomic, retain) NSString *lista;
@property (nonatomic, readwrite) NSInteger listaOriginId;
@property (nonatomic, readwrite) NSInteger languageID;

@property (nonatomic, retain) UIView *menuInfoView;
@property (nonatomic, retain) UIView *menuAddView;

@property (nonatomic, retain)  UIView *AddView;
@property (nonatomic, retain)  UIView *InfoView;
@property (nonatomic, retain) UIView *searchView;
@property (nonatomic, readwrite) BOOL menuFlag;
@property (nonatomic, readwrite) BOOL menuFlagSearch;

@property (nonatomic, retain) UITextField *aNewWord1;
@property (nonatomic, retain) UITextField *aNewWord2;

@property (nonatomic, retain) UITextField *infoWord1;
@property (nonatomic, retain) UITextField *infoWord2;
@property (nonatomic, retain) UITextView *infoText;
@property (nonatomic, retain) UITextView *addText;
@property (nonatomic, readwrite) NSInteger wordID;

@property (nonatomic, retain) UIScrollView *scrollOfAddMenu;
@property (nonatomic, retain) UIScrollView *scrollOfInfoMenu;

@property (nonatomic, retain) UITextField *searchBar;



@end