//
//  ListasViewController.m
//  Vocabulario
//
//  Created by Alejandro Delgado Diaz on 30/03/13.
//  Copyright (c) 2013 Alejandro. All rights reserved.
//

#import "ListasViewController.h"
#import "listDAO.h"
#import "WordsViewController.h"


@interface ListasViewController ()

@end

@implementation ListasViewController

@synthesize arrayListas;
@synthesize dictionaryList, dictionaryWords, dictionaryWordsSupporter;
@synthesize dao;
@synthesize tableViewLista;
@synthesize lenguaLista, lenguaMaster;
@synthesize languageID;
@synthesize AddView;
@synthesize menuAddView;
@synthesize menuFlag, menuFlagSearch, menuFlagInfo, menuFlagAlpha;
@synthesize scrollOfAddMenu;
@synthesize nombreListaNueva, addText;
@synthesize searchView, searchBar, tableViewSearch;
@synthesize InfoView, scrollOfInfoMenu, infoText, nombreLista, menuInfoView, listID;
@synthesize gestureInfoMenu;
@synthesize InfoViewWords, scrollOfInfoMenuWords, menuInfoViewWords, infoWord1, infoWord2, infoTextWords;
@synthesize wordID;
@synthesize idiomaLearn1, idiomaMaster1;



- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

-(void)back {
    
    [self.navigationController popViewControllerAnimated:YES];
}


- (void)viewDidLoad
{
    
    UIImage *buttonImage = [UIImage imageNamed:@"back2.png"];
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button setImage:buttonImage forState:UIControlStateNormal];
    button.frame = CGRectMake(0, 0, 65, 38);
    [button addTarget:self action:@selector(back) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *customBarItem = [[UIBarButtonItem alloc] initWithCustomView:button];
    self.navigationItem.leftBarButtonItem = customBarItem;
    
    
   // NSLog(@"Lenguage i wanna learn, %@", lenguaLista);
    
    [self setTitleNav:lenguaLista];

    dao = [[listDAO alloc]init];
    arrayListas = [[NSMutableArray alloc]init];
    dictionaryWords = [[NSMutableDictionary alloc]init];
    dictionaryList = [[NSMutableDictionary alloc]init];
    
    
    menuFlag=TRUE; //Checking openned menus
    menuFlagSearch=TRUE; //if the menu search is onside
    menuFlagInfo=FALSE; //menu for information of the word
    

    [super viewDidLoad];
    
    UITapGestureRecognizer *gestureRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(hideKeyboard)];
    gestureRecognizer.cancelsTouchesInView = NO;
    gestureRecognizer.numberOfTouchesRequired=1;
    [self.view addGestureRecognizer:gestureRecognizer];
    
    
    //button for saving up-left
    UIImage *buttonAddImage = [UIImage imageNamed:@"addAlexVocabularioGris.png"];
    //create the button and assign the image
    UIButton *buttonAdd = [UIButton buttonWithType:UIButtonTypeCustom];
    [buttonAdd setImage:buttonAddImage forState:UIControlStateNormal];
    [buttonAdd addTarget:self action:@selector(openMenuAdd:) forControlEvents:UIControlEventTouchUpInside];
    //sets the frame of the button to the size of the image
    buttonAdd.frame = CGRectMake(0, 0, 20, 20);
    //creates a UIBarButtonItem with the button as a custom view
    UIBarButtonItem *addLanguageButton = [[UIBarButtonItem alloc] initWithCustomView:buttonAdd];
    
    self.navigationItem.rightBarButtonItem=addLanguageButton;
    
    
    /*---------------------------------------------------------------------------
     * toolbar items
     *--------------------------------------------------------------------------*/
    
    UIImage *buttonSearchImage = [UIImage imageNamed:@"searchAlexVocabularioGris.png"];
    //create the button and assign the image
    UIButton *buttonSearch = [UIButton buttonWithType:UIButtonTypeCustom];
    [buttonSearch setImage:buttonSearchImage forState:UIControlStateNormal];
    [buttonSearch addTarget:self action:@selector(openMenuSearch:) forControlEvents:UIControlEventTouchUpInside];
    //sets the frame of the button to the size of the image
    buttonSearch.frame = CGRectMake(0, 0, 22, 22);
    //creates a UIBarButtonItem with the button as a custom view
    UIBarButtonItem *searchButton = [[UIBarButtonItem alloc] initWithCustomView:buttonSearch];
    
    
    UIButton *buttonEdit = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    [buttonEdit setTitle:@"Edit" forState:UIControlStateNormal];
    [buttonEdit setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
    [buttonEdit setTintColor:[UIColor darkGrayColor]];
    buttonEdit.titleLabel.font= [UIFont fontWithName:@"GillSans" size:16.0];
    
    [buttonEdit addTarget:self action:@selector(editingCell) forControlEvents:UIControlEventTouchUpInside];
    CGRect buttonEditFrame= CGRectMake(0, 0, 50, 34);
    [buttonEdit setFrame:buttonEditFrame];
    
    //UIBarButtonItem *editCell = [[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemEdit target:self action:@selector(editingCell)];
    
    UIBarButtonItem *editCell = [[UIBarButtonItem alloc] initWithCustomView:buttonEdit];
    
    
    UIBarButtonItem *flexibaleSpaceBarButton = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
    
    self.toolbarItems = [NSArray arrayWithObjects:searchButton, flexibaleSpaceBarButton,editCell, nil];
    
    
    tableViewLista=[[UITableView alloc] initWithFrame:(CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height-88)) style:UITableViewStylePlain];
    tableViewLista.delegate=self;
    tableViewLista.dataSource = self;
    tableViewLista.rowHeight = 60;
    tableViewLista.bounces=YES;
    //tableView.backgroundColor=[UIColor colorWithCGColor:whiteColorApp];
    tableViewLista.clipsToBounds=YES;
    tableViewLista.scrollsToTop=NO;
    // [tableView setSectionIndexColor:[UIColor redColor]];
   // [self.view addSubview:tableViewLista];
    
    /*---------------------------------------------------------------------------
     * add View
     *--------------------------------------------------------------------------*/
    
    AddView=[[UIView alloc]init];
    AddView.frame=CGRectMake(-self.view.frame.size.width, 0, self.view.frame.size.width, self.view.frame.size.height);
    AddView.backgroundColor=[UIColor whiteColor];
    
    scrollOfAddMenu = [[UIScrollView alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height)];
    scrollOfAddMenu.contentSize= CGSizeMake(self.view.frame.size.width, self.view.frame.size.height-44);
    scrollOfAddMenu.backgroundColor = [UIColor whiteColor];
    //self.scrollView.contentInset = UIEdgeInsetsMake(vOffset, hOffset, 0, 0);
    scrollOfAddMenu.showsVerticalScrollIndicator = YES;    // to hide scroll indicators!
    scrollOfAddMenu.scrollEnabled = YES;
    //textField.delegate = self;              //use this when ur using Delegate methods of UITextField
    [AddView addSubview:scrollOfAddMenu];
    
    menuAddView=[[UIView alloc]init];
    menuAddView.frame=CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height-44);
    menuAddView.backgroundColor=[UIColor whiteColor];
    
    [scrollOfAddMenu addSubview:menuAddView];
    
    
    
    
    nombreListaNueva=[[UITextField alloc]initWithFrame:CGRectMake(10, 20, self.view.frame.size.width-20, 38)];
    nombreListaNueva.placeholder = @"New list";
    [nombreListaNueva setValue:[UIColor lightTextColor] forKeyPath:@"_placeholderLabel.textColor"];
    nombreListaNueva.font = [UIFont fontWithName:@"GillSans" size:25.0]; // text font
    nombreListaNueva.adjustsFontSizeToFitWidth = YES;     //adjust the font size to fit width.
    nombreListaNueva.borderStyle= UITextBorderStyleRoundedRect;
    nombreListaNueva.backgroundColor=[UIColor darkGrayColor];
    nombreListaNueva.textColor = [UIColor whiteColor];             //text color
    nombreListaNueva.textAlignment=NSTextAlignmentLeft;
    nombreListaNueva.clearButtonMode = UITextFieldViewModeAlways;//for clear button on right side
    
    [menuAddView addSubview:nombreListaNueva];

    UILabel *explicacionLanguageNew= [[UILabel alloc]initWithFrame:CGRectMake(15, 50, self.view.frame.size.width-30, 30)];
    explicacionLanguageNew.text=@"*Put here the title of the new list you want to learn";
    explicacionLanguageNew.font=[UIFont fontWithName:@"GillSans" size:13.0];
    explicacionLanguageNew.textColor= [UIColor grayColor];
    explicacionLanguageNew.backgroundColor= [UIColor clearColor];
    explicacionLanguageNew.textAlignment=NSTextAlignmentLeft;
    
    [menuAddView addSubview:explicacionLanguageNew];
    
    /*
    UILabel *tituloAddWords = [[UILabel alloc]init];
    tituloAddWords.text=@"New list";
    tituloAddWords.backgroundColor=[UIColor clearColor];
    tituloAddWords.frame=CGRectMake(5, 9, 100, 24);
    [menuAddView addSubview:tituloAddWords];
     
    
    UILabel *idiomaLearn = [[UILabel alloc]init];
    idiomaLearn.text=@"Name lista";
    idiomaLearn.backgroundColor=[UIColor clearColor];
    idiomaLearn.frame=CGRectMake(5, 40, 350, 24);
    [menuAddView addSubview:idiomaLearn];
    */

    

    
    addText=[[UITextView alloc]initWithFrame:CGRectMake(30, 250, self.view.frame.size.width-60, self.view.frame.size.height-320)];
    //text.frame=CGRectMake(0, 42, self.view.frame.size.width, self.view.frame.size.height-48);
    //  originalTextViewFrame=CGRectMake(3, 55, self.view.frame.size.width-6, self.view.frame.size.height-100);
    //text.backgroundColor= [UIColor colorWithCGColor:];
    addText.font=[UIFont fontWithName:@"GillSans" size:18.0];
    addText.textColor=[UIColor whiteColor];
    addText.backgroundColor=[UIColor darkGrayColor];
    addText.clipsToBounds = YES;
    addText.scrollsToTop=YES;
    addText.bounces=NO;
    addText.delegate=self;
    [menuAddView addSubview:addText];
    
    /*---------------------------------------------------------------------------
     * Search View
     *--------------------------------------------------------------------------*/
    
    searchView=[[UIView alloc]init];
    searchView.frame=CGRectMake(0, self.view.frame.size.height, self.view.frame.size.width, self.view.frame.size.height);
    searchView.backgroundColor=[UIColor whiteColor];
    
    searchBar = [[UITextField alloc] initWithFrame:CGRectMake(2, 2, self.view.frame.size.width-4, 32)];
    searchBar.placeholder = @"Search...";   //for place holder
    [searchBar setValue:[UIColor whiteColor] forKeyPath:@"_placeholderLabel.textColor"];
    searchBar.font = [UIFont fontWithName:@"GillSans" size:20.0]; // text font
    searchBar.adjustsFontSizeToFitWidth = YES;     //adjust the font size to fit width.
    searchBar.borderStyle= UITextBorderStyleRoundedRect;
    searchBar.backgroundColor=[UIColor darkGrayColor];
    searchBar.textColor = [UIColor whiteColor];             //text color
    searchBar.textAlignment=NSTextAlignmentLeft;
    searchBar.clearButtonMode = UITextFieldViewModeAlways;//for clear button on right side
    searchBar.returnKeyType= UIReturnKeyGo;//we are assigning the done button like returnbutton
    [searchBar resignFirstResponder];
    [searchBar addTarget:self action:@selector(delayedSearch) forControlEvents:UIControlEventEditingChanged];
    //searchBar.delegate=self; //we need to put the delegate of this to hide the keyboard with the done botton
    [searchView addSubview:searchBar];
    
    /*  UIButton *cancelButton = [UIButton buttonWithType:UIButtonTypeCustom];
     CGRect firstButton =CGRectMake(self.view.frame.size.width-68, 0, 70, 30);
     [cancelButton setFrame:firstButton]; //1
     [cancelButton setTitle:@"Cancel" forState:UIControlStateNormal];
     [cancelButton setBackgroundColor:[UIColor blackColor]];
     [cancelButton addTarget:self action:@selector(openMenuSearch:) forControlEvents:UIControlEventTouchDown];
     [searchView addSubview:cancelButton];
     */
    
    tableViewSearch=[[UITableView alloc] initWithFrame:(CGRectMake(0, 35, self.view.frame.size.width, self.view.frame.size.height-74)) style:UITableViewStylePlain];
    tableViewSearch.delegate=self;
    tableViewSearch.dataSource = self;
    tableViewSearch.rowHeight = 32;
    tableViewSearch.bounces=YES;
    //tableView.backgroundColor=[UIColor colorWithCGColor:whiteColorApp];
    tableViewSearch.clipsToBounds=YES;
    tableViewSearch.scrollsToTop=NO;
    // [tableView setSectionIndexColor:[UIColor redColor]];
    [searchView addSubview:tableViewSearch];
    
    
    /*---------------------------------------------------------------------------
     * Info View
     *--------------------------------------------------------------------------*/
    
    InfoView=[[UIView alloc]init];
    InfoView.frame=CGRectMake(self.view.frame.size.width, 0, self.view.frame.size.width, self.view.frame.size.height);
    InfoView.backgroundColor=[UIColor whiteColor];
    
    scrollOfInfoMenu = [[UIScrollView alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height)];
    scrollOfInfoMenu.contentSize= CGSizeMake(self.view.frame.size.width, self.view.frame.size.height-44);
    scrollOfInfoMenu.backgroundColor = [UIColor whiteColor];
    //self.scrollView.contentInset = UIEdgeInsetsMake(vOffset, hOffset, 0, 0);
    scrollOfInfoMenu.showsVerticalScrollIndicator = YES;    // to hide scroll indicators!
    scrollOfInfoMenu.scrollEnabled = YES;
    //textField.delegate = self;              //use this when ur using Delegate methods of UITextField
    [InfoView addSubview:scrollOfInfoMenu];
    
    menuInfoView=[[UIView alloc]init];
    menuInfoView.frame=CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height-44);
    menuInfoView.backgroundColor=[UIColor whiteColor];
    [scrollOfInfoMenu addSubview:menuInfoView];
    
   /*
    UILabel *tituloInfoWords = [[UILabel alloc]init];
    tituloInfoWords.text=@"info";
    tituloInfoWords.backgroundColor=[UIColor clearColor];
    tituloInfoWords.frame=CGRectMake(5, 9, 100, 24);
    [menuInfoView addSubview:tituloInfoWords];
    
    UILabel *tituloNameLista = [[UILabel alloc]init];
    tituloNameLista.text=@"Name of the list";
    tituloNameLista.backgroundColor=[UIColor clearColor];
    tituloNameLista.frame=CGRectMake(5, 30, 200, 24);
    [menuInfoView addSubview:tituloNameLista];
    */
    
    /*nombreLista=[[UITextField alloc]initWithFrame:CGRectMake(5, 60, 200, 24)];
    nombreLista.backgroundColor=[UIColor whiteColor];
    [menuInfoView addSubview:nombreLista];*/
    
    nombreLista=[[UITextField alloc]initWithFrame:CGRectMake(10, 20, self.view.frame.size.width-20, 38)];
    nombreLista.placeholder = @"Your list name";
    [nombreLista setValue:[UIColor lightTextColor] forKeyPath:@"_placeholderLabel.textColor"];
    nombreLista.font = [UIFont fontWithName:@"GillSans" size:25.0]; // text font
    nombreLista.adjustsFontSizeToFitWidth = YES;     //adjust the font size to fit width.
    nombreLista.borderStyle= UITextBorderStyleRoundedRect;
    nombreLista.backgroundColor=[UIColor darkGrayColor];
    nombreLista.textColor = [UIColor whiteColor];             //text color
    nombreLista.textAlignment=NSTextAlignmentLeft;
    nombreLista.clearButtonMode = UITextFieldViewModeAlways;//for clear button on right side
    
    [scrollOfInfoMenu addSubview:nombreLista];
    
    UILabel *explicacionLanguageNew1= [[UILabel alloc]initWithFrame:CGRectMake(15, 50, self.view.frame.size.width-30, 30)];
    explicacionLanguageNew1.text=@"*List you are learning";
    explicacionLanguageNew1.font=[UIFont fontWithName:@"GillSans" size:13.0];
    explicacionLanguageNew1.textColor= [UIColor grayColor];
    explicacionLanguageNew1.backgroundColor= [UIColor clearColor];
    explicacionLanguageNew1.textAlignment=NSTextAlignmentLeft;
    
    [scrollOfInfoMenu addSubview:explicacionLanguageNew1];
    
    UILabel *labelNote1= [[UILabel alloc]initWithFrame:CGRectMake(30, 210, self.view.frame.size.width-30, 30)];
    labelNote1.text=@"Notes";
    labelNote1.font=[UIFont fontWithName:@"GillSans" size:25.0];
    labelNote1.textColor= [UIColor grayColor];
    labelNote1.backgroundColor= [UIColor clearColor];
    labelNote1.textAlignment=NSTextAlignmentLeft;
    
    [scrollOfInfoMenu addSubview:labelNote1];

    
        
    infoText=[[UITextView alloc]initWithFrame:CGRectMake(30, 250, self.view.frame.size.width-60, self.view.frame.size.height-320)];
    //text.frame=CGRectMake(0, 42, self.view.frame.size.width, self.view.frame.size.height-48);
    //  originalTextViewFrame=CGRectMake(3, 55, self.view.frame.size.width-6, self.view.frame.size.height-100);
    //text.backgroundColor= [UIColor colorWithCGColor:];
    infoText.font=[UIFont fontWithName:@"GillSans" size:18.0];
    infoText.textColor=[UIColor whiteColor];
    infoText.backgroundColor=[UIColor darkGrayColor];
    infoText.clipsToBounds = YES;
    infoText.scrollsToTop=YES;
    infoText.bounces=NO;
    infoText.delegate=self;
    [scrollOfInfoMenu addSubview:infoText];
    
    gestureInfoMenu = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(openMenuInfoGest:)];
    gestureInfoMenu.minimumPressDuration = 0.7; //seconds
    gestureInfoMenu.delegate = self;
    
    [self.tableViewLista addGestureRecognizer:gestureInfoMenu];
    
    /*---------------------------------------------------------------------------
     * Info View Words in search
     *--------------------------------------------------------------------------*/
    
    InfoViewWords=[[UIView alloc]init];
    InfoViewWords.frame=CGRectMake(self.view.frame.size.width, 0, self.view.frame.size.width, self.view.frame.size.height);
    InfoViewWords.backgroundColor=[UIColor whiteColor];
    
    scrollOfInfoMenuWords = [[UIScrollView alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height)];
    scrollOfInfoMenuWords.contentSize= CGSizeMake(self.view.frame.size.width, self.view.frame.size.height-44);
    scrollOfInfoMenuWords.backgroundColor = [UIColor whiteColor];
    //self.scrollView.contentInset = UIEdgeInsetsMake(vOffset, hOffset, 0, 0);
    scrollOfInfoMenuWords.showsVerticalScrollIndicator = YES;    // to hide scroll indicators!
    scrollOfInfoMenuWords.scrollEnabled = YES;
    //textField.delegate = self;              //use this when ur using Delegate methods of UITextField
    [InfoViewWords addSubview:scrollOfInfoMenuWords];
    
    menuInfoViewWords=[[UIView alloc]init];
    menuInfoViewWords.frame=CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height-44);
    menuInfoViewWords.backgroundColor=[UIColor whiteColor];
    [scrollOfInfoMenuWords addSubview:menuInfoViewWords];
    
    
    /*UILabel *tituloInfoWords1 = [[UILabel alloc]init];
     tituloInfoWords1.text=@"info words";
     tituloInfoWords1.backgroundColor=[UIColor clearColor];
     tituloInfoWords1.frame=CGRectMake(5, 9, 100, 24);
     [menuInfoViewWords addSubview:tituloInfoWords1];
     */
    
    UILabel *labelNote= [[UILabel alloc]initWithFrame:CGRectMake(30, 210, self.view.frame.size.width-30, 30)];
    labelNote.text=@"Notes";
    labelNote.font=[UIFont fontWithName:@"GillSans" size:25.0];
    labelNote.textColor= [UIColor grayColor];
    labelNote.backgroundColor= [UIColor clearColor];
    labelNote.textAlignment=NSTextAlignmentLeft;
    
    [menuAddView addSubview:labelNote];
    
    idiomaMaster1 = [[UILabel alloc]initWithFrame:CGRectMake(15, 15, self.view.frame.size.width-30, 30)];
    idiomaMaster1.text=nil;
    idiomaMaster1.font=[UIFont fontWithName:@"GillSans" size:25.0];
    idiomaMaster1.textColor= [UIColor grayColor];
    idiomaMaster1.backgroundColor=[UIColor clearColor];
    idiomaMaster1.textAlignment=NSTextAlignmentLeft;
    
    [menuInfoViewWords addSubview:idiomaMaster1];
    
    
    infoWord1=[[UITextField alloc]initWithFrame:CGRectMake(10, 50, self.view.frame.size.width-20, 38)];
    infoWord1.placeholder = @"You know";
    [infoWord1 setValue:[UIColor lightTextColor] forKeyPath:@"_placeholderLabel.textColor"];
    infoWord1.font = [UIFont fontWithName:@"GillSans" size:25.0]; // text font
    infoWord1.adjustsFontSizeToFitWidth = YES;     //adjust the font size to fit width.
    infoWord1.borderStyle= UITextBorderStyleRoundedRect;
    infoWord1.backgroundColor=[UIColor darkGrayColor];
    infoWord1.textColor = [UIColor whiteColor];             //text color
    infoWord1.textAlignment=NSTextAlignmentLeft;
    infoWord1.clearButtonMode = UITextFieldViewModeAlways;//for clear button on right side
    
    [menuInfoViewWords addSubview:infoWord1];
    
    
    
    
    
    
    idiomaLearn1 = [[UILabel alloc]initWithFrame:CGRectMake(15, 105, self.view.frame.size.width-30, 30)];
    idiomaLearn1.text=nil;
    idiomaLearn1.font=[UIFont fontWithName:@"GillSans" size:25.0];
    idiomaLearn1.textColor= [UIColor grayColor];
    idiomaLearn1.backgroundColor=[UIColor clearColor];
    idiomaLearn1.textAlignment=NSTextAlignmentLeft;
    
    [menuInfoViewWords addSubview:idiomaLearn1];
    
    
    infoWord2=[[UITextField alloc]initWithFrame:CGRectMake(10, 140, self.view.frame.size.width-20, 38)];
    infoWord2.placeholder = @"You know";
    [infoWord2 setValue:[UIColor lightTextColor] forKeyPath:@"_placeholderLabel.textColor"];
    infoWord2.font = [UIFont fontWithName:@"GillSans" size:25.0]; // text font
    infoWord2.adjustsFontSizeToFitWidth = YES;     //adjust the font size to fit width.
    infoWord2.borderStyle= UITextBorderStyleRoundedRect;
    infoWord2.backgroundColor=[UIColor darkGrayColor];
    infoWord2.textColor = [UIColor whiteColor];             //text color
    infoWord2.textAlignment=NSTextAlignmentLeft;
    infoWord2.clearButtonMode = UITextFieldViewModeAlways;//for clear button on right side
    
    
    [menuInfoViewWords addSubview:infoWord2];
    
    
    UILabel *labelNote2= [[UILabel alloc]initWithFrame:CGRectMake(30, 210, self.view.frame.size.width-30, 30)];
    labelNote2.text=@"Notes";
    labelNote2.font=[UIFont fontWithName:@"GillSans" size:25.0];
    labelNote2.textColor= [UIColor grayColor];
    labelNote2.backgroundColor= [UIColor clearColor];
    labelNote2.textAlignment=NSTextAlignmentLeft;
    
    [menuInfoViewWords addSubview:labelNote2];
    
    infoTextWords=[[UITextView alloc]initWithFrame:CGRectMake(30, 250, self.view.frame.size.width-60, self.view.frame.size.height-320)];
    //text.frame=CGRectMake(0, 42, self.view.frame.size.width, self.view.frame.size.height-48);
    //originalTextViewFrame=CGRectMake(3, 55, self.view.frame.size.width-6, self.view.frame.size.height-100);
    //text.backgroundColor= [UIColor colorWithCGColor:];
    infoTextWords.font=[UIFont fontWithName:@"GillSans" size:18.0];
    infoTextWords.textColor=[UIColor whiteColor];
    infoTextWords.backgroundColor=[UIColor darkGrayColor];
    infoTextWords.clipsToBounds = YES;
    infoTextWords.scrollsToTop=YES;
    infoTextWords.bounces=NO;
    infoTextWords.delegate=self;
    [menuInfoViewWords addSubview:infoTextWords];
    


}



- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void) viewDidAppear:(BOOL)animated{
    menuFlagAlpha=FALSE;
    
    arrayListas = [dao getListOfLists:languageID];
    
    dictionaryList= [dao getingDirectListas:languageID];
   // [arrayListas sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];

    [self.tableViewLista reloadData];
    
    
    NSMutableDictionary *ejemplo = [[NSMutableDictionary alloc]init];
    ejemplo=[dao getDictionarForSearch];

    
}


- (void)setTitleNav:(NSString *)title
{
    
    
    [super setTitle:title];
    UILabel *titleView = (UILabel *)self.navigationItem.titleView;
    if (!titleView) {
        titleView = [[UILabel alloc] initWithFrame:CGRectZero];
        titleView.backgroundColor = [UIColor clearColor];
        titleView.font = [UIFont fontWithName:@"GillSans" size:25.0];
        titleView.shadowColor = [UIColor colorWithWhite:0.5 alpha:0.0];
        
        titleView.textColor = [UIColor grayColor]; // Change to desired color
        
        self.navigationItem.titleView = titleView;
        // [titleView release];
    }
    titleView.text = title;
    [titleView sizeToFit];
}


- (void) hideKeyboard {
    
    [self.view endEditing:YES];
}

#pragma mark - Table view data source

#pragma mark - Table view detect scrolling


- (void)scrollViewDidScroll:(UIScrollView *)sender{
    //executes when you scroll the scrollView --> when scroll is scrolling
    
    
}

- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView {
    // execute when you drag the scrollView
    
    //NSLog(@"scrolling!");
    [self.view endEditing:YES]; //keyboard goes out
    
}



- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    
    
    /*****************************************************************
     *
     * I have  to check here!!!!!  I Hide the tableview when im not 
     * using it, it should be more elegant, or maybe not! see it!
     *
     *****************************************************************/
    
    //NSLog(@"numberOfSectionInTableView");
    
    if (menuFlagSearch==FALSE) { //if the searchView is on the top
        
        //NSLog(@"mierda");

        
        if ([searchBar.text length]==0) {
            //NSLog(@"mierda2");
            
            [tableViewSearch removeFromSuperview];
            return 0;

        }else{
            
            
            if ([dictionaryWords.allKeys count]!=0) {
                [searchView addSubview:tableViewSearch];

            }else{
                [tableViewSearch removeFromSuperview];

            }
            
        return [dictionaryWords.allKeys count];
        }
    }else{ //if the normal view is on the top
    
    // Return the number of sections.
       // NSLog(@"HOLA que pasa: %d", [dictionaryList.allKeys count]);
    return [dictionaryList.allKeys count];
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    if (menuFlagSearch==FALSE) {

    return section == 0 ? 15 : 15;
    }else{
        return section == 0 ? 15 : 15;

    }
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    
    NSLog(@"Number of rows");
    
    if (menuFlagSearch==FALSE) { //ensenia las palabras, el buscador esta en pantalla
        
        //NSLog(@"False");
        NSSortDescriptor* sortDescriptor = [NSSortDescriptor sortDescriptorWithKey:nil ascending:YES selector:@selector(localizedCompare:)];
        NSArray* sortedCategories = [dictionaryWords.allKeys sortedArrayUsingDescriptors:[NSArray arrayWithObject:sortDescriptor]];
        
        NSString *categoryName = [sortedCategories objectAtIndex:section];
        
        NSArray *currentCategory = [dictionaryWords objectForKey:categoryName];
        
        return [currentCategory count];

    }else{ //buscador no en pantalla
        
        
        //NSLog(@"True");
    
    // Return the number of rows in the section.
        NSSortDescriptor* sortDescriptor = [NSSortDescriptor sortDescriptorWithKey:nil ascending:YES selector:@selector(localizedCompare:)];
        NSArray* sortedCategories = [dictionaryList.allKeys sortedArrayUsingDescriptors:[NSArray arrayWithObject:sortDescriptor]];
        
        NSString *categoryName = [sortedCategories objectAtIndex:section];
        
        NSArray *currentCategory = [dictionaryList objectForKey:categoryName];
        
        //NSLog(@"hola nombre categoria: %@", categoryName);
        
        if (currentCategory!=0) { //puting inside the tableview when i have items 
            [self.view addSubview:tableViewLista];
        }else{
            [tableViewLista removeFromSuperview];
        }
        
        return [currentCategory count];
        
        
    //return [arrayListas count];
    }
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
   // if (menuFlagSearch==FALSE) {
        UIView *customSectionHeaderView;
        UILabel *nameCategory;
        
        UIFont *labelFont;
        
        if (section == 0)
        {
            customSectionHeaderView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, tableView.frame.size.width, 15)];
            
            nameCategory = [[UILabel alloc] initWithFrame:CGRectMake(9, 0, tableView.frame.size.width/2, 15)];
            
            labelFont = [UIFont fontWithName:@"GillSans" size:13.0];
        }
        else
        {
            customSectionHeaderView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, tableView.frame.size.width, 15)];
            
            nameCategory = [[UILabel alloc] initWithFrame:CGRectMake(9, 0, tableView.frame.size.width/2, 15)];
            labelFont = [UIFont fontWithName:@"GillSans" size:13.0];
        }
        
        customSectionHeaderView.backgroundColor = [UIColor colorWithRed:146.0/255.0 green:176.0/255.0 blue:88.0/255.0 alpha:1];
    
        nameCategory.textAlignment = UITextAlignmentLeft;
        [nameCategory setTextColor:[UIColor whiteColor]];
        [nameCategory setBackgroundColor:[UIColor clearColor]];
        nameCategory.font = labelFont;
        

        
        NSSortDescriptor* sortDescriptor = [NSSortDescriptor sortDescriptorWithKey:nil ascending:YES selector:@selector(localizedCompare:)];
    
    NSArray* sortedCategories = [[NSArray alloc]init];
    
    if (menuFlagSearch==FALSE) {
        
            sortedCategories = [dictionaryWords.allKeys sortedArrayUsingDescriptors:[NSArray arrayWithObject:sortDescriptor]];

    }else{
            sortedCategories = [dictionaryList.allKeys sortedArrayUsingDescriptors:[NSArray arrayWithObject:sortDescriptor]];

        

       // sortedCategories = [dictionaryWords.allKeys sortedArrayUsingDescriptors:[NSArray arrayWithObject:sortDescriptor]];


    }
    
    NSString *categoryName = [sortedCategories objectAtIndex:section];
    
    
    nameCategory.text=categoryName;
    
    
    [customSectionHeaderView addSubview:nameCategory];
    
    
    return customSectionHeaderView;
   /* }else{
        return nil;

    }*/
//sortedCategories=nil;

}



- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    if (menuFlagSearch==FALSE) {
        UILabel *left;
        UILabel *right;
        
        
        
        UITableViewCell *cell;
        if (cell == nil)
        {
            cell = [[UITableViewCell alloc] init];
            
            cell.selectionStyle = UITableViewCellSelectionStyleBlue;
            
            
            //  searchBar.adjustsFontSizeToFitWidth = YES;     //adjust the font size to fit width.
            
            left =[[UILabel alloc]initWithFrame:CGRectMake(9,4,(self.view.frame.size.width/2)-14,20)];
            left.font=[UIFont fontWithName:@"GillSans" size:16.5];
            left.textColor=[UIColor blackColor];
            left.backgroundColor=[UIColor clearColor];
            left.adjustsFontSizeToFitWidth=YES;
            //left.enabled=NO;
            [cell.contentView addSubview:left];
            
            right =[[UILabel alloc]initWithFrame:CGRectMake((self.view.frame.size.width/2)+9,4,(self.view.frame.size.width/2)-14,20)];
            right.font=[UIFont fontWithName:@"GillSans" size:16.5];
            right.textColor=[UIColor blackColor];
            right.backgroundColor=[UIColor clearColor];
            right.adjustsFontSizeToFitWidth=YES;
            // right.enabled=NO;
            [cell.contentView addSubview:right];
        }
        
        // Configure the cell...
        
            if ([dictionaryWords.allKeys count]!=0) {
            
                NSLog(@"dictioary despues de la busqueda: %@", [[dictionaryWords objectForKey:@"Casa"]valueForKey:@"word1"]);
            
                NSSortDescriptor* sortDescriptor = [NSSortDescriptor sortDescriptorWithKey:nil ascending:YES selector:@selector(localizedCompare:)];
                NSArray* sortedCategories = [dictionaryWords.allKeys sortedArrayUsingDescriptors:[NSArray arrayWithObject:sortDescriptor]];
            
                NSString *categoryName = [sortedCategories objectAtIndex:indexPath.section];
            
                NSArray *currentCategory = [dictionaryWords objectForKey:categoryName];
            
                NSDictionary *currentWord = [currentCategory objectAtIndex:indexPath.row];
            
                left.text = [currentWord valueForKey:@"word1"];
                right.text = [currentWord valueForKey:@"word2"];

            }
        
        
        if (indexPath.row % 2 ==0) {
            
            UIImageView *imagecell=[[UIImageView alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 60)];
            imagecell.image=[UIImage imageNamed:@"barraSearchVoca@2x.png"];
            cell.backgroundView=imagecell;
        }else{
            
            UIImageView *imagecell=[[UIImageView alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 60)];
            imagecell.image=[UIImage imageNamed:@"barraSearchVoca2@2x.png"];
            cell.backgroundView=imagecell;
        }
        
        //COLOR PRESSING THE CELL////
        UIView *selectedBackgroundViewForCell = [UIView new];
        [selectedBackgroundViewForCell setBackgroundColor:[UIColor darkGrayColor]];
        cell.selectedBackgroundView = selectedBackgroundViewForCell;
        
        
        return cell;

    }else{
    
    UITableViewCell *cell;
    if (cell == nil)
    {
        cell = [[UITableViewCell alloc] init];
    }
    
    // Configure the cell...
   // cell.textLabel.text = [[arrayListas objectAtIndex:[indexPath row]] valueForKey:@"listaDeTipos"];
	
        if ([dictionaryList.allKeys count]!=0) {
            
            //NSLog(@"dictioary despues de la busqueda: %@", [[dictionaryWords objectForKey:@"Casa"]valueForKey:@"word1"]);
            
            NSSortDescriptor* sortDescriptor = [NSSortDescriptor sortDescriptorWithKey:nil ascending:YES selector:@selector(localizedCompare:)];
            NSArray* sortedCategories = [dictionaryList.allKeys sortedArrayUsingDescriptors:[NSArray arrayWithObject:sortDescriptor]];
            
            NSString *categoryName = [sortedCategories objectAtIndex:indexPath.section];
            
            NSArray *currentCategory = [dictionaryList objectForKey:categoryName];
            
            NSDictionary *currentWord = [currentCategory objectAtIndex:indexPath.row];
            
            cell.textLabel.text =[currentWord valueForKey:@"listaDeTipos"];
            
            //   cell.textLabel.textAlignment= NSTextAlignmentCenter;
            cell.textLabel.font = [UIFont fontWithName:@"GillSans" size:20.0];
            cell.textLabel.textColor = [UIColor darkGrayColor];
            cell.textLabel.backgroundColor = [UIColor clearColor];
            // cell.backgroundColor = [UIColor redColor];
            
            UIImageView *imagecell=[[UIImageView alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 60)];
            imagecell.image=[UIImage imageNamed:@"barraDictionaries@2x.png"];
            cell.backgroundView=imagecell;
                        
        }
        
        //COLOR PRESSING THE CELL////
        UIView *selectedBackgroundViewForCell = [UIView new];
        [selectedBackgroundViewForCell setBackgroundColor:[UIColor darkGrayColor]];
        cell.selectedBackgroundView = selectedBackgroundViewForCell;
        
        
    return cell;
    }
}

- (float)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    // This will create a "invisible" footer
    return 0.000001f; //da lo mismo que sea pequenio o muy pequenio
}

/*
 // Override to support conditional editing of the table view.
 - (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
 {
 // Return NO if you do not want the specified item to be editable.
 return YES;
 }
 */

/*---------------------------------------------------------------------------
 * Calling to function dataBase
 *--------------------------------------------------------------------------*/

 // Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath{
    if (editingStyle == UITableViewCellEditingStyleDelete) {
         // Delete the row from the data source
         
        if (menuFlagSearch==TRUE) { //no in the search view
            NSSortDescriptor* sortDescriptor = [NSSortDescriptor sortDescriptorWithKey:nil ascending:YES selector:@selector(localizedCompare:)];
            NSArray* sortedCategories = [dictionaryList.allKeys sortedArrayUsingDescriptors:[NSArray arrayWithObject:sortDescriptor]];
            
            NSString *categoryName = [sortedCategories objectAtIndex:indexPath.section];
            
            NSArray *currentCategory = [dictionaryList objectForKey:categoryName];
            
            // NSLog(@"CurrentCategory: %@", currentCategory);
            
            NSDictionary *currentList = [currentCategory objectAtIndex:indexPath.row];
            // NSLog(@"currentList: %@", currentList);
            
            NSString *pepe = [currentList valueForKey:@"listId"];
            listID = [pepe integerValue];
            
            
            [self deletingListWarning:[currentList valueForKey:@"listaDeTipos"]];
        }else{
            
            NSSortDescriptor* sortDescriptor = [NSSortDescriptor sortDescriptorWithKey:nil ascending:YES selector:@selector(localizedCompare:)];
            NSArray* sortedCategories = [dictionaryWords.allKeys sortedArrayUsingDescriptors:[NSArray arrayWithObject:sortDescriptor]];
            
            NSString *categoryName = [sortedCategories objectAtIndex:indexPath.section];
            
            NSArray *currentCategory = [dictionaryWords objectForKey:categoryName];
            
            NSDictionary *currentWord = [currentCategory objectAtIndex:indexPath.row];
            
            NSString *pepe = [currentWord valueForKey:@"wordId"];
            wordID = [pepe integerValue];
            
            
            
            // [self deletingLanguageWarning:[[arrayLenguas objectAtIndex:indexPath.row]valueForKey:@"language"]];
            [self deletingWordWarning: wordID nameWord:[currentWord valueForKey:@"word1"]];
            
            
        }
        

        
        

    }
}

- (void) deletingListWarning:(NSString *)nombreListaT {
    
    NSMutableString *message = [[NSMutableString alloc]initWithString:@"You will lose all the content of "];
    [message appendString:nombreListaT];
    
    UIAlertView *alert = [[UIAlertView alloc]
                          initWithTitle:@"Are you sure?"
                          message:message
                          delegate:self
                          cancelButtonTitle:@"NO"
                          otherButtonTitles:@"YES", nil];
    //alert.tag=1;
    
    [alert show];
    
}

- (void) deletingWordWarning:(NSInteger)wordID nameWord:(NSString *)nameWord {
    
    NSMutableString *message = [[NSMutableString alloc]initWithString:@"Delete the word "];
    [message appendString:nameWord];
    
    UIAlertView *alert = [[UIAlertView alloc]
                          initWithTitle:@"Are you sure?"
                          message:message
                          delegate:self
                          cancelButtonTitle:@"NO"
                          otherButtonTitles:@"YES", nil];
    //alert.tag=1;
    
    [alert show];
    
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    
    if (buttonIndex == 0){
    
    
    }else{
        
        if (menuFlagSearch==TRUE) { //no searchview
            [dao deleteList:listID];
            
            
            dictionaryList= [dao getingDirectListas:languageID];
            
            if ([dictionaryList.allKeys count ]==0) { //puting out of the view the tableview when doesnt have items inside
                [tableViewLista removeFromSuperview];
            }
            
            [tableViewLista reloadData];
        }else{
            
            [dao deleteWordSearch:wordID];
            
            dictionaryWordsSupporter= [dao getDictionarForSearch];
            
            if ([dictionaryWords.allKeys count]==0) {
                [tableViewSearch removeFromSuperview];
            }
            
           // [tableViewSearch reloadData];
            
            [self searchTabA:nil];

            
        }

        
    }
    
}
 


 // Override to support rearranging the table view.
/*
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath
 {
     
 }
 */

/*
 // Override to support conditional rearranging of the table view.
 - (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath
 {
 // Return NO if you do not want the item to be re-orderable.
 return YES;
 }
 */

/*
 #pragma mark - Table view delegate
 
 - (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
 {
 ModVehiculoViewController *destino = [self.storyboard instantiateViewControllerWithIdentifier:@"visualizacion"];
 Vehiculo *tmp = [vehiculos objectAtIndex:[indexPath row]];
 destino.vehiculo = tmp;
 
 [self.navigationController pushViewController:destino animated:YES];
 }
 
 */

#pragma mark - keyboard detection



- (void) viewWillAppear:(BOOL)animated{
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillShow:) name:UIKeyboardWillShowNotification object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillHide:) name:UIKeyboardWillHideNotification object:nil];
}

- (void)keyboardWillShow:(NSNotification*)notification {
    
    NSDictionary *userInfo = [notification userInfo];
    NSTimeInterval animationDuration;
    UIViewAnimationCurve animationCurve;
    CGRect keyboardRect;
    
    [[userInfo objectForKey:UIKeyboardAnimationCurveUserInfoKey] getValue:&animationCurve];
    animationDuration = [[userInfo objectForKey:UIKeyboardAnimationDurationUserInfoKey] doubleValue];
    keyboardRect = [[userInfo objectForKey:UIKeyboardFrameEndUserInfoKey] CGRectValue];
    keyboardRect = [self.view convertRect:keyboardRect fromView:nil];
    
    [UIView beginAnimations:@"ResizeForKeyboard" context:nil];
    [UIView setAnimationDuration:animationDuration];
    [UIView setAnimationCurve:animationCurve];
    
    scrollOfInfoMenu.frame=CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height-210);
    scrollOfAddMenu.frame=CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height-210);
    scrollOfInfoMenuWords.frame=CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height-210);
    
    [UIView commitAnimations];
    
    
}

- (void)keyboardWillHide:(NSNotification*)notification {
    
    NSDictionary *userInfo = [notification userInfo];
    NSTimeInterval animationDuration;
    UIViewAnimationCurve animationCurve;
    CGRect keyboardRect;
    
    [[userInfo objectForKey:UIKeyboardAnimationCurveUserInfoKey] getValue:&animationCurve];
    animationDuration = [[userInfo objectForKey:UIKeyboardAnimationDurationUserInfoKey] doubleValue];
    keyboardRect = [[userInfo objectForKey:UIKeyboardFrameEndUserInfoKey] CGRectValue];
    keyboardRect = [self.view convertRect:keyboardRect fromView:nil];
    
    [UIView beginAnimations:@"ResizeForKeyboard" context:nil];
    [UIView setAnimationDuration:animationDuration];
    [UIView setAnimationCurve:animationCurve];
    
    scrollOfInfoMenu.frame=CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height);
    scrollOfAddMenu.frame=CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height);
    scrollOfInfoMenuWords.frame=CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height);

    
    [UIView commitAnimations];
}


#pragma mark - Calling to function dataBase

- (void) addNewListInDataBase{
    //NSLog(@"Añadiendo nueva");
    
    if ([nombreListaNueva.text length] == 0) {
        
        UIAlertView *alert = [[UIAlertView alloc]
                              initWithTitle:@"Attention!"
                              message:@"You should write the name before saving!"
                              delegate:self
                              cancelButtonTitle:@"Ok"
                              otherButtonTitles:nil, nil];
        [alert show];
        
    }else{
        
        [dao addList:nombreListaNueva.text comments:addText.text lenguaLista:lenguaLista lenguaMaster:lenguaMaster languageID:languageID];
        arrayListas = [dao getListOfLists:languageID];

        dictionaryList= [dao getingDirectListas:languageID];
        
        
        [tableViewLista reloadData];
        
        [self openMenuAdd:nil];
        nombreListaNueva.text=@"";
        
    }
}



/*
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    
    [self.tableViewWords reloadData];
    
    if (buttonIndex == 0){
        //Code for CancelButtonTitle button (its the first one in this case is NO (moreWordsAlert) or okey)
        if (alertView.tag==1) { //when is the alert is coming from the moreWordsAlert
            
            [self openMenuAdd:(nil)];
            
            aNewWord1.text=@"";
            aNewWord2.text=@"";
            addText.text=@"";
        }
        
        
    }
    if (buttonIndex == 1){
        aNewWord1.text=@"";
        aNewWord2.text=@"";
        addText.text=@"";
        
        [aNewWord1 becomeFirstResponder];
        
    }
}*/

/*---------------------------------------------------------------------------
 * I check if we are searching or just moding and doing diferents things in
 * each case
 *--------------------------------------------------------------------------*/

- (void) modListInDataBase{
    
    if ([nombreLista.text length] ==0) {
        UIAlertView *alert = [[UIAlertView alloc]
                              initWithTitle:@"Attention!"
                              message:@"You should write the name before saving!"
                              delegate:self
                              cancelButtonTitle:@"Ok"
                              otherButtonTitles:nil, nil];
        [alert show];
    }else{
    
        [dao modList:nombreLista.text comments:infoText.text listID:listID];
    
        infoText.text=@""; //i have to empty the box
        
        dictionaryList= [dao getingDirectListas:languageID];
        
        [self.tableViewLista reloadData];
    
        
        
        /*if (menuFlagSearch==FALSE) { //para cuando empiece con el buscador
            //   arrayWordsSupporter = [dao getListOfWords:lenguaLista lista:lista];
            //   [self searchTabA:nil];
        }else{
            arrayListas = [dao getListOfLists:languageID];
            [self.tableViewLista reloadData];
        
        }
         */
    
        [self openMenuInfo:(nil)];
    }
    
}

- (void) modWordInDataBase{
    
    if ([infoWord1.text length]==0 || [infoWord2.text length]==0) {
        UIAlertView *alert = [[UIAlertView alloc]
                              initWithTitle:@"Attention!"
                              message:@"You should complete all the sections before saving!"
                              delegate:self
                              cancelButtonTitle:@"Ok"
                              otherButtonTitles:nil, nil];
        [alert show];
        
    } else{
    
        [dao modWord:infoWord1.text word2:infoWord2.text lengua:lenguaLista comments:infoTextWords.text wordID:wordID];
    
        infoTextWords.text=@""; //i have to empty the box
    
        if (menuFlagSearch==FALSE) {
        
            dictionaryWordsSupporter= [dao getDictionarForSearch];

        
            // arrayWordsSupporter = [dao getListOfWords:listaOriginId];
            [self searchTabA:nil];
        }else{
            //  arrayWords = [dao getListOfWords:listaOriginId];
        
            dictionaryWords= [dao getDictionarForSearch];

            [self.tableViewLista reloadData];
        
        }
    
        [self openMenuInfoWords:(nil)];
    }
    
}

#pragma mark - Functions for moving menus

/*---------------------------------------------------------------------------
 * Menu Info moving words
 *--------------------------------------------------------------------------*/


- (void)openMenuInfoWords:(id)sender
{
    // Move the menu view
    if (menuFlag == FALSE)
    {
        
        [self setTitleNav:@"Search"];

        if (menuFlagSearch==TRUE) {
            [self.navigationController setToolbarHidden:NO animated:YES];
            
            UIImage *buttonAddImage = [UIImage imageNamed:@"addAlexVocabularioGris.png"];
            //create the button and assign the image
            UIButton *buttonAdd = [UIButton buttonWithType:UIButtonTypeCustom];
            [buttonAdd setImage:buttonAddImage forState:UIControlStateNormal];
            [buttonAdd addTarget:self action:@selector(openMenuAdd:) forControlEvents:UIControlEventTouchUpInside];
            //sets the frame of the button to the size of the image
            buttonAdd.frame = CGRectMake(0, 0, 20, 20);
            //creates a UIBarButtonItem with the button as a custom view
            UIBarButtonItem *addLanguageButton = [[UIBarButtonItem alloc] initWithCustomView:buttonAdd];
            
            self.navigationItem.rightBarButtonItem=addLanguageButton;
            
        }else{
            
            //button for saving up-left
            UIButton *editCell1 = [UIButton buttonWithType:UIButtonTypeRoundedRect];
            [editCell1 setTitle:@"Cancel" forState:UIControlStateNormal];
            [editCell1 setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
            [editCell1 setTintColor:[UIColor redColor]];
            editCell1.titleLabel.font= [UIFont fontWithName:@"GillSans" size:16.0];
            
            [editCell1 addTarget:self action:@selector(openMenuSearch:) forControlEvents:UIControlEventTouchUpInside];
            CGRect buttonCancel= CGRectMake(0, 0, 60, 34);
            [editCell1 setFrame:buttonCancel];
            
            UIBarButtonItem *cancellLanguageButton= [[UIBarButtonItem alloc] initWithCustomView:editCell1];
            
            self.navigationItem.rightBarButtonItem=cancellLanguageButton;
            
        }
        
        self.navigationItem.leftBarButtonItem=nil;
        
        
        [self moveMenuInfoWords:InfoViewWords duration:0.2 curve:UIViewAnimationCurveEaseOut x:self.view.frame.size.width y:0.0];
        
        menuFlag = TRUE;
        
        
        //button for saving up-left
        
        
        [self.view endEditing:YES]; //keyboard goes out
        
        gestureInfoMenu.enabled=YES;

        
    }
    else
    {
        
        
        [self.view addSubview:InfoViewWords];
      
        [self setTitleNav:@"Info"];

        
        [self moveMenuInfo:InfoViewWords duration:0.2 curve:UIViewAnimationCurveEaseOut x:0.0 y:0.0];
        
        menuFlag = FALSE;
        
        
        [self.navigationController setToolbarHidden:YES animated:YES];
        
        scrollOfInfoMenuWords.frame=CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height);
        
        
        
        
        //button for saving up-left
        UIButton *editCell1 = [UIButton buttonWithType:UIButtonTypeRoundedRect];
        [editCell1 setTitle:@"Cancel" forState:UIControlStateNormal];
        [editCell1 setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
        [editCell1 setTintColor:[UIColor redColor]];
        editCell1.titleLabel.font= [UIFont fontWithName:@"GillSans" size:16.0];
        
        [editCell1 addTarget:self action:@selector(openMenuInfoWords:) forControlEvents:UIControlEventTouchUpInside];
        CGRect buttonCancel= CGRectMake(0, 0, 60, 34);
        [editCell1 setFrame:buttonCancel];
        
        UIBarButtonItem *cancellLanguageButton= [[UIBarButtonItem alloc] initWithCustomView:editCell1];
        
        self.navigationItem.rightBarButtonItem=cancellLanguageButton; //aqui que añadir la forma de salvar la info modificada de info
        
        //nota save

        UIButton *saving = [UIButton buttonWithType:UIButtonTypeRoundedRect];
        [saving setTitle:@"Save" forState:UIControlStateNormal];
        [saving setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
        [saving setTintColor:[UIColor greenColor]];
        saving.titleLabel.font= [UIFont fontWithName:@"GillSans" size:16.0];
        
        [saving addTarget:self action:@selector(modWordInDataBase) forControlEvents:UIControlEventTouchUpInside];
        CGRect savingFrame= CGRectMake(0, 0, 55, 34);
        [saving setFrame:savingFrame];
        
        UIBarButtonItem *guardarButton= [[UIBarButtonItem alloc] initWithCustomView:saving];
        
        
        
        self.navigationItem.leftBarButtonItem=guardarButton;
        
        //[infoWord1 becomeFirstResponder];
        
        
        
    }
}

- (void)moveMenuInfoWords:(UIView *)menuView duration:(NSTimeInterval)duration curve:(int)curve x:(CGFloat)x y:(CGFloat)y
{
    //NSLog(@"hi");
    
    [UIView animateWithDuration:duration
                          delay:0.0f
                        options:curve
                     animations:^{
                         CGRect menuFrame = InfoViewWords.frame;
                         menuFrame.origin.x = x;
                         menuFrame.origin.y = y;
                         menuView.frame = menuFrame;
                         
                         //  NSLog(@"%f",x);
                         //  NSLog(@"%f",y);
                         
                     }
                     completion:nil];
    
  /*  UIImage *buttonImage = [UIImage imageNamed:@"back2.png"];
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button setImage:buttonImage forState:UIControlStateNormal];
    button.frame = CGRectMake(0, 0, 65, 38);
    [button addTarget:self action:@selector(back) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *customBarItem = [[UIBarButtonItem alloc] initWithCustomView:button];
    self.navigationItem.leftBarButtonItem = customBarItem;
    */
    
}



/*---------------------------------------------------------------------------
 * Menu Info moving 2
 *--------------------------------------------------------------------------*/


- (void)openMenuInfo:(id)sender
{
    // close the menu
    if (menuFlag == FALSE)
    {
        [self setTitleNav:lenguaLista];
        
        

        
        if (menuFlagSearch==TRUE) {
            [self.navigationController setToolbarHidden:NO animated:YES];
            
            
            UIImage *buttonAddImage = [UIImage imageNamed:@"addAlexVocabularioGris.png"];
            //create the button and assign the image
            UIButton *buttonAdd = [UIButton buttonWithType:UIButtonTypeCustom];
            [buttonAdd setImage:buttonAddImage forState:UIControlStateNormal];
            [buttonAdd addTarget:self action:@selector(openMenuAdd:) forControlEvents:UIControlEventTouchUpInside];
            //sets the frame of the button to the size of the image
            buttonAdd.frame = CGRectMake(0, 0, 20, 20);
            //creates a UIBarButtonItem with the button as a custom view
            UIBarButtonItem *addLanguageButton = [[UIBarButtonItem alloc] initWithCustomView:buttonAdd];
            
            self.navigationItem.rightBarButtonItem=addLanguageButton;
            
        }else{
            
            //button for saving up-left
            UIBarButtonItem *cancellLanguageButton = [[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemCancel target:self action:@selector(openMenuSearch:)];
            self.navigationItem.rightBarButtonItem=cancellLanguageButton;
            
        }
        
        self.navigationItem.leftBarButtonItem=nil;
        
        [self.view bringSubviewToFront:InfoView];
        
        [self moveMenuInfo:InfoView duration:0.2 curve:UIViewAnimationCurveEaseOut x:self.view.frame.size.width y:0.0];
        
        menuFlag = TRUE;
        menuFlagAlpha= FALSE;
        
        //button for saving up-left
        
        [self.view endEditing:YES]; //keyboard goes out
        gestureInfoMenu.enabled=YES; // for not having problems with the gesture when im openning the menu
        menuFlagInfo=FALSE;
        nombreLista.text=@"";
        infoText.text=@"";
        
        
    }
    else //open the menu
    {
        [self.view addSubview:InfoView];
        
        [self setTitleNav:@"Info"];

        [self moveMenuInfo:InfoView duration:0.2 curve:UIViewAnimationCurveEaseOut x:0.0 y:0.0];
        
        menuFlag = FALSE;
        
        
        [self.navigationController setToolbarHidden:YES animated:YES];
        
        scrollOfInfoMenu.frame=CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height);
        
        
        //button for cancel
        UIButton *editCell1 = [UIButton buttonWithType:UIButtonTypeRoundedRect];
        [editCell1 setTitle:@"Cancel" forState:UIControlStateNormal];
        [editCell1 setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
        [editCell1 setTintColor:[UIColor redColor]];
        editCell1.titleLabel.font= [UIFont fontWithName:@"GillSans" size:16.0];
        
        [editCell1 addTarget:self action:@selector(openMenuInfo:) forControlEvents:UIControlEventTouchUpInside];
        CGRect buttonCancel= CGRectMake(0, 0, 60, 34);
        [editCell1 setFrame:buttonCancel];
        
        UIBarButtonItem *cancellLanguageButton= [[UIBarButtonItem alloc] initWithCustomView:editCell1];
        
        self.navigationItem.rightBarButtonItem=cancellLanguageButton;
        
        
        //button for saving

        
        UIButton *saving = [UIButton buttonWithType:UIButtonTypeRoundedRect];
        [saving setTitle:@"Save" forState:UIControlStateNormal];
        [saving setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
        [saving setTintColor:[UIColor greenColor]];
        saving.titleLabel.font= [UIFont fontWithName:@"GillSans" size:16.0];
        
        [saving addTarget:self action:@selector(modListInDataBase) forControlEvents:UIControlEventTouchUpInside];
        CGRect savingFrame= CGRectMake(0, 0, 55, 34);
        [saving setFrame:savingFrame];
        
        UIBarButtonItem *guardarButton= [[UIBarButtonItem alloc] initWithCustomView:saving];
        
        self.navigationItem.leftBarButtonItem=guardarButton; //aqui que añadir la forma de salvar la info modificada de info
        
        //[infoWord1 becomeFirstResponder];
        
        
        
    }
}

- (void)moveMenuInfo:(UIView *)menuView duration:(NSTimeInterval)duration curve:(int)curve x:(CGFloat)x y:(CGFloat)y
{
    //NSLog(@"hi");
    
    [UIView animateWithDuration:duration
                          delay:0.0f
                        options:curve
                     animations:^{
                         CGRect menuFrame = InfoView.frame;
                         menuFrame.origin.x = x;
                         menuFrame.origin.y = y;
                         menuView.frame = menuFrame;
                         
                         //  NSLog(@"%f",x);
                         //  NSLog(@"%f",y);
                         
                     }
                     completion:nil];
    
    gestureInfoMenu.enabled=NO; // for not having problems with the gesture when im openning the menu
    
    UIImage *buttonImage = [UIImage imageNamed:@"back2.png"];
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button setImage:buttonImage forState:UIControlStateNormal];
    button.frame = CGRectMake(0, 0, 65, 38);
    [button addTarget:self action:@selector(back) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *customBarItem = [[UIBarButtonItem alloc] initWithCustomView:button];
    self.navigationItem.leftBarButtonItem = customBarItem;
    



}


/*---------------------------------------------------------------------------
 * Menu Add moving
 *--------------------------------------------------------------------------*/


- (void)openMenuAdd:(id)sender
{
    // Move the menu view
    if (menuFlag == FALSE)
    {
        [self setTitleNav:lenguaLista];
        [tableViewLista reloadData];

       // [self.view bringSubviewToFront:AddView];
        
        [self.navigationController setToolbarHidden:NO animated:YES];
        
        
        
        menuFlag = TRUE;
        
        //button for saving up-left
        UIImage *buttonAddImage = [UIImage imageNamed:@"addAlexVocabularioGris.png"];
        //create the button and assign the image
        UIButton *buttonAdd = [UIButton buttonWithType:UIButtonTypeCustom];
        [buttonAdd setImage:buttonAddImage forState:UIControlStateNormal];
        [buttonAdd addTarget:self action:@selector(openMenuAdd:) forControlEvents:UIControlEventTouchUpInside];
        //sets the frame of the button to the size of the image
        buttonAdd.frame = CGRectMake(0, 0, 20, 20);
        //creates a UIBarButtonItem with the button as a custom view
        UIBarButtonItem *addLanguageButton = [[UIBarButtonItem alloc] initWithCustomView:buttonAdd];
        
        self.navigationItem.rightBarButtonItem=addLanguageButton;
        self.navigationItem.leftBarButtonItem=nil;
        
        [self.view endEditing:YES]; //keyboard goes out
        [self moveMenuAdd:AddView duration:0.2 curve:UIViewAnimationCurveEaseOut x:-self.view.frame.size.width y:0.0];

        
    }
    else
    {
        [self.view addSubview:AddView];
        
        [self setTitleNav:@"New List"];

        
        [self moveMenuAdd:AddView duration:0.2 curve:UIViewAnimationCurveEaseOut x:0.0 y:0.0];
        
        menuFlag = FALSE;
        
        [self.navigationController setToolbarHidden:YES animated:YES];
        scrollOfAddMenu.frame=CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height);
        
        
        
        //button for cancel
        UIButton *editCell1 = [UIButton buttonWithType:UIButtonTypeRoundedRect];
        [editCell1 setTitle:@"Cancel" forState:UIControlStateNormal];
        [editCell1 setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
        [editCell1 setTintColor:[UIColor redColor]];
        editCell1.titleLabel.font= [UIFont fontWithName:@"GillSans" size:16.0];
        
        [editCell1 addTarget:self action:@selector(openMenuAdd:) forControlEvents:UIControlEventTouchUpInside];
        CGRect buttonCancel= CGRectMake(0, 0, 60, 34);
        [editCell1 setFrame:buttonCancel];
        
        UIBarButtonItem *cancellLanguageButton= [[UIBarButtonItem alloc] initWithCustomView:editCell1];
        
        self.navigationItem.rightBarButtonItem=cancellLanguageButton;
        
        
        
        //button for saving
        
        UIButton *saving = [UIButton buttonWithType:UIButtonTypeRoundedRect];
        [saving setTitle:@"Save" forState:UIControlStateNormal];
        [saving setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
        [saving setTintColor:[UIColor greenColor]];
        saving.titleLabel.font= [UIFont fontWithName:@"GillSans" size:16.0];
        
        [saving addTarget:self action:@selector(addNewListInDataBase) forControlEvents:UIControlEventTouchUpInside];
        CGRect savingFrame= CGRectMake(0, 0, 55, 34);
        [saving setFrame:savingFrame];
        
        UIBarButtonItem *guardarButton= [[UIBarButtonItem alloc] initWithCustomView:saving];
        
        self.navigationItem.leftBarButtonItem=guardarButton; //aqui que añadir la forma de salvar la info modificada de info
        
        [nombreListaNueva becomeFirstResponder]; //keyboard goes out
        
        
    }
}

- (void)moveMenuAdd:(UIView *)menuView duration:(NSTimeInterval)duration curve:(int)curve x:(CGFloat)x y:(CGFloat)y
{
    //NSLog(@"hi");
    
    [self.view bringSubviewToFront:AddView];

    
    [UIView animateWithDuration:duration
                          delay:0.0f
                        options:curve
                     animations:^{
                         CGRect menuFrame = AddView.frame;
                         menuFrame.origin.x = x;
                         menuFrame.origin.y = y;
                         menuView.frame = menuFrame;
                         
                         //  NSLog(@"%f",x);
                         //  NSLog(@"%f",y);
                         
                     }
                     completion:nil];
    
    UIImage *buttonImage = [UIImage imageNamed:@"back2.png"];
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button setImage:buttonImage forState:UIControlStateNormal];
    button.frame = CGRectMake(0, 0, 65, 38);
    [button addTarget:self action:@selector(back) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *customBarItem = [[UIBarButtonItem alloc] initWithCustomView:button];
    self.navigationItem.leftBarButtonItem = customBarItem;
}



/*---------------------------------------------------------------------------
 * Menu Search moving
 *--------------------------------------------------------------------------*/

- (void)openMenuSearch:(id)sender
{
    // Move the menu view
    if (menuFlagSearch == FALSE)
    {
        
        [self setTitleNav:lenguaLista];

        
        menuFlagSearch = TRUE;

        
        [self getingBackDictionarySeach];
        
        searchBar.text=@"";
        
        [self.view bringSubviewToFront:searchView];
        
        //button for saving up-left
        UIImage *buttonAddImage = [UIImage imageNamed:@"addAlexVocabularioGris.png"];
        //create the button and assign the image
        UIButton *buttonAdd = [UIButton buttonWithType:UIButtonTypeCustom];
        [buttonAdd setImage:buttonAddImage forState:UIControlStateNormal];
        [buttonAdd addTarget:self action:@selector(openMenuAdd:) forControlEvents:UIControlEventTouchUpInside];
        //sets the frame of the button to the size of the image
        buttonAdd.frame = CGRectMake(0, 0, 20, 20);
        //creates a UIBarButtonItem with the button as a custom view
        UIBarButtonItem *addLanguageButton = [[UIBarButtonItem alloc] initWithCustomView:buttonAdd];
        
        self.navigationItem.rightBarButtonItem=addLanguageButton;
        self.navigationItem.leftBarButtonItem=nil;
        
        [self.view endEditing:YES]; //keyboard goes out
        
        [self.navigationController setToolbarHidden:NO animated:YES];
        
        // BOOL navBarState = [self.navigationController isNavigationBarHidden];
        // [self.navigationController setNavigationBarHidden:!navBarState animated:YES];
        
        [self moveMenuSearch:searchView duration:0.2 curve:UIViewAnimationCurveEaseOut x:0.0 y:self.view.frame.size.height];
    }
    else
    {
        /*---------------------------------------------------------------------------
         * llamar a funcion para cambiar el array que dirige el tableview
         *--------------------------------------------------------------------------*/
      //  [self deletingArrayWords]; *****************************

        dictionaryWords= [dao getDictionarForSearch];


        [self deletingDictionarySearch];

        
        [self.view addSubview:searchView];
        
        [self setTitleNav:@"Search"];

        
        
        [self moveMenuSearch:searchView duration:0.2 curve:UIViewAnimationCurveEaseOut x:0.0 y:0.0];
        
        menuFlagSearch = FALSE;
        
       // NSLog(@"menuFlagSearch: %i", menuFlagSearch);

        [tableViewSearch reloadData];

        [searchBar becomeFirstResponder];
        
        //BOOL navBarState = [self.navigationController isNavigationBarHidden];
        //[self.navigationController setNavigationBarHidden:!navBarState animated:YES];
        
        
        [self.navigationController setToolbarHidden:YES animated:YES];
        
        
        //button for saving up-left
        UIButton *editCell1 = [UIButton buttonWithType:UIButtonTypeRoundedRect];
        [editCell1 setTitle:@"Cancel" forState:UIControlStateNormal];
        [editCell1 setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
        [editCell1 setTintColor:[UIColor redColor]];
        editCell1.titleLabel.font= [UIFont fontWithName:@"GillSans" size:16.0];
        
        [editCell1 addTarget:self action:@selector(openMenuSearch:) forControlEvents:UIControlEventTouchUpInside];
        CGRect buttonCancel= CGRectMake(0, 0, 60, 34);
        [editCell1 setFrame:buttonCancel];
        
        UIBarButtonItem *cancellLanguageButton= [[UIBarButtonItem alloc] initWithCustomView:editCell1];
        
        self.navigationItem.rightBarButtonItem=cancellLanguageButton;
        
        
        self.navigationItem.leftBarButtonItem=nil;
        [self.navigationItem setHidesBackButton:YES];


        
        
        
        
    }
}



- (void)moveMenuSearch:(UIView *)menuView duration:(NSTimeInterval)duration curve:(int)curve x:(CGFloat)x y:(CGFloat)y
{
    //NSLog(@"hi");
    
    [UIView animateWithDuration:duration
                          delay:0.0f
                        options:curve
                     animations:^{
                         CGRect menuFrame = searchView.frame;
                         menuFrame.origin.x = x;
                         menuFrame.origin.y = y;
                         menuView.frame = menuFrame;
                         
                         //  NSLog(@"%f",x);
                         //  NSLog(@"%f",y);
                         
                     }
                     completion:nil];
    
    UIImage *buttonImage = [UIImage imageNamed:@"back2.png"];
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button setImage:buttonImage forState:UIControlStateNormal];
    button.frame = CGRectMake(0, 0, 65, 38);
    [button addTarget:self action:@selector(back) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *customBarItem = [[UIBarButtonItem alloc] initWithCustomView:button];
    self.navigationItem.leftBarButtonItem = customBarItem;
}

- (void) editingCell{
    
    
    if (tableViewLista.editing==NO) {
        [tableViewLista setEditing:YES animated:YES];
        
        UIImage *buttonSearchImage = [UIImage imageNamed:@"searchAlexVocabularioGris.png"];
        //create the button and assign the image
        UIButton *buttonSearch = [UIButton buttonWithType:UIButtonTypeCustom];
        [buttonSearch setImage:buttonSearchImage forState:UIControlStateNormal];
        [buttonSearch addTarget:self action:@selector(openMenuSearch:) forControlEvents:UIControlEventTouchUpInside];
        //sets the frame of the button to the size of the image
        buttonSearch.frame = CGRectMake(0, 0, 22, 22);
        //creates a UIBarButtonItem with the button as a custom view
        UIBarButtonItem *searchButton = [[UIBarButtonItem alloc] initWithCustomView:buttonSearch];
        
        
        UIButton *buttonEdit = [UIButton buttonWithType:UIButtonTypeRoundedRect];
        [buttonEdit setTitle:@"Cancel" forState:UIControlStateNormal];
        [buttonEdit setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
        [buttonEdit setTintColor:[UIColor darkGrayColor]];
        buttonEdit.titleLabel.font= [UIFont fontWithName:@"GillSans" size:16.0];
        
        [buttonEdit addTarget:self action:@selector(editingCell) forControlEvents:UIControlEventTouchUpInside];
        CGRect buttonEditFrame= CGRectMake(0, 0, 60, 34);
        [buttonEdit setFrame:buttonEditFrame];
        
        //UIBarButtonItem *editCell = [[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemEdit target:self action:@selector(editingCell)];
        
        UIBarButtonItem *editCell = [[UIBarButtonItem alloc] initWithCustomView:buttonEdit];
        
        
        UIBarButtonItem *flexibaleSpaceBarButton = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
        
        self.toolbarItems = [NSArray arrayWithObjects:searchButton, flexibaleSpaceBarButton,editCell, nil];
        
    }else{
        [tableViewLista setEditing:NO animated:YES];
        
        /*---------------------------------------------------------------------------
         * toolbar items
         *--------------------------------------------------------------------------*/
        
        UIImage *buttonSearchImage = [UIImage imageNamed:@"searchAlexVocabularioGris.png"];
        //create the button and assign the image
        UIButton *buttonSearch = [UIButton buttonWithType:UIButtonTypeCustom];
        [buttonSearch setImage:buttonSearchImage forState:UIControlStateNormal];
        [buttonSearch addTarget:self action:@selector(openMenuSearch:) forControlEvents:UIControlEventTouchUpInside];
        //sets the frame of the button to the size of the image
        buttonSearch.frame = CGRectMake(0, 0, 22, 22);
        //creates a UIBarButtonItem with the button as a custom view
        UIBarButtonItem *searchButton = [[UIBarButtonItem alloc] initWithCustomView:buttonSearch];
        
        
        UIButton *buttonEdit = [UIButton buttonWithType:UIButtonTypeRoundedRect];
        [buttonEdit setTitle:@"Edit" forState:UIControlStateNormal];
        [buttonEdit setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
        [buttonEdit setTintColor:[UIColor darkGrayColor]];
        buttonEdit.titleLabel.font= [UIFont fontWithName:@"GillSans" size:16.0];
        
        [buttonEdit addTarget:self action:@selector(editingCell) forControlEvents:UIControlEventTouchUpInside];
        CGRect buttonEditFrame= CGRectMake(0, 0, 50, 34);
        [buttonEdit setFrame:buttonEditFrame];
        
        //UIBarButtonItem *editCell = [[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemEdit target:self action:@selector(editingCell)];
        
        UIBarButtonItem *editCell = [[UIBarButtonItem alloc] initWithCustomView:buttonEdit];
        
        
        UIBarButtonItem *flexibaleSpaceBarButton = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
        
        self.toolbarItems = [NSArray arrayWithObjects:searchButton, flexibaleSpaceBarButton,editCell, nil];
        
        
    }
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
    return [NSArray arrayWithArray:dictionaryList.allKeys] ;
    
}

- (NSArray *)sectionIndexTitlesForTableView:(UITableView *)tableView
{
    if (menuFlagSearch==TRUE) { //if the menu search is not on we have research
        NSArray *arrayletters = [[NSArray alloc]init];
        arrayletters= [dao getAlphabet:languageID];
        
        return arrayletters;
    }else{
        return nil;
    }
    

}
/*

- (NSInteger)tableView:(UITableView *)tableView sectionForSectionIndexTitle:(NSString *)title atIndex:(NSInteger)index
{
    return [[UILocalizedIndexedCollation currentCollation] sectionForSectionIndexTitleAtIndex:index];
}*/


#pragma mark - Table view delegate

/*- (void)tableView:(UITableView *)tableView willSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    NSLog(@"hola que tal, no hago nada");
    
}
*/

- (void) openMenuInfoGest:(UILongPressGestureRecognizer *)gestureRecognizer{
    NSLog(@"hola");
    
    if (menuFlagAlpha==TRUE) {
        menuFlagInfo=TRUE;
        [self openMenuInfo:nil];
    }



}

- (void) tableView:(UITableView *)tableView didHighlightRowAtIndexPath:(NSIndexPath *)indexPath{
    NSLog(@"hi men");
    
    menuFlagAlpha=TRUE;
    
    if (menuFlagSearch==TRUE) {

    
        NSSortDescriptor* sortDescriptor = [NSSortDescriptor sortDescriptorWithKey:nil ascending:YES selector:@selector(localizedCompare:)];
        NSArray* sortedCategories = [dictionaryList.allKeys sortedArrayUsingDescriptors:[NSArray arrayWithObject:sortDescriptor]];
    
        NSString *categoryName = [sortedCategories objectAtIndex:indexPath.section];
    
        NSArray *currentCategory = [dictionaryList objectForKey:categoryName];
    
        // NSLog(@"CurrentCategory: %@", currentCategory);
    
        NSDictionary *currentList = [currentCategory objectAtIndex:indexPath.row];
        //NSLog(@"currentList: %@", currentList);
    
        NSString *pepe = [currentList valueForKey:@"listId"];
        listID = [pepe integerValue];
    
        nombreLista.text=[currentList valueForKey:@"listaDeTipos"];
        infoText.text=[currentList valueForKey:@"comentarios"];
        
    }
    
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    [tableView deselectRowAtIndexPath:indexPath animated:YES]; // for not leaving the color after choosing the cell

    if (menuFlagSearch==TRUE) { //es decir, no esta en pantalla searchView
        NSSortDescriptor* sortDescriptor = [NSSortDescriptor sortDescriptorWithKey:nil ascending:YES selector:@selector(localizedCompare:)];
        NSArray* sortedCategories = [dictionaryList.allKeys sortedArrayUsingDescriptors:[NSArray arrayWithObject:sortDescriptor]];
        
        NSString *categoryName = [sortedCategories objectAtIndex:indexPath.section];
        
        NSArray *currentCategory = [dictionaryList objectForKey:categoryName];
        
       // NSLog(@"CurrentCategory: %@", currentCategory);
        
        NSDictionary *currentList = [currentCategory objectAtIndex:indexPath.row];
    //    NSLog(@"currentList: %@", currentList);
        
        NSString *pepe = [currentList valueForKey:@"listId"];
        listID = [pepe integerValue];
        
        if (menuFlagInfo==TRUE) {
           /*
            NSSortDescriptor* sortDescriptor = [NSSortDescriptor sortDescriptorWithKey:nil ascending:YES selector:@selector(localizedCompare:)];
            NSArray* sortedCategories = [dictionaryList.allKeys sortedArrayUsingDescriptors:[NSArray arrayWithObject:sortDescriptor]];
            
            NSString *categoryName = [sortedCategories objectAtIndex:indexPath.section];
            
            NSArray *currentCategory = [dictionaryList objectForKey:categoryName];
            
           // NSLog(@"CurrentCategory: %@", currentCategory);
            
            NSDictionary *currentList = [currentCategory objectAtIndex:indexPath.row];
            //NSLog(@"currentList: %@", currentList);
            
            NSString *pepe = [currentList valueForKey:@"listId"];
            listID = [pepe integerValue];
            
            nombreLista.text=[currentList valueForKey:@"listaDeTipos"];
            infoText.text=[currentList valueForKey:@"comentarios"];
            */
            
            
        }else{
            
            
            
            WordsViewController *destino = [self.storyboard instantiateViewControllerWithIdentifier:@"words"];
            //destino *tmp = [vehiculos objectAtIndex:[indexPath row]];
            destino.lenguaLista = lenguaLista;
            destino.lenguaMaster= lenguaMaster;
            destino.listaOriginId = listID;
            destino.languageID = languageID;
            
            NSSortDescriptor* sortDescriptor = [NSSortDescriptor sortDescriptorWithKey:nil ascending:YES selector:@selector(localizedCompare:)];
            NSArray* sortedCategories = [dictionaryList.allKeys sortedArrayUsingDescriptors:[NSArray arrayWithObject:sortDescriptor]];
            
            NSString *categoryName = [sortedCategories objectAtIndex:indexPath.section];
            
            NSArray *currentCategory = [dictionaryList objectForKey:categoryName];
            
          //  NSLog(@"CurrentCategory: %@", currentCategory);
            
            NSDictionary *currentList = [currentCategory objectAtIndex:indexPath.row];
           // NSLog(@"currentList: %@", currentList);


            destino.lista =[currentList valueForKey:@"listaDeTipos"];

            
            //  escribirView.dates = [[notes objectAtIndex:indexPath.row]objectForKey:@"date"];
            
            
            [self.navigationController pushViewController:destino animated:YES];
            
            [InfoView removeFromSuperview];
            [InfoViewWords removeFromSuperview];
        }

    }else{ //if im searching
     
        NSSortDescriptor* sortDescriptor = [NSSortDescriptor sortDescriptorWithKey:nil ascending:YES selector:@selector(localizedCompare:)];
        NSArray* sortedCategories = [dictionaryWords.allKeys sortedArrayUsingDescriptors:[NSArray arrayWithObject:sortDescriptor]];
        
        NSString *categoryName = [sortedCategories objectAtIndex:indexPath.section];
        
        NSArray *currentCategory = [dictionaryWords objectForKey:categoryName];
        
        NSDictionary *currentWord = [currentCategory objectAtIndex:indexPath.row];
        
        infoWord1.text = [currentWord valueForKey:@"word1"];
        infoWord2.text = [currentWord valueForKey:@"word2"];
        infoTextWords.text=[currentWord valueForKey:@"comments"];
        
        idiomaMaster1.text= [currentWord valueForKey:@"languageMaster"];
        idiomaLearn1.text= [currentWord valueForKey:@"languageOrigin"];
        
        NSString *pepe = [currentWord valueForKey:@"wordId"];
        wordID = [pepe integerValue];
        
        

       // right.text = [currentWord valueForKey:@"word2"];
        [self openMenuInfoWords:nil];
        
        /*---------------------------------------------------------------------------
         * introduce the way i can modificate the word from the searchview
         *--------------------------------------------------------------------------*/


    }
}



- (void)viewWillDisappear:(BOOL)animated {
    [self.navigationController setToolbarHidden:NO animated:NO];
    
    
}


- (void) deletingDictionarySearch{
    
    NSLog(@"Estamos borrando");
    
    dictionaryWordsSupporter = [[NSMutableDictionary alloc]initWithDictionary:dictionaryWords];
    [dictionaryWords removeAllObjects];
    //[tableViewSearch reloadData]; //cleaning the tableview
    
    // NSLog(@"hola %@", arrayWordsSupporter);
    
    
}

- (void) getingBackDictionarySeach{
    
    //NSLog(@"Estamos arreglando");
    
    
    dictionaryWords = [NSMutableDictionary dictionaryWithDictionary :dictionaryWordsSupporter];
    [dictionaryWordsSupporter removeAllObjects];
    
    [tableViewLista reloadData];
    
    //NSLog(@"hola %@", arrayWords);
    
}

/*---------------------------------------------------------------------------
 * copiar esto en todas las busquedas grandes
 *--------------------------------------------------------------------------*/

- (void)delayedSearch {
    
    if ([searchBar.text isEqualToString:@""]) {
        [self performSelector:@selector(searchTabA:) withObject:nil];
    }else{
        [self performSelector:@selector(searchTabA:) withObject:nil afterDelay:0.9];
    }
}


- (void) textViewDidBeginEditing:(UITextView *)textView{
    
    CGPoint bottomOffset = CGPointMake(0, self.scrollOfInfoMenu.contentSize.height - self.scrollOfInfoMenu.bounds.size.height);
    [self.scrollOfInfoMenu setContentOffset:bottomOffset animated:YES];
    
    CGPoint bottomOffset1 = CGPointMake(0, self.scrollOfAddMenu.contentSize.height - self.scrollOfAddMenu.bounds.size.height);
    [self.scrollOfAddMenu setContentOffset:bottomOffset1 animated:YES];
    
    
    CGPoint bottomOffset2 = CGPointMake(0, self.scrollOfInfoMenuWords.contentSize.height - self.scrollOfInfoMenuWords.bounds.size.height);
    [self.scrollOfInfoMenuWords setContentOffset:bottomOffset2 animated:YES];
    
    
}


- (void) searchTabA:(id)sender{
    
    if ([searchBar.text length]==0) {
        
        [dictionaryWords removeAllObjects];
        [tableViewSearch reloadData];
        
        
    }else{
        
        [dictionaryWords removeAllObjects];
        
        for (int contListas=0; contListas<[dictionaryWordsSupporter.allKeys count]; contListas++) {
            NSMutableArray *arrayList = [[NSMutableArray alloc]init];

            
            NSSortDescriptor* sortDescriptor = [NSSortDescriptor sortDescriptorWithKey:nil ascending:YES selector:@selector(localizedCompare:)];
            NSArray* sortedCategories = [dictionaryWordsSupporter.allKeys sortedArrayUsingDescriptors:[NSArray arrayWithObject:sortDescriptor]];
            
            NSString *categoryName = [sortedCategories objectAtIndex:contListas];
            
            NSArray *currentCategory = [dictionaryWordsSupporter objectForKey:categoryName];
            
            NSLog(@"category name: %@", categoryName );
            
            for (int contWords=0; contWords<[currentCategory count]; contWords++) {
                
                NSLog(@"currectcategory: %d", [currentCategory count]);
                NSLog(@"%@", [[[dictionaryWordsSupporter objectForKey:categoryName]objectAtIndex:contWords]valueForKey:@"word1"]);
                
                NSString *word11= [[[dictionaryWordsSupporter objectForKey:categoryName]objectAtIndex:contWords ]valueForKey:@"word1"];
                NSString *word22=[[[dictionaryWordsSupporter objectForKey:categoryName]objectAtIndex:contWords ]valueForKey:@"word2"];                
                
                NSString *word1= [word11 lowercaseString];
                NSString *word2= [word22 lowercaseString];
                NSString *wordSearched= [searchBar.text lowercaseString];
            

            
            
                if (([word1 rangeOfString:wordSearched].location != NSNotFound) || ([word2 rangeOfString:wordSearched].location !=NSNotFound)) {
                
                     NSLog(@"Escribo: %@    comparado con word1: %@ y word2: %@", wordSearched, word1, word2);
                
                    // NSLog(@"array cont: %d", [arrayWords count]);
                
                    [arrayList addObject:[[dictionaryWordsSupporter objectForKey:categoryName]objectAtIndex:contWords ]];
                
                } else {
                
                
                }//end of title comparason
            
            }//end for words
            
            if ([arrayList count]!=0) {
                [dictionaryWords setObject:arrayList forKey: categoryName];

            }
            

        
        }//end of the for listas
        
        [tableViewSearch reloadData];
        
    }//end of the if I push the textField
    
}//end of searchTab


@end