//
//  objectWord.m
//  Vocabulario
//
//  Created by Alejandro Delgado Diaz on 31/03/13.
//  Copyright (c) 2013 Alejandro. All rights reserved.
//

#import "objectWord.h"

@implementation objectWord

@synthesize word1, word2, languageMaster, languageOrigin, comments, wordId, listOriginId;

@end
