//
//  wordDAO.m
//  Vocabulario
//
//  Created by Alejandro Delgado Diaz on 31/03/13.
//  Copyright (c) 2013 Alejandro. All rights reserved.
//

#import "wordDAO.h"
#import "objectWord.h"

@implementation wordDAO
//@synthesize languageLista;
//@synthesize listaWords;




- (NSString *) getPathDataBase{
    NSString *dirDocs;
    NSArray *rutas;
    NSString *rutaBD;
    
    rutas = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    dirDocs = [rutas objectAtIndex:0];
    
    NSFileManager *fileMgr = [NSFileManager defaultManager];
    rutaBD = [[NSString alloc] initWithString:[dirDocs stringByAppendingPathComponent:@"myVocabulario.sqlite"]];
    
    if([fileMgr fileExistsAtPath:rutaBD] == NO){
        [fileMgr copyItemAtPath:[[[NSBundle mainBundle] resourcePath] stringByAppendingPathComponent:@"myVocabulario.sqlite"] toPath:rutaBD error:NULL];
    }
    
    return rutaBD;
}

- (NSMutableArray *) getListOfWords: (NSInteger)listOriginId{
    
    
	NSMutableArray *arrayWords = [[NSMutableArray alloc] init];
	NSString *ubicacionDB = [self getPathDataBase];
	
	if(!(sqlite3_open([ubicacionDB UTF8String], &dataBase) == SQLITE_OK)){
		NSLog(@"No se puede conectar con la BD");
	}
    
	NSString *sentenciaSQL = [NSString stringWithFormat:@"SELECT word1, word2, comments, rowid FROM words WHERE listOriginId = '%d'", listOriginId] ;
	
    const char *sql = [sentenciaSQL UTF8String];
    
    sqlite3_stmt *sqlStatement;
	
	if(sqlite3_prepare_v2(dataBase, sql, -1, &sqlStatement, NULL) != SQLITE_OK){
		NSLog(@"Problema al preparar el statement");
      //  NSLog(@"HOLA");
	}
	
	while(sqlite3_step(sqlStatement) == SQLITE_ROW){
		objectWord *word = [[objectWord alloc] init];
		word.word1 = [NSString stringWithUTF8String:(char *) sqlite3_column_text(sqlStatement, 0)];
        word.word2 = [NSString stringWithUTF8String:(char *) sqlite3_column_text(sqlStatement, 1)];
		word.comments = [NSString stringWithUTF8String:(char *) sqlite3_column_text(sqlStatement, 2)];
        word.wordId = sqlite3_column_int(sqlStatement, 3);
        
        //NSLog(@"%i", word.wordId);

        
		[arrayWords addObject:word];
	}
	
	return arrayWords;
}

- (void) addWord:(NSString *)word1 word2:(NSString *)word2 lengua:(NSString *)lengua lista:(NSString *)lista comments:(NSString *)comments listOriginId:(NSInteger)listOriginId languageMaster:(NSString *)languageMaster languageID:(NSInteger)languageID{
	NSString *ubicacionDB = [self getPathDataBase];
	
	if(!(sqlite3_open([ubicacionDB UTF8String], &dataBase) == SQLITE_OK)){
		NSLog(@"No se puede conectar con la BD");
		return;
	} else {
        
      //  NSLog(@"('%@', '%@','%@','%@','%@','%@','%d')", lengua, lista, word1, word2, comments, languageMaster, listOriginId);
        
		NSString *sqlInsert = [NSString stringWithFormat:@"INSERT INTO words (language, nameList, word1, word2, comments, languageMaster, listOriginId, languageID) VALUES ('%@', '%@','%@','%@','%@','%@','%d','%d')", lengua, lista, word1, word2, comments, languageMaster, listOriginId, languageID];
		const char *sql = [sqlInsert UTF8String];
		sqlite3_stmt *sqlStatement;
		
		if(sqlite3_prepare_v2(dataBase, sql, -1, &sqlStatement, NULL) != SQLITE_OK){
			NSLog(@"Problema al preparar el statement");
			return;
		} else {
			if(sqlite3_step(sqlStatement) == SQLITE_DONE){
				sqlite3_finalize(sqlStatement);
				sqlite3_close(dataBase);
			}
		}
		
	}
    
}

- (void) modWord:(NSString *)word1 word2:(NSString *)word2 lengua:(NSString *)lengua lista:(NSString *)lista comments:(NSString *)comments wordID:(NSInteger)wordID{
    
   // NSLog(@"HOLA");
   // NSLog(@"%d", wordID);
    
    NSString *ubicacionBD = [self getPathDataBase];
	
	if(!(sqlite3_open([ubicacionBD UTF8String], &dataBase) == SQLITE_OK)){
		NSLog(@"No se puede conectar con la BD");
		return;
	} else {
		NSString *sqlUpdate = [NSString stringWithFormat:@"UPDATE words SET word1 = '%@', word2 = '%@', comments ='%@' WHERE rowid = %d", word1, word2, comments, wordID];
		const char *sql = [sqlUpdate UTF8String];
		sqlite3_stmt *sqlStatement;
		
		if(sqlite3_prepare_v2(dataBase, sql, -1, &sqlStatement, NULL) != SQLITE_OK){
			NSLog(@"Problema al preparar el statement.");
			return;
		} else {
			if(sqlite3_step(sqlStatement) == SQLITE_DONE){
				sqlite3_finalize(sqlStatement);
				sqlite3_close(dataBase);
			}
		}
	}
}

- (void) deleteWord:(NSInteger) wordID{
	//NSLog(@"a borrar");
    
    NSString *ubicacionBD = [self getPathDataBase];
    
	
	if(!(sqlite3_open([ubicacionBD UTF8String], &dataBase) == SQLITE_OK)){
		NSLog(@"No se puede conectar con la BD");
		return;
	} else {
		NSString *sqlDelete = [NSString stringWithFormat:@"DELETE FROM words WHERE rowid = %d", wordID];
		const char *sql = [sqlDelete UTF8String];
		sqlite3_stmt *sqlStatement;
		
		if(sqlite3_prepare_v2(dataBase, sql, -1, &sqlStatement, NULL) != SQLITE_OK){
			NSLog(@"Problema al preparar el statement.");
			return;
		} else {
			if(sqlite3_step(sqlStatement) == SQLITE_DONE){
				sqlite3_finalize(sqlStatement);
				sqlite3_close(dataBase);
			}
		}
	}
}
	
    
@end