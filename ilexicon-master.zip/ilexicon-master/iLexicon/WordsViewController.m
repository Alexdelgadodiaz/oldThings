//
//  WordsViewController.m
//  Vocabulario
//
//  Created by Alejandro Delgado Diaz on 31/03/13.
//  Copyright (c) 2013 Alejandro. All rights reserved.
//


/*---------------------------------------------------------------------------
 *
 *--------------------------------------------------------------------------*/


#import "WordsViewController.h"
#import "wordDAO.h"

@interface WordsViewController ()

@end

@implementation WordsViewController

@synthesize arrayWords, arrayWordsSupporter;
@synthesize dao;
@synthesize tableViewWords, tableViewSearch;
@synthesize lenguaLista, lenguaMaster;
@synthesize lista, listaOriginId, languageID;
@synthesize AddView, InfoView, searchView;
@synthesize menuFlag, menuFlagSearch;
@synthesize aNewWord1, aNewWord2, infoWord1, infoWord2, infoText, addText;
@synthesize wordID;
@synthesize scrollOfAddMenu, scrollOfInfoMenu;
@synthesize searchBar;
@synthesize menuAddView, menuInfoView;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

-(void)back {
    
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)viewDidLoad
{
   // NSLog(@"Lenguage i wanna learn, %@", lenguaLista);
    
    [self setTitleNav:lista];
    
    arrayWords = [[NSMutableArray alloc]init];
    
    dao = [[wordDAO alloc]init];
    // arrayWords = [dao getListOfWords:lenguaLista lista:lista];
    menuFlag=TRUE;
    menuFlagSearch=TRUE;

    
    [super viewDidLoad];
    
    UIImage *buttonImage = [UIImage imageNamed:@"back2.png"];
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button setImage:buttonImage forState:UIControlStateNormal];
    button.frame = CGRectMake(0, 0, 65, 38);
    [button addTarget:self action:@selector(back) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *customBarItem = [[UIBarButtonItem alloc] initWithCustomView:button];
    self.navigationItem.leftBarButtonItem = customBarItem;
    
    
    UITapGestureRecognizer *gestureRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(hideKeyboard)];
    gestureRecognizer.cancelsTouchesInView = NO;
    gestureRecognizer.numberOfTouchesRequired=1;
    [self.view addGestureRecognizer:gestureRecognizer];
    
    //button for saving up-left
    UIImage *buttonAddImage = [UIImage imageNamed:@"addAlexVocabularioGris.png"];
    //create the button and assign the image
    UIButton *buttonAdd = [UIButton buttonWithType:UIButtonTypeCustom];
    [buttonAdd setImage:buttonAddImage forState:UIControlStateNormal];
    [buttonAdd addTarget:self action:@selector(openMenuAdd:) forControlEvents:UIControlEventTouchUpInside];
    //sets the frame of the button to the size of the image
    buttonAdd.frame = CGRectMake(0, 0, 20, 20);
    //creates a UIBarButtonItem with the button as a custom view
    UIBarButtonItem *addLanguageButton = [[UIBarButtonItem alloc] initWithCustomView:buttonAdd];
    
    self.navigationItem.rightBarButtonItem=addLanguageButton;
    
    
    
    /*---------------------------------------------------------------------------
     * toolbar items
     *--------------------------------------------------------------------------*/
    
    UIImage *buttonSearchImage = [UIImage imageNamed:@"searchAlexVocabularioGris.png"];
    //create the button and assign the image
    UIButton *buttonSearch = [UIButton buttonWithType:UIButtonTypeCustom];
    [buttonSearch setImage:buttonSearchImage forState:UIControlStateNormal];
    [buttonSearch addTarget:self action:@selector(openMenuSearch:) forControlEvents:UIControlEventTouchUpInside];
    //sets the frame of the button to the size of the image
    buttonSearch.frame = CGRectMake(0, 0, 22, 22);
    //creates a UIBarButtonItem with the button as a custom view
    UIBarButtonItem *searchButton = [[UIBarButtonItem alloc] initWithCustomView:buttonSearch];
    
    UIButton *buttonEdit = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    [buttonEdit setTitle:@"Edit" forState:UIControlStateNormal];
    [buttonEdit setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
    [buttonEdit setTintColor:[UIColor darkGrayColor]];
    buttonEdit.titleLabel.font= [UIFont fontWithName:@"GillSans" size:16.0];
    
    [buttonEdit addTarget:self action:@selector(editingCell) forControlEvents:UIControlEventTouchUpInside];
    CGRect buttonEditFrame= CGRectMake(0, 0, 50, 34);
    [buttonEdit setFrame:buttonEditFrame];
    
    //UIBarButtonItem *editCell = [[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemEdit target:self action:@selector(editingCell)];
    
    UIBarButtonItem *editCell = [[UIBarButtonItem alloc] initWithCustomView:buttonEdit];
    
    
    UIBarButtonItem *flexibaleSpaceBarButton = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
    
    self.toolbarItems = [NSArray arrayWithObjects:searchButton, flexibaleSpaceBarButton,editCell, nil];
    
    
    
    
    
    tableViewWords=[[UITableView alloc] initWithFrame:(CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height-86)) style:UITableViewStylePlain];
    tableViewWords.delegate=self;
    tableViewWords.dataSource = self;
    tableViewWords.rowHeight = 32;
    tableViewWords.bounces=YES;
    //tableView.backgroundColor=[UIColor colorWithCGColor:whiteColorApp];
    tableViewWords.clipsToBounds=YES;
    tableViewWords.scrollsToTop=NO;
    // [tableView setSectionIndexColor:[UIColor redColor]];
   // [self.view addSubview:tableViewWords];

    
    /*---------------------------------------------------------------------------
     * add View
     *--------------------------------------------------------------------------*/
    
    AddView=[[UIView alloc]init];
    AddView.frame=CGRectMake(-self.view.frame.size.width, 0, self.view.frame.size.width, self.view.frame.size.height);
    AddView.backgroundColor=[UIColor whiteColor];
    
    scrollOfAddMenu = [[UIScrollView alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height)];
    scrollOfAddMenu.contentSize= CGSizeMake(self.view.frame.size.width, self.view.frame.size.height-44);
    scrollOfAddMenu.backgroundColor = [UIColor whiteColor];
    //self.scrollView.contentInset = UIEdgeInsetsMake(vOffset, hOffset, 0, 0);
    scrollOfAddMenu.showsVerticalScrollIndicator = YES;    // to hide scroll indicators!
    scrollOfAddMenu.scrollEnabled = YES;
    //textField.delegate = self;              //use this when ur using Delegate methods of UITextField
    [AddView addSubview:scrollOfAddMenu];
    
    menuAddView=[[UIView alloc]init];
    menuAddView.frame=CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height-44);
    menuAddView.backgroundColor=[UIColor whiteColor];
    [scrollOfAddMenu addSubview:menuAddView];

    
    /*UILabel *tituloAddWords = [[UILabel alloc]init];
    tituloAddWords.text=@"New word";
    tituloAddWords.backgroundColor=[UIColor clearColor];
    tituloAddWords.frame=CGRectMake(5, 9, 100, 24);
    [menuAddView addSubview:tituloAddWords];
    */
    
    


    
    UILabel *idiomaLearn = [[UILabel alloc]initWithFrame:CGRectMake(15, 10, self.view.frame.size.width-30, 30)];
    
    idiomaLearn.text=lenguaMaster;
    idiomaLearn.font=[UIFont fontWithName:@"GillSans" size:25.0];
    idiomaLearn.textColor= [UIColor grayColor];
    idiomaLearn.backgroundColor=[UIColor clearColor];
    idiomaLearn.textAlignment=NSTextAlignmentLeft;
    [menuAddView addSubview:idiomaLearn];
    
    
    

    
    aNewWord1=[[UITextField alloc]initWithFrame:CGRectMake(10, 45, self.view.frame.size.width-20, 38)];
    aNewWord1.placeholder = @"You know";
    [aNewWord1 setValue:[UIColor lightTextColor] forKeyPath:@"_placeholderLabel.textColor"];
    aNewWord1.font = [UIFont fontWithName:@"GillSans" size:25.0]; // text font
    aNewWord1.adjustsFontSizeToFitWidth = YES;     //adjust the font size to fit width.
    aNewWord1.borderStyle= UITextBorderStyleRoundedRect;
    aNewWord1.backgroundColor=[UIColor darkGrayColor];
    aNewWord1.textColor = [UIColor whiteColor];             //text color
    aNewWord1.textAlignment=NSTextAlignmentLeft;
    aNewWord1.clearButtonMode = UITextFieldViewModeAlways;//for clear button on right side
    
    
    [menuAddView addSubview:aNewWord1];
    /*
    UILabel *explicacionNewWord1= [[UILabel alloc]initWithFrame:CGRectMake(15, 75, self.view.frame.size.width-30, 30)];
    explicacionNewWord1.text=@"*Put here a word you know in the language you know";
    explicacionNewWord1.font=[UIFont fontWithName:@"GillSans" size:13.0];
    explicacionNewWord1.textColor= [UIColor grayColor];
    explicacionNewWord1.backgroundColor= [UIColor clearColor];
    explicacionNewWord1.textAlignment=NSTextAlignmentLeft;
    
    [menuAddView addSubview:explicacionNewWord1];
    */
    
    UILabel *idiomaMaster = [[UILabel alloc]initWithFrame:CGRectMake(15, 110, self.view.frame.size.width-30, 30)];
    idiomaMaster.text=lenguaLista;
    idiomaMaster.font=[UIFont fontWithName:@"GillSans" size:25.0];
    idiomaMaster.textColor= [UIColor grayColor];
    idiomaMaster.backgroundColor=[UIColor clearColor];
    idiomaMaster.textAlignment=NSTextAlignmentLeft;
    
    [menuAddView addSubview:idiomaMaster];
    
    
    aNewWord2=[[UITextField alloc]initWithFrame:CGRectMake(10, 145, self.view.frame.size.width-20, 38)];
    aNewWord2.placeholder = @"You don't know yet";
    [aNewWord2 setValue:[UIColor lightTextColor] forKeyPath:@"_placeholderLabel.textColor"];
    aNewWord2.font = [UIFont fontWithName:@"GillSans" size:25.0]; // text font
    aNewWord2.adjustsFontSizeToFitWidth = YES;     //adjust the font size to fit width.
    aNewWord2.borderStyle= UITextBorderStyleRoundedRect;
    aNewWord2.backgroundColor=[UIColor darkGrayColor];
    aNewWord2.textColor = [UIColor whiteColor];             //text color
    aNewWord2.textAlignment=NSTextAlignmentLeft;
    aNewWord2.clearButtonMode = UITextFieldViewModeAlways;//for clear button on right side

    [menuAddView addSubview:aNewWord2];
    /*
    UILabel *explicacionNewWord2= [[UILabel alloc]initWithFrame:CGRectMake(15, 175, self.view.frame.size.width-30, 30)];
    explicacionNewWord2.text=@"*Put here the word you want to learn";
    explicacionNewWord2.font=[UIFont fontWithName:@"GillSans" size:13.0];
    explicacionNewWord2.textColor= [UIColor grayColor];
    explicacionNewWord2.backgroundColor= [UIColor clearColor];
    explicacionNewWord2.textAlignment=NSTextAlignmentLeft;
    
    [menuAddView addSubview:explicacionNewWord2];
    */
    UILabel *labelNote= [[UILabel alloc]initWithFrame:CGRectMake(30, 210, self.view.frame.size.width-30, 30)];
    labelNote.text=@"Notes";
    labelNote.font=[UIFont fontWithName:@"GillSans" size:25.0];
    labelNote.textColor= [UIColor grayColor];
    labelNote.backgroundColor= [UIColor clearColor];
    labelNote.textAlignment=NSTextAlignmentLeft;
    
    [menuAddView addSubview:labelNote];
    
    
    addText=[[UITextView alloc]initWithFrame:CGRectMake(30, 250, self.view.frame.size.width-60, self.view.frame.size.height-320)];
    //text.frame=CGRectMake(0, 42, self.view.frame.size.width, self.view.frame.size.height-48);
    //originalTextViewFrame=CGRectMake(3, 55, self.view.frame.size.width-6, self.view.frame.size.height-100);
    //text.backgroundColor= [UIColor colorWithCGColor:];
    addText.font=[UIFont fontWithName:@"GillSans" size:18.0];
    addText.textColor=[UIColor whiteColor];
    addText.backgroundColor=[UIColor darkGrayColor];
    addText.clipsToBounds = YES;
    addText.scrollsToTop=YES;
    addText.bounces=NO;
    addText.delegate=self;
    
    

    [menuAddView addSubview:addText];
    
    /*---------------------------------------------------------------------------
     * Search View
     *--------------------------------------------------------------------------*/
    
    searchView=[[UIView alloc]init];
    searchView.frame=CGRectMake(0, self.view.frame.size.height, self.view.frame.size.width, self.view.frame.size.height);
    searchView.backgroundColor=[UIColor whiteColor];
    
    searchBar = [[UITextField alloc] initWithFrame:CGRectMake(2, 2, self.view.frame.size.width-4, 32)];
    searchBar.placeholder = @"Search...";   //for place holder
    [searchBar setValue:[UIColor whiteColor] forKeyPath:@"_placeholderLabel.textColor"];
    searchBar.font = [UIFont fontWithName:@"GillSans" size:20.0]; // text font
    searchBar.adjustsFontSizeToFitWidth = YES;     //adjust the font size to fit width.
    searchBar.borderStyle= UITextBorderStyleRoundedRect;
    searchBar.backgroundColor=[UIColor darkGrayColor];
    searchBar.textColor = [UIColor whiteColor];             //text color
    searchBar.textAlignment=NSTextAlignmentLeft;
    searchBar.clearButtonMode = UITextFieldViewModeAlways;//for clear button on right side
    searchBar.returnKeyType= UIReturnKeyGo;//we are assigning the done button like returnbutton
    [searchBar resignFirstResponder];
    [searchBar addTarget:self action:@selector(searchTabA:) forControlEvents:UIControlEventEditingChanged];
    //searchBar.delegate=self; //we need to put the delegate of this to hide the keyboard with the done botton
    [searchView addSubview:searchBar];
    
    /*  UIButton *cancelButton = [UIButton buttonWithType:UIButtonTypeCustom];
     CGRect firstButton =CGRectMake(self.view.frame.size.width-68, 0, 70, 30);
     [cancelButton setFrame:firstButton]; //1
     [cancelButton setTitle:@"Cancel" forState:UIControlStateNormal];
     [cancelButton setBackgroundColor:[UIColor blackColor]];
     [cancelButton addTarget:self action:@selector(openMenuSearch:) forControlEvents:UIControlEventTouchDown];
     [searchView addSubview:cancelButton];
     */
    
    tableViewSearch=[[UITableView alloc] initWithFrame:(CGRectMake(0, 35, self.view.frame.size.width, self.view.frame.size.height-74)) style:UITableViewStylePlain];
    tableViewSearch.delegate=self;
    tableViewSearch.dataSource = self;
    tableViewSearch.rowHeight = 32;
    tableViewSearch.bounces=YES;
    //tableView.backgroundColor=[UIColor colorWithCGColor:whiteColorApp];
    tableViewSearch.clipsToBounds=YES;
    tableViewSearch.scrollsToTop=NO;
    // [tableView setSectionIndexColor:[UIColor redColor]];
    [searchView addSubview:tableViewSearch];
    

    /*---------------------------------------------------------------------------
     * Info View
     *--------------------------------------------------------------------------*/
    
    InfoView=[[UIView alloc]init];
    InfoView.frame=CGRectMake(self.view.frame.size.width, 0, self.view.frame.size.width, self.view.frame.size.height);
    InfoView.backgroundColor=[UIColor whiteColor];
    
    scrollOfInfoMenu = [[UIScrollView alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height)];
    scrollOfInfoMenu.contentSize= CGSizeMake(self.view.frame.size.width, self.view.frame.size.height-44);
    scrollOfInfoMenu.backgroundColor = [UIColor whiteColor];
    //self.scrollView.contentInset = UIEdgeInsetsMake(vOffset, hOffset, 0, 0);
    scrollOfInfoMenu.showsVerticalScrollIndicator = YES;    // to hide scroll indicators!
    scrollOfInfoMenu.scrollEnabled = YES;
    //textField.delegate = self;              //use this when ur using Delegate methods of UITextField
    [InfoView addSubview:scrollOfInfoMenu];
    
    menuInfoView=[[UIView alloc]init];
    menuInfoView.frame=CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height-44);
    menuInfoView.backgroundColor=[UIColor whiteColor];
    [scrollOfInfoMenu addSubview:menuInfoView];
    


   /*
    UILabel *tituloInfoWords = [[UILabel alloc]init];
    tituloInfoWords.text=@"info";
    tituloInfoWords.backgroundColor=[UIColor clearColor];
    tituloInfoWords.frame=CGRectMake(5, 9, 200, 24);
    [menuInfoView addSubview:tituloInfoWords];
    */
    
    
    UILabel *idiomaMaster1 = [[UILabel alloc]initWithFrame:CGRectMake(15, 15, self.view.frame.size.width-30, 30)];
    
   // NSLog(@"%@", lenguaMaster);
    idiomaMaster1.text=lenguaMaster;
    idiomaMaster1.font=[UIFont fontWithName:@"GillSans" size:25.0];
    idiomaMaster1.textColor= [UIColor grayColor];
    idiomaMaster1.backgroundColor=[UIColor clearColor];
    idiomaMaster1.textAlignment=NSTextAlignmentLeft;
    
    [menuInfoView addSubview:idiomaMaster1];

    
    
    infoWord1=[[UITextField alloc]initWithFrame:CGRectMake(10, 50, self.view.frame.size.width-20, 38)];
    infoWord1.placeholder = @"You know";
    [infoWord1 setValue:[UIColor lightTextColor] forKeyPath:@"_placeholderLabel.textColor"];
    infoWord1.font = [UIFont fontWithName:@"GillSans" size:25.0]; // text font
    infoWord1.adjustsFontSizeToFitWidth = YES;     //adjust the font size to fit width.
    infoWord1.borderStyle= UITextBorderStyleRoundedRect;
    infoWord1.backgroundColor=[UIColor darkGrayColor];
    infoWord1.textColor = [UIColor whiteColor];             //text color
    infoWord1.textAlignment=NSTextAlignmentLeft;
    infoWord1.clearButtonMode = UITextFieldViewModeAlways;//for clear button on right side
    
    [menuInfoView addSubview:infoWord1];
    
   
    UILabel *idiomaLearn1 = [[UILabel alloc]initWithFrame:CGRectMake(15, 105, self.view.frame.size.width-30, 30)];
    idiomaLearn1.text=lenguaLista;
    idiomaLearn1.font=[UIFont fontWithName:@"GillSans" size:25.0];
    idiomaLearn1.textColor= [UIColor grayColor];
    idiomaLearn1.backgroundColor=[UIColor clearColor];
    idiomaLearn1.textAlignment=NSTextAlignmentLeft;
    
    [menuInfoView addSubview:idiomaLearn1];
    
    
    
    infoWord2=[[UITextField alloc]initWithFrame:CGRectMake(10, 140, self.view.frame.size.width-20, 38)];
    infoWord2.placeholder = @"You know";
    [infoWord2 setValue:[UIColor lightTextColor] forKeyPath:@"_placeholderLabel.textColor"];
    infoWord2.font = [UIFont fontWithName:@"GillSans" size:25.0]; // text font
    infoWord2.adjustsFontSizeToFitWidth = YES;     //adjust the font size to fit width.
    infoWord2.borderStyle= UITextBorderStyleRoundedRect;
    infoWord2.backgroundColor=[UIColor darkGrayColor];
    infoWord2.textColor = [UIColor whiteColor];             //text color
    infoWord2.textAlignment=NSTextAlignmentLeft;
    infoWord2.clearButtonMode = UITextFieldViewModeAlways;//for clear button on right side
    
    [menuInfoView addSubview:infoWord2];
    
    UILabel *labelNote2= [[UILabel alloc]initWithFrame:CGRectMake(30, 210, self.view.frame.size.width-30, 30)];
    labelNote2.text=@"Notes";
    labelNote2.font=[UIFont fontWithName:@"GillSans" size:25.0];
    labelNote2.textColor= [UIColor grayColor];
    labelNote2.backgroundColor= [UIColor clearColor];
    labelNote2.textAlignment=NSTextAlignmentLeft;
    
    [menuInfoView addSubview:labelNote2];
    
    

    
    
    infoText=[[UITextView alloc]initWithFrame:CGRectMake(30, 250, self.view.frame.size.width-60, self.view.frame.size.height-320)];
    //text.frame=CGRectMake(0, 42, self.view.frame.size.width, self.view.frame.size.height-48);
    //originalTextViewFrame=CGRectMake(3, 55, self.view.frame.size.width-6, self.view.frame.size.height-100);
    //text.backgroundColor= [UIColor colorWithCGColor:];
    infoText.font=[UIFont fontWithName:@"GillSans" size:18.0];
    infoText.textColor=[UIColor whiteColor];
    infoText.backgroundColor=[UIColor darkGrayColor];
    infoText.clipsToBounds = YES;
    infoText.scrollsToTop=YES;
    infoText.bounces=NO;
    infoText.delegate=self;
    
    
    [menuInfoView addSubview:infoText];

    

    
    

    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void) viewDidAppear:(BOOL)animated{
    arrayWords = [dao getListOfWords:listaOriginId];
	[self.tableViewWords reloadData];


}

- (void)setTitleNav:(NSString *)title{
    
    [super setTitle:title];
    UILabel *titleView = (UILabel *)self.navigationItem.titleView;
    if (!titleView) {
        titleView = [[UILabel alloc] initWithFrame:CGRectZero];
        titleView.backgroundColor = [UIColor clearColor];
        titleView.font = [UIFont fontWithName:@"GillSans" size:25.0];
        titleView.shadowColor = [UIColor colorWithWhite:0.5 alpha:0.0];
        
        titleView.textColor = [UIColor grayColor]; // Change to desired color
        
        self.navigationItem.titleView = titleView;
        // [titleView release];
    }
    titleView.text = title;
    [titleView sizeToFit];
}

#pragma mark - keyboard detection

- (void) hideKeyboard {
    
    [self.view endEditing:YES];
}

- (void) viewWillAppear:(BOOL)animated{
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillShow:) name:UIKeyboardWillShowNotification object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillHide:) name:UIKeyboardWillHideNotification object:nil];
}

- (void)keyboardWillShow:(NSNotification*)notification {
    
    NSDictionary *userInfo = [notification userInfo];
    NSTimeInterval animationDuration;
    UIViewAnimationCurve animationCurve;
    CGRect keyboardRect;
    
    [[userInfo objectForKey:UIKeyboardAnimationCurveUserInfoKey] getValue:&animationCurve];
    animationDuration = [[userInfo objectForKey:UIKeyboardAnimationDurationUserInfoKey] doubleValue];
    keyboardRect = [[userInfo objectForKey:UIKeyboardFrameEndUserInfoKey] CGRectValue];
    keyboardRect = [self.view convertRect:keyboardRect fromView:nil];
    
    [UIView beginAnimations:@"ResizeForKeyboard" context:nil];
    [UIView setAnimationDuration:animationDuration];
    [UIView setAnimationCurve:animationCurve];
    
    scrollOfInfoMenu.frame=CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height-210);
    scrollOfAddMenu.frame=CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height-210);
    
    [UIView commitAnimations];

    
}

- (void)keyboardWillHide:(NSNotification*)notification {
    
    NSDictionary *userInfo = [notification userInfo];
    NSTimeInterval animationDuration;
    UIViewAnimationCurve animationCurve;
    CGRect keyboardRect;
    
    [[userInfo objectForKey:UIKeyboardAnimationCurveUserInfoKey] getValue:&animationCurve];
    animationDuration = [[userInfo objectForKey:UIKeyboardAnimationDurationUserInfoKey] doubleValue];
    keyboardRect = [[userInfo objectForKey:UIKeyboardFrameEndUserInfoKey] CGRectValue];
    keyboardRect = [self.view convertRect:keyboardRect fromView:nil];
    
    [UIView beginAnimations:@"ResizeForKeyboard" context:nil];
    [UIView setAnimationDuration:animationDuration];
    [UIView setAnimationCurve:animationCurve];
    
    scrollOfInfoMenu.frame=CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height);
    scrollOfAddMenu.frame=CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height);
    
        [UIView commitAnimations];
}


#pragma mark - Table view detect scrolling


- (void)scrollViewDidScroll:(UIScrollView *)sender{
    //executes when you scroll the scrollView --> when scroll is scrolling
    

}

- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView {
    // execute when you drag the scrollView
    
    //NSLog(@"scrolling!");
    [self.view endEditing:YES]; //keyboard goes out

}

#pragma mark - Table view data source

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    
    return section == 0 ? 15 : 15;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    UIView *customSectionHeaderView;
    UILabel *language1;
    UILabel *language2;
   
    UIFont *labelFont;
    
    if (section == 0)
    {
        customSectionHeaderView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, tableView.frame.size.width, 15)];
        
        language1 = [[UILabel alloc] initWithFrame:CGRectMake(9, 0, tableView.frame.size.width/2, 15)];
        language2 = [[UILabel alloc] initWithFrame:CGRectMake((tableView.frame.size.width/2)+9, 0, tableView.frame.size.width, 15)];
       
        labelFont = [UIFont fontWithName:@"GillSans" size:13.0];
    }
    else
    {
        customSectionHeaderView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, tableView.frame.size.width, 15)];
        
        language1 = [[UILabel alloc] initWithFrame:CGRectMake(9, 0, tableView.frame.size.width/2, 15)];
        language2 = [[UILabel alloc] initWithFrame:CGRectMake((tableView.frame.size.width/2)+9, 0, tableView.frame.size.width, 15)];
        labelFont = [UIFont fontWithName:@"GillSans" size:13.0];
    }
    
    customSectionHeaderView.backgroundColor = [UIColor colorWithRed:200.0/255.0 green:141.0/255.0 blue:50.0/255.0 alpha:1];
    
    language1.textAlignment = UITextAlignmentLeft;
    [language1 setTextColor:[UIColor whiteColor]];
    [language1 setBackgroundColor:[UIColor clearColor]];
    language1.font = labelFont;
    
    language2.textAlignment = UITextAlignmentLeft;
    [language2 setTextColor:[UIColor whiteColor]];
    [language2 setBackgroundColor:[UIColor clearColor]];
    language2.font = labelFont;
    
    
  //  NSString *categoryName = @"idioma";
    
  //  language1.text = [categoryName substringFromIndex:1];
    
    language1.text=lenguaMaster;
    
  //  NSString *categoryName2 = lenguaLista;
    
  //  language2.text = [categoryName2 substringFromIndex:1];
    
    language2.text= lenguaLista;
    
    [customSectionHeaderView addSubview:language1];
    [customSectionHeaderView addSubview:language2];
    
    return customSectionHeaderView;
}



- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
    
    if (menuFlagSearch==FALSE) { //if the searchView is on the top
        
        //NSLog(@"mierda");
        
        
        if (([searchBar.text length]==0) || ([arrayWords count]==0) ) {
            //NSLog(@"mierda2");
            
            [tableViewSearch removeFromSuperview];
            return 0;
            
        }else{
            
            if ([arrayWords count]!=0) {
                [searchView addSubview:tableViewSearch];
                return 1;

            }

        }
    
    }
    
    return 1;

}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    // Return the number of rows in the section.
    
    if (menuFlagSearch==FALSE) { //ensenia las palabras, el buscador esta en pantalla
        //return [arrayWords count];
        
    }else{ //el buscador no esta en pantalla
        if ([arrayWords count]!=0) { //puting inside the tableview if items inside
            NSLog(@"hola");
            
            [self.view addSubview:tableViewWords];
            

        }else{
            
            //[self.view addSubview:tableViewWords];

        
        }
    }
    
    return [arrayWords count];


    
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UILabel *left;
    UILabel *right;
    
    
    
    UITableViewCell *cell;
    if (cell == nil)
    {
        cell = [[UITableViewCell alloc] init];
        
        cell.selectionStyle = UITableViewCellSelectionStyleBlue;

        
      //  searchBar.adjustsFontSizeToFitWidth = YES;     //adjust the font size to fit width.

       
        left =[[UILabel alloc]initWithFrame:CGRectMake(9,4,(self.view.frame.size.width/2)-14,20)];
        left.font=[UIFont fontWithName:@"GillSans" size:16.5];
        left.textColor=[UIColor blackColor];
        left.backgroundColor=[UIColor clearColor];
        left.adjustsFontSizeToFitWidth=YES;
        //left.enabled=NO;
        [cell.contentView addSubview:left];
        
        right =[[UILabel alloc]initWithFrame:CGRectMake((self.view.frame.size.width/2)+9,4,(self.view.frame.size.width/2)-14,20)];
        right.font=[UIFont fontWithName:@"GillSans" size:16.5];
        right.textColor=[UIColor blackColor];
        right.backgroundColor=[UIColor clearColor];
        right.adjustsFontSizeToFitWidth=YES;
        // right.enabled=NO;
        [cell.contentView addSubview:right];
    }
    
    // Configure the cell...
    left.text = [[arrayWords objectAtIndex:[indexPath row]] valueForKey:@"word1"];
        
    right.text = [[arrayWords objectAtIndex:[indexPath row]] valueForKey:@"word2"];
    
    if (indexPath.row % 2 ==0) {
        
        UIImageView *imagecell=[[UIImageView alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 60)];
        imagecell.image=[UIImage imageNamed:@"barraSearchVoca@2x.png"];
        cell.backgroundView=imagecell;
    }else{
        
        UIImageView *imagecell=[[UIImageView alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 60)];
        imagecell.image=[UIImage imageNamed:@"barraSearchVoca2@2x.png"];
        cell.backgroundView=imagecell;
    }
	
    
    //COLOR PRESSING THE CELL////
    UIView *selectedBackgroundViewForCell = [UIView new];
    [selectedBackgroundViewForCell setBackgroundColor:[UIColor darkGrayColor]];
    cell.selectedBackgroundView = selectedBackgroundViewForCell;
    
    return cell;
}


-(void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    cell.backgroundColor=[UIColor clearColor];
    
    
}

- (float)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    // This will create a "invisible" footer
    return 0.01f;
}


 // Override to support conditional editing of the table view.
 - (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
 {
 // Return NO if you do not want the specified item to be editable.
 return YES;
 }


/*---------------------------------------------------------------------------
 * calling to database functions
 *--------------------------------------------------------------------------*/
 // Override to support editing the table view.
 - (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath{
     if (editingStyle == UITableViewCellEditingStyleDelete) {
    // Delete the row from the data source
    
         NSString *pepe = [[arrayWords objectAtIndex:indexPath.row]valueForKey:@"wordId"];
         wordID = [pepe integerValue];
         
         [self deletingWordWarning: wordID nameWord:[[arrayWords objectAtIndex:indexPath.row]valueForKey:@"word1"]];


     }
 
 }

- (void) deletingWordWarning:(NSInteger)wordID nameWord:(NSString *)nameWord {
    
    NSMutableString *message = [[NSMutableString alloc]initWithString:@"Delete the word "];
    [message appendString:nameWord];
    
    UIAlertView *alert = [[UIAlertView alloc]
                          initWithTitle:@"Are you sure?"
                          message:message
                          delegate:self
                          cancelButtonTitle:@"NO"
                          otherButtonTitles:@"YES", nil];
    alert.tag=2;
    
    [alert show];
    
}

/*- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    
    if (buttonIndex == 0){
        
        
    }else{
        
        [dao deleteWord:wordID];
        
        arrayWords = [[NSMutableArray alloc]init];
        arrayWords = [dao getListOfWords:listaOriginId];
        
        if ([arrayWords count]==0) { //puting out the tableview if no items inside
            [tableViewWords removeFromSuperview];
        }
        
        [tableViewWords reloadData];
        
            
    }
        
        
    
    
}*/


/*
 // Override to support rearranging the table view.
 - (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath
 {
 }
 */

/*
 // Override to support conditional rearranging of the table view.
 - (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath
 {
 // Return NO if you do not want the item to be re-orderable.
 return YES;
 }
 */


 #pragma mark - Table view delegate
 
 - (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
 {
    // NSLog(@"%@",[arrayWords objectAtIndex:indexPath.row]);
     
     
     [tableView deselectRowAtIndexPath:indexPath animated:YES]; // for not leaving the color after choosing the cell
     
     infoWord1.text=[[arrayWords objectAtIndex:indexPath.row]valueForKey:@"word1"];
     infoWord2.text=[[arrayWords objectAtIndex:indexPath.row]valueForKey:@"word2"];
     
     infoText.text=[[arrayWords objectAtIndex:indexPath.row]valueForKey:@"comments"];
     
     NSString *pepe = [[arrayWords objectAtIndex:indexPath.row]valueForKey:@"wordId"];
     wordID = [pepe integerValue];
     
    // NSLog(@"%@", pepe);
     [self.view endEditing:YES]; //keyboard goes out

     
     [self openMenuInfo:nil];
 
 }

- (void)viewWillDisappear:(BOOL)animated {
    [self.navigationController setToolbarHidden:NO animated:NO];


}

#pragma mark - Calling to function dataBase

- (void) addNewWordInDataBase{
    //NSLog(@"Añadiendo nueva");
    
    if (([aNewWord1.text length]==0) || ([aNewWord2.text length]==0)) {
        
        UIAlertView *alert = [[UIAlertView alloc]
                              initWithTitle:@"Attention!"
                              message:@"You should write a word before saving!"
                              delegate:self
                              cancelButtonTitle:@"Ok"
                              otherButtonTitles:nil, nil];
        [alert show];
    
    }else{
    
        [dao addWord:aNewWord1.text word2:aNewWord2.text lengua:lenguaLista lista:lista comments:addText.text listOriginId:listaOriginId languageMaster:lenguaMaster languageID:languageID];
    
        arrayWords = [dao getListOfWords:listaOriginId];
	
        [self moreWordsAlert];
        
    }
}

- (void) moreWordsAlert{
    
    UIAlertView *alert = [[UIAlertView alloc]
                          initWithTitle:@"Saved!"
                          message:@"Do you want to save more?"
                          delegate:self
                          cancelButtonTitle:@"NO"
                          otherButtonTitles:@"YES", nil];
    alert.tag=1;
    
    [alert show];
    
}


- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
   
    [self.tableViewWords reloadData];
    
    if (alertView.tag==1) {
        if (buttonIndex == 0){
            //Code for CancelButtonTitle button (its the first one in this case is NO (moreWordsAlert) or okey)
            if (alertView.tag==1) { //when is the alert is coming from the moreWordsAlert
                
                [self openMenuAdd:(nil)];
                
                aNewWord1.text=@"";
                aNewWord2.text=@"";
                addText.text=@"";
            }
            
            
        }
        if (buttonIndex == 1){
            
            [self.view sendSubviewToBack:tableViewWords];
            
            aNewWord1.text=@"";
            aNewWord2.text=@"";
            addText.text=@"";
            
            [aNewWord1 becomeFirstResponder];
            
        }
    }else if (alertView.tag==2){
        
        if (buttonIndex==1) {
            [dao deleteWord:wordID];
            
            arrayWords = [[NSMutableArray alloc]init];
            arrayWords = [dao getListOfWords:listaOriginId];
            
            if ([arrayWords count]==0) { //puting out the tableview if no items inside
                [tableViewWords removeFromSuperview];
            }
            
            [tableViewWords reloadData];
        }
        
    }


}

/*---------------------------------------------------------------------------
 * I check if we are searching or just moding and doing diferents things in
 * each case
 *--------------------------------------------------------------------------*/

- (void) modWordInDataBase{
    
    
    if ([infoWord1.text length]==0 || [infoWord2.text length]==0) {
        
        UIAlertView *alert = [[UIAlertView alloc]
                              initWithTitle:@"Attention!"
                              message:@"You should complete the sections before saving!"
                              delegate:self
                              cancelButtonTitle:@"Ok"
                              otherButtonTitles:nil, nil];
        [alert show];
    }else{
    
        [dao modWord:infoWord1.text word2:infoWord2.text lengua:lenguaLista lista:lista comments:infoText.text wordID:wordID];
    
        infoText.text=@""; //i have to empty the box
    
        if (menuFlagSearch==FALSE) {
            arrayWordsSupporter = [dao getListOfWords:listaOriginId];
            [self searchTabA:nil];
        }else{
            arrayWords = [dao getListOfWords:listaOriginId];
            [self.tableViewWords reloadData];

        }

    [self openMenuInfo:(nil)];
    }
    
}


#pragma mark - Functions for moving menus 


/*---------------------------------------------------------------------------
 * Menu Info moving
 *--------------------------------------------------------------------------*/


- (void)openMenuInfo:(id)sender
{
    // Move the menu view
    if (menuFlag == FALSE)
    {

        
        if (menuFlagSearch==TRUE) {
            
            [self setTitleNav:lista];
            
            NSLog(@"estoy dentro");

            
            [self.navigationController setToolbarHidden:NO animated:YES];
            
            

            
            
            
            //button for saving up-left
            UIImage *buttonAddImage = [UIImage imageNamed:@"addAlexVocabularioGris.png"];
            //create the button and assign the image
            UIButton *buttonAdd = [UIButton buttonWithType:UIButtonTypeCustom];
            [buttonAdd setImage:buttonAddImage forState:UIControlStateNormal];
            [buttonAdd addTarget:self action:@selector(openMenuAdd:) forControlEvents:UIControlEventTouchUpInside];
            //sets the frame of the button to the size of the image
            buttonAdd.frame = CGRectMake(0, 0, 20, 20);
            //creates a UIBarButtonItem with the button as a custom view
            UIBarButtonItem *addLanguageButton = [[UIBarButtonItem alloc] initWithCustomView:buttonAdd];
            
            self.navigationItem.rightBarButtonItem=addLanguageButton;
            
            
            

            
            [self.navigationItem setHidesBackButton:YES];

            menuFlag = TRUE;

            
           
            
        }else{
            
            [self setTitleNav:@"Search"];

            
            //button for saving up-left
            UIButton *editCell1 = [UIButton buttonWithType:UIButtonTypeRoundedRect];
            [editCell1 setTitle:@"Cancel" forState:UIControlStateNormal];
            [editCell1 setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
            [editCell1 setTintColor:[UIColor redColor]];
            editCell1.titleLabel.font= [UIFont fontWithName:@"GillSans" size:16.0];
            
            [editCell1 addTarget:self action:@selector(openMenuSearch:) forControlEvents:UIControlEventTouchUpInside];
            CGRect buttonCancel= CGRectMake(0, 0, 60, 34);
            [editCell1 setFrame:buttonCancel];
            
            UIBarButtonItem *cancellLanguageButton= [[UIBarButtonItem alloc] initWithCustomView:editCell1];
            
            self.navigationItem.rightBarButtonItem=cancellLanguageButton;
            
        }
        
        self.navigationItem.leftBarButtonItem=nil;
        

        [self moveMenuInfo:InfoView duration:0.2 curve:UIViewAnimationCurveEaseOut x:self.view.frame.size.width y:0.0];

        //menuFlagSearch=FALSE;
        
        
        //button for saving up-left
        
        
        [self.view endEditing:YES]; //keyboard goes out
        
    }
    else
    {
        [self.view addSubview:InfoView];
        
        [self setTitleNav:@"Info"];

        
        [self moveMenuInfo:InfoView duration:0.2 curve:UIViewAnimationCurveEaseOut x:0.0 y:0.0];

        menuFlag = FALSE;
        
        
        [self.navigationController setToolbarHidden:YES animated:YES];
        
        scrollOfInfoMenu.frame=CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height);


        
        

        
        
        //button for cancel
        UIButton *editCell1 = [UIButton buttonWithType:UIButtonTypeRoundedRect];
        [editCell1 setTitle:@"Cancel" forState:UIControlStateNormal];
        [editCell1 setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
        [editCell1 setTintColor:[UIColor redColor]];
        editCell1.titleLabel.font= [UIFont fontWithName:@"GillSans" size:16.0];
        
        [editCell1 addTarget:self action:@selector(openMenuInfo:) forControlEvents:UIControlEventTouchUpInside];
        CGRect buttonCancel= CGRectMake(0, 0, 60, 34);
        [editCell1 setFrame:buttonCancel];
        
        UIBarButtonItem *cancellLanguageButton= [[UIBarButtonItem alloc] initWithCustomView:editCell1];
        
        self.navigationItem.rightBarButtonItem=cancellLanguageButton; //aqui que añadir la forma de salvar la info modificada de info
        
        
        //nota save
        
        UIButton *saving = [UIButton buttonWithType:UIButtonTypeRoundedRect];
        [saving setTitle:@"Save" forState:UIControlStateNormal];
        [saving setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
        [saving setTintColor:[UIColor greenColor]];
        saving.titleLabel.font= [UIFont fontWithName:@"GillSans" size:16.0];
        
        [saving addTarget:self action:@selector(modWordInDataBase) forControlEvents:UIControlEventTouchUpInside];
        CGRect savingFrame= CGRectMake(0, 0, 55, 34);
        [saving setFrame:savingFrame];
        
        UIBarButtonItem *guardarButton= [[UIBarButtonItem alloc] initWithCustomView:saving];
        
        self.navigationItem.leftBarButtonItem=guardarButton;

        
        //[infoWord1 becomeFirstResponder];
        
        
        
    }
}

- (void)moveMenuInfo:(UIView *)menuView duration:(NSTimeInterval)duration curve:(int)curve x:(CGFloat)x y:(CGFloat)y
{
    //NSLog(@"hi");
    
    [UIView animateWithDuration:duration
                          delay:0.0f
                        options:curve
                     animations:^{
                         CGRect menuFrame = InfoView.frame;
                         menuFrame.origin.x = x;
                         menuFrame.origin.y = y;
                         menuView.frame = menuFrame;
                         
                         //  NSLog(@"%f",x);
                         //  NSLog(@"%f",y);
                         
                     }
                     completion:nil];
    
    if (menuFlag==TRUE) {
        UIImage *buttonImage = [UIImage imageNamed:@"back2.png"];
        UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
        [button setImage:buttonImage forState:UIControlStateNormal];
        button.frame = CGRectMake(0, 0, 65, 38);
        [button addTarget:self action:@selector(back) forControlEvents:UIControlEventTouchUpInside];
        UIBarButtonItem *customBarItem = [[UIBarButtonItem alloc] initWithCustomView:button];
        self.navigationItem.leftBarButtonItem = customBarItem;
    }
    
    

}


/*---------------------------------------------------------------------------
 * Menu Add moving
 *--------------------------------------------------------------------------*/


- (void)openMenuAdd:(id)sender
{
    // Move the menu view
    if (menuFlag == FALSE)
    {
        [self setTitleNav:lista];

        
        [self.navigationController setToolbarHidden:NO animated:YES];


        menuFlag = TRUE;
        
        //button for saving up-left
        UIImage *buttonAddImage = [UIImage imageNamed:@"addAlexVocabularioGris.png"];
        //create the button and assign the image
        UIButton *buttonAdd = [UIButton buttonWithType:UIButtonTypeCustom];
        [buttonAdd setImage:buttonAddImage forState:UIControlStateNormal];
        [buttonAdd addTarget:self action:@selector(openMenuAdd:) forControlEvents:UIControlEventTouchUpInside];
        //sets the frame of the button to the size of the image
        buttonAdd.frame = CGRectMake(0, 0, 20, 20);
        //creates a UIBarButtonItem with the button as a custom view
        UIBarButtonItem *addLanguageButton = [[UIBarButtonItem alloc] initWithCustomView:buttonAdd];
        
        self.navigationItem.rightBarButtonItem=addLanguageButton;
        
        self.navigationItem.leftBarButtonItem=nil;
        
        [self.view endEditing:YES]; //keyboard goes out
        
        [self moveMenuAdd:AddView duration:0.2 curve:UIViewAnimationCurveEaseOut x:-self.view.frame.size.width y:0.0];

        
    }
    else
    {
        [self.view addSubview:AddView];
        
        [self setTitleNav:@"New Word"];

        
        [self moveMenuAdd:AddView duration:0.2 curve:UIViewAnimationCurveEaseOut x:0.0 y:0.0];

        menuFlag = FALSE;
        
        [self.navigationController setToolbarHidden:YES animated:YES];
        scrollOfAddMenu.frame=CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height);

        //button for cancel
        UIButton *editCell1 = [UIButton buttonWithType:UIButtonTypeRoundedRect];
        [editCell1 setTitle:@"Cancel" forState:UIControlStateNormal];
        [editCell1 setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
        [editCell1 setTintColor:[UIColor redColor]];
        editCell1.titleLabel.font= [UIFont fontWithName:@"GillSans" size:16.0];
        
        [editCell1 addTarget:self action:@selector(openMenuAdd:) forControlEvents:UIControlEventTouchUpInside];
        CGRect buttonCancel= CGRectMake(0, 0, 60, 34);
        [editCell1 setFrame:buttonCancel];
        
        UIBarButtonItem *cancellLanguageButton= [[UIBarButtonItem alloc] initWithCustomView:editCell1];
        
        self.navigationItem.rightBarButtonItem=cancellLanguageButton;
        
        
        
        //button for saving
        
        UIButton *saving = [UIButton buttonWithType:UIButtonTypeRoundedRect];
        [saving setTitle:@"Save" forState:UIControlStateNormal];
        [saving setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
        [saving setTintColor:[UIColor greenColor]];
        saving.titleLabel.font= [UIFont fontWithName:@"GillSans" size:16.0];
        
        [saving addTarget:self action:@selector(addNewWordInDataBase) forControlEvents:UIControlEventTouchUpInside];
        CGRect savingFrame= CGRectMake(0, 0, 55, 34);
        [saving setFrame:savingFrame];
        
        UIBarButtonItem *guardarButton= [[UIBarButtonItem alloc] initWithCustomView:saving];
        
        self.navigationItem.leftBarButtonItem=guardarButton; //aqui que añadir la forma de salvar la info modificada de info
        
              
        [aNewWord1 becomeFirstResponder]; //keyboard goes out
        
        
    }
}


- (void)moveMenuAdd:(UIView *)menuView duration:(NSTimeInterval)duration curve:(int)curve x:(CGFloat)x y:(CGFloat)y
{
    //NSLog(@"hi");
    
    [UIView animateWithDuration:duration
                          delay:0.0f
                        options:curve
                     animations:^{
                         CGRect menuFrame = AddView.frame;
                         menuFrame.origin.x = x;
                         menuFrame.origin.y = y;
                         menuView.frame = menuFrame;
                         
                       //  NSLog(@"%f",x);
                       //  NSLog(@"%f",y);
                         
                     }
                     completion:nil];
    
    UIImage *buttonImage = [UIImage imageNamed:@"back2.png"];
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button setImage:buttonImage forState:UIControlStateNormal];
    button.frame = CGRectMake(0, 0, 65, 38);
    [button addTarget:self action:@selector(back) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *customBarItem = [[UIBarButtonItem alloc] initWithCustomView:button];
    self.navigationItem.leftBarButtonItem = customBarItem;
    
}



/*---------------------------------------------------------------------------
 * Menu Search moving
 *--------------------------------------------------------------------------*/

- (void)openMenuSearch:(id)sender
{
    // Move the menu view
    if (menuFlagSearch == FALSE)
    {
        menuFlagSearch = TRUE;

        [self setTitleNav:lista];

        
        [self getitngBackArrayWords];
        
       // NSLog(@"%@ ", arrayWords);
       
        searchBar.text=@"";
        
        //[tableViewWords reloadData];

        [self.view bringSubviewToFront:searchView];
        

        
        //button for saving up-left
        UIImage *buttonAddImage = [UIImage imageNamed:@"addAlexVocabularioGris.png"];
        //create the button and assign the image
        UIButton *buttonAdd = [UIButton buttonWithType:UIButtonTypeCustom];
        [buttonAdd setImage:buttonAddImage forState:UIControlStateNormal];
        [buttonAdd addTarget:self action:@selector(openMenuInfo:) forControlEvents:UIControlEventTouchUpInside];
        //sets the frame of the button to the size of the image
        buttonAdd.frame = CGRectMake(0, 0, 20, 20);
        //creates a UIBarButtonItem with the button as a custom view
        UIBarButtonItem *addLanguageButton = [[UIBarButtonItem alloc] initWithCustomView:buttonAdd];
        
        UIImage *buttonImage = [UIImage imageNamed:@"back2.png"];
         UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
         [button setImage:buttonImage forState:UIControlStateNormal];
         button.frame = CGRectMake(0, 0, 65, 38);
         [button addTarget:self action:@selector(back) forControlEvents:UIControlEventTouchUpInside];
         UIBarButtonItem *customBarItem = [[UIBarButtonItem alloc] initWithCustomView:button];
         self.navigationItem.leftBarButtonItem = customBarItem;
        
        self.navigationItem.rightBarButtonItem=addLanguageButton;
        
        //self.navigationItem.leftBarButtonItem=nil;
        
        [self.view endEditing:YES]; //keyboard goes out
        
        [self.navigationController setToolbarHidden:NO animated:YES];
        
        // BOOL navBarState = [self.navigationController isNavigationBarHidden];
        // [self.navigationController setNavigationBarHidden:!navBarState animated:YES];
        
        [self moveMenuSearch:searchView duration:0.2 curve:UIViewAnimationCurveEaseOut x:0.0 y:self.view.frame.size.height];
        menuFlagSearch = TRUE;
        
    }
    else
    {
        /*---------------------------------------------------------------------------
         * llamar a funcion para cambiar el array que dirige el tableview
         *--------------------------------------------------------------------------*/
        [self deletingArrayWords];
        
        [self.view addSubview:searchView];
        
        [self setTitleNav:@"Search"];

        
        [self moveMenuSearch:searchView duration:0.2 curve:UIViewAnimationCurveEaseOut x:0.0 y:0.0];
        menuFlagSearch = FALSE;
        
        [tableViewSearch reloadData];

        
        [searchBar becomeFirstResponder];
        
        //BOOL navBarState = [self.navigationController isNavigationBarHidden];
        //[self.navigationController setNavigationBarHidden:!navBarState animated:YES];
        
        
        [self.navigationController setToolbarHidden:YES animated:YES];
        
        //button for saving up-left
        UIButton *editCell1 = [UIButton buttonWithType:UIButtonTypeRoundedRect];
        [editCell1 setTitle:@"Cancel" forState:UIControlStateNormal];
        [editCell1 setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
        [editCell1 setTintColor:[UIColor redColor]];
        editCell1.titleLabel.font= [UIFont fontWithName:@"GillSans" size:16.0];
        
        [editCell1 addTarget:self action:@selector(openMenuSearch:) forControlEvents:UIControlEventTouchUpInside];
        CGRect buttonCancel= CGRectMake(0, 0, 60, 34);
        [editCell1 setFrame:buttonCancel];
        
        UIBarButtonItem *cancellLanguageButton= [[UIBarButtonItem alloc] initWithCustomView:editCell1];
        
        self.navigationItem.rightBarButtonItem=cancellLanguageButton;
        
        [self.navigationItem setHidesBackButton:YES];
        self.navigationItem.leftBarButtonItem=nil;

        
        
        
        
    }
}



- (void)moveMenuSearch:(UIView *)menuView duration:(NSTimeInterval)duration curve:(int)curve x:(CGFloat)x y:(CGFloat)y
{
    //NSLog(@"hi");
    
    [UIView animateWithDuration:duration
                          delay:0.0f
                        options:curve
                     animations:^{
                         CGRect menuFrame = searchView.frame;
                         menuFrame.origin.x = x;
                         menuFrame.origin.y = y;
                         menuView.frame = menuFrame;
                         
                         //  NSLog(@"%f",x);
                         //  NSLog(@"%f",y);
                         
                     }
                     completion:nil];
    
 /*   UIImage *buttonImage = [UIImage imageNamed:@"back2.png"];
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button setImage:buttonImage forState:UIControlStateNormal];
    button.frame = CGRectMake(0, 0, 65, 38);
    [button addTarget:self action:@selector(back) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *customBarItem = [[UIBarButtonItem alloc] initWithCustomView:button];
    self.navigationItem.leftBarButtonItem = customBarItem;
  */
}





#pragma mark - Various

- (void) textViewDidBeginEditing:(UITextView *)textView{

    CGPoint bottomOffset = CGPointMake(0, self.scrollOfInfoMenu.contentSize.height - self.scrollOfInfoMenu.bounds.size.height);
    [self.scrollOfInfoMenu setContentOffset:bottomOffset animated:YES];
    
    CGPoint bottomOffset1 = CGPointMake(0, self.scrollOfAddMenu.contentSize.height - self.scrollOfAddMenu.bounds.size.height);
    [self.scrollOfAddMenu setContentOffset:bottomOffset1 animated:YES];
}

- (void) editingCell{
    

    if (tableViewWords.editing==NO) {
        [tableViewWords setEditing:YES animated:YES];
        
        UIImage *buttonSearchImage = [UIImage imageNamed:@"searchAlexVocabularioGris.png"];
        //create the button and assign the image
        UIButton *buttonSearch = [UIButton buttonWithType:UIButtonTypeCustom];
        [buttonSearch setImage:buttonSearchImage forState:UIControlStateNormal];
        [buttonSearch addTarget:self action:@selector(openMenuSearch:) forControlEvents:UIControlEventTouchUpInside];
        //sets the frame of the button to the size of the image
        buttonSearch.frame = CGRectMake(0, 0, 22, 22);
        //creates a UIBarButtonItem with the button as a custom view
        UIBarButtonItem *searchButton = [[UIBarButtonItem alloc] initWithCustomView:buttonSearch];
        
        UIButton *buttonEdit = [UIButton buttonWithType:UIButtonTypeRoundedRect];
        [buttonEdit setTitle:@"Cancel" forState:UIControlStateNormal];
        [buttonEdit setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
        [buttonEdit setTintColor:[UIColor darkGrayColor]];
        buttonEdit.titleLabel.font= [UIFont fontWithName:@"GillSans" size:16.0];
        
        [buttonEdit addTarget:self action:@selector(editingCell) forControlEvents:UIControlEventTouchUpInside];
        CGRect buttonEditFrame= CGRectMake(0, 0, 60, 34);
        [buttonEdit setFrame:buttonEditFrame];
        
        //UIBarButtonItem *editCell = [[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemEdit target:self action:@selector(editingCell)];
        
        UIBarButtonItem *editCell = [[UIBarButtonItem alloc] initWithCustomView:buttonEdit];
        
        UIBarButtonItem *flexibaleSpaceBarButton = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
        
        self.toolbarItems = [NSArray arrayWithObjects:searchButton, flexibaleSpaceBarButton,editCell, nil];

    }else{
        [tableViewWords setEditing:NO animated:YES];
        
        /*---------------------------------------------------------------------------
         * toolbar items
         *--------------------------------------------------------------------------*/
        
        UIImage *buttonSearchImage = [UIImage imageNamed:@"searchAlexVocabularioGris.png"];
        //create the button and assign the image
        UIButton *buttonSearch = [UIButton buttonWithType:UIButtonTypeCustom];
        [buttonSearch setImage:buttonSearchImage forState:UIControlStateNormal];
        [buttonSearch addTarget:self action:@selector(openMenuSearch:) forControlEvents:UIControlEventTouchUpInside];
        //sets the frame of the button to the size of the image
        buttonSearch.frame = CGRectMake(0, 0, 22, 22);
        //creates a UIBarButtonItem with the button as a custom view
        UIBarButtonItem *searchButton = [[UIBarButtonItem alloc] initWithCustomView:buttonSearch];
        
        UIButton *buttonEdit = [UIButton buttonWithType:UIButtonTypeRoundedRect];
        [buttonEdit setTitle:@"Edit" forState:UIControlStateNormal];
        [buttonEdit setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
        [buttonEdit setTintColor:[UIColor darkGrayColor]];
        buttonEdit.titleLabel.font= [UIFont fontWithName:@"GillSans" size:16.0];
        
        [buttonEdit addTarget:self action:@selector(editingCell) forControlEvents:UIControlEventTouchUpInside];
        CGRect buttonEditFrame= CGRectMake(0, 0, 50, 34);
        [buttonEdit setFrame:buttonEditFrame];
        
        //UIBarButtonItem *editCell = [[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemEdit target:self action:@selector(editingCell)];
        
        UIBarButtonItem *editCell = [[UIBarButtonItem alloc] initWithCustomView:buttonEdit];
        
        UIBarButtonItem *flexibaleSpaceBarButton = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
        
        self.toolbarItems = [NSArray arrayWithObjects:searchButton, flexibaleSpaceBarButton,editCell, nil];


    }
}

- (void) deletingArrayWords{
    
    //NSLog(@"Estamos borrando");
    
    arrayWordsSupporter = [[NSMutableArray alloc]initWithArray:arrayWords];
    [arrayWords removeAllObjects];
    [tableViewSearch reloadData]; //cleaning the tableview
    
   // NSLog(@"hola %@", arrayWordsSupporter);

    
}

- (void) getitngBackArrayWords{
    
    //NSLog(@"Estamos arreglando");

    
    arrayWords = [NSMutableArray arrayWithArray:arrayWordsSupporter];
   
    [arrayWordsSupporter removeAllObjects];
    
    [tableViewWords reloadData];
    
    
    //NSLog(@"hola %@", [arrayWords objectAtIndex:1]);
    
}



- (void) searchTabA:(id)sender{
    
  //  [self.view bringSubviewToFront:tableViewSearch];
    
    if ([searchBar.text length]==0) {
        
        [arrayWords removeAllObjects];
        [tableViewSearch reloadData];
        
        
    }else{
        
        [arrayWords removeAllObjects];
        
        for (int cont=0; cont<[arrayWordsSupporter count]; cont++) {
            
            NSString *word11=[[arrayWordsSupporter objectAtIndex:cont]valueForKey:@"word1"];
            NSString *word22=[[arrayWordsSupporter objectAtIndex:cont]valueForKey:@"word2"];
            
            
            NSString *word1= [word11 lowercaseString];
            NSString *word2= [word22 lowercaseString];
            NSString *wordSearched= [searchBar.text lowercaseString];
            
            
            if (([word1 rangeOfString:wordSearched].location != NSNotFound) || ([word2 rangeOfString:wordSearched].location !=NSNotFound)) {
                
               // NSLog(@"Escribo: %@    comparado con word1: %@ y word2: %@", wordSearched, word1, word2);

               // NSLog(@"array cont: %d", [arrayWords count]);
                
                [arrayWords addObject:[arrayWordsSupporter objectAtIndex:cont]];
                
            } else {
                
                
            }//end of title comparason
            
        }//end of the for
        
        [tableViewSearch reloadData];
        
    }//end of the if I push the textField
    
}//end of searchTab


@end