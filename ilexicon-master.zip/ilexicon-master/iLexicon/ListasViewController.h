//
//  ListasViewController.h
//  Vocabulario
//
//  Created by Alejandro Delgado Diaz on 30/03/13.
//  Copyright (c) 2013 Alejandro. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "listDAO.h"

@interface ListasViewController : UIViewController <UITableViewDelegate, UITableViewDataSource, UIGestureRecognizerDelegate, UITextViewDelegate> {
    listDAO *dao;
    NSMutableArray *arrayListas;
    NSMutableDictionary *dictionaryWords;
    
    NSString *lenguaLista;
    NSString *lenguaMaster;
    NSInteger languageID;
    
    UILocalizedIndexedCollation *collation;

    
}

@property (nonatomic, retain) listDAO *dao;
@property (nonatomic, retain) NSMutableArray *arrayListas;
@property (nonatomic, retain) NSMutableDictionary *dictionaryList;

@property (nonatomic, retain) NSMutableDictionary *dictionaryWords;
@property (nonatomic, retain) NSMutableDictionary *dictionaryWordsSupporter;
@property (nonatomic, retain) UITableView *tableViewLista;
@property (nonatomic, retain) NSString *lenguaLista;
@property (nonatomic, retain) NSString *lenguaMaster;
@property (nonatomic, readwrite) NSInteger languageID;

@property (nonatomic, retain) UIView *AddView;
@property (nonatomic, retain) UIScrollView *scrollOfAddMenu;
@property (nonatomic, retain) UIView *menuAddView;
@property (nonatomic, retain) UITextField *nombreListaNueva;
@property (nonatomic, retain) UITextView *addText;

@property (nonatomic, retain) UIView *InfoView;
@property (nonatomic, retain) UIScrollView *scrollOfInfoMenu;
@property (nonatomic, retain) UIView *menuInfoView;
@property (nonatomic, retain) UITextField *nombreLista;
@property (nonatomic, retain) UITextView *infoText;
@property (nonatomic, readwrite) NSInteger listID;
@property (nonatomic, retain) UILongPressGestureRecognizer *gestureInfoMenu;

@property (nonatomic, retain) UIView *searchView;
@property (nonatomic, retain) UITextField *searchBar;
@property (nonatomic, retain) UITableView *tableViewSearch;

@property (nonatomic, retain) UIView *InfoViewWords;
@property (nonatomic, retain) UIScrollView *scrollOfInfoMenuWords;
@property (nonatomic, retain) UIView *menuInfoViewWords;
@property (nonatomic, retain) UITextField *infoWord1;
@property (nonatomic, retain) UITextField *infoWord2;
@property (nonatomic, retain) UITextView *infoTextWords;

@property (nonatomic, retain) UILabel *idiomaMaster1;
@property (nonatomic, retain) UILabel *idiomaLearn1;


@property (nonatomic, readwrite) NSInteger wordID;






@property (nonatomic, readwrite) BOOL menuFlag;
@property (nonatomic, readwrite) BOOL menuFlagSearch;
@property (nonatomic, readwrite) BOOL menuFlagInfo;
@property (nonatomic, readwrite) BOOL menuFlagAlpha;


@end
