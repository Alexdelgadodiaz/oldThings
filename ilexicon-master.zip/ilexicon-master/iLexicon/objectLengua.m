//
//  objectLengua.m
//  Vocabulario
//
//  Created by Alejandro Delgado Diaz on 28/03/13.
//  Copyright (c) 2013 Alejandro. All rights reserved.
//

#import "objectLengua.h"

@implementation objectLengua

@synthesize language;
@synthesize languageMaster;
@synthesize comments;
@synthesize languageId;

@end
