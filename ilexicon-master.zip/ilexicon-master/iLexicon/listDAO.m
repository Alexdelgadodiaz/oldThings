//
//  listDAO.m
//  Vocabulario
//
//  Created by Alejandro Delgado Diaz on 30/03/13.
//  Copyright (c) 2013 Alejandro. All rights reserved.
//

#import "listDAO.h"
#import "objectlistaki.h"
#import "objectWord.h"

@implementation listDAO
//@synthesize languageLista;




- (NSString *) getPathDataBase{
    NSString *dirDocs;
    NSArray *rutas;
    NSString *rutaBD;
    
    rutas = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    dirDocs = [rutas objectAtIndex:0];
    
    NSFileManager *fileMgr = [NSFileManager defaultManager];
    rutaBD = [[NSString alloc] initWithString:[dirDocs stringByAppendingPathComponent:@"myVocabulario.sqlite"]];
    
    if([fileMgr fileExistsAtPath:rutaBD] == NO){
        [fileMgr copyItemAtPath:[[[NSBundle mainBundle] resourcePath] stringByAppendingPathComponent:@"myVocabulario.sqlite"] toPath:rutaBD error:NULL];
    }
    
    return rutaBD;
}

- (NSMutableArray *) getListOfLists: (NSInteger)languageID{
    
    listaNumber=languageID;
    
   // NSLog(@" hola %@", lengua);

    
	NSMutableArray *arrayList = [[NSMutableArray alloc] init];
	NSString *ubicacionDB = [self getPathDataBase];
	
	if(!(sqlite3_open([ubicacionDB UTF8String], &dataBase) == SQLITE_OK)){
		NSLog(@"No se puede conectar con la BD");
	}
    
	NSString *sentenciaSQL = [NSString stringWithFormat:@"SELECT nameList, commets, rowid FROM lists WHERE languageID= '%d'", languageID] ;
	
    const char *sql = [sentenciaSQL UTF8String];

    sqlite3_stmt *sqlStatement;
	
	if(sqlite3_prepare_v2(dataBase, sql, -1, &sqlStatement, NULL) != SQLITE_OK){
		NSLog(@"Problema al preparar el statement");
       // NSLog(@"HOLA");
	}
	
	while(sqlite3_step(sqlStatement) == SQLITE_ROW){
		objectlistaki *lista = [[objectlistaki alloc] init];
		lista.listaDeTipos = [NSString stringWithUTF8String:(char *) sqlite3_column_text(sqlStatement, 0)];
		lista.comentarios = [NSString stringWithUTF8String:(char *) sqlite3_column_text(sqlStatement, 1)];
        lista.listId= sqlite3_column_int(sqlStatement, 2);
        
        //NSLog(@"el numero que corresponde a la lista es %d", lista.listId);
		
		[arrayList addObject:lista];
	}
	
    NSSortDescriptor *sort = [NSSortDescriptor sortDescriptorWithKey:@"listaDeTipos" ascending:YES];
    [arrayList sortUsingDescriptors:[NSArray arrayWithObject:sort]];
    
	return arrayList;
}



- (NSMutableDictionary *) getingDirectListas:(NSInteger)languageID{
    
    NSArray *arrayList = [self getListOfLists:languageID];
    NSMutableArray *arrayLetters = [[NSMutableArray alloc]init];    
    NSMutableDictionary *dictionaryListas= [[NSMutableDictionary alloc]init];
    NSMutableArray *arrayForDictionary = [[NSMutableArray alloc]init];

    NSInteger contadorArrayLetters = -1;
    
    
    
    for (int i=0; i<[arrayList count]; i++) {
        
        NSString *firstLetter = [[[[arrayList objectAtIndex:i]valueForKey:@"listaDeTipos"] substringToIndex:1]uppercaseString];
        
        if (i==0) { //si es el primero
            [arrayLetters addObject:firstLetter];
            [arrayForDictionary addObject:[arrayList objectAtIndex:i]];
            contadorArrayLetters++;
                        
        }else{//entre medias
            if ([[arrayLetters objectAtIndex:contadorArrayLetters] isEqualToString:firstLetter]) {
              
                [arrayForDictionary addObject:[arrayList objectAtIndex:i]];
                
                if (i== [arrayList count]-1) { //if is the last one
                    [dictionaryListas setObject:arrayForDictionary forKey:[arrayLetters objectAtIndex:contadorArrayLetters]]; //i 
                }

            }else{ 

                [dictionaryListas setObject:arrayForDictionary forKey:[arrayLetters objectAtIndex:contadorArrayLetters]]; //i set the dictionary
                contadorArrayLetters++;
                [arrayLetters addObject:firstLetter];
                arrayForDictionary = [[NSMutableArray alloc]init];
                [arrayForDictionary addObject:[arrayList objectAtIndex:i]];
                
                if (i== [arrayList count]-1) {
                        [dictionaryListas setObject:arrayForDictionary forKey:firstLetter]; //i set the dictionary
                }
            }

        }
    }//end for
    
    if (contadorArrayLetters==0) { //if there is only one list?
        [dictionaryListas setObject:arrayForDictionary forKey:[arrayLetters objectAtIndex:0]]; //i set the dictionary

    }
    
    return dictionaryListas;
}

- (NSArray*) getAlphabet:(NSInteger)languageID{
    
    NSArray *arrayList = [self getListOfLists:languageID];
    NSMutableArray *arrayLetters = [[NSMutableArray alloc]init];
    NSInteger contadorArrayLetters = -1;


    for (int i=0; i<[arrayList count]; i++) {
        NSString *firstLetter = [[[[arrayList objectAtIndex:i]valueForKey:@"listaDeTipos"] substringToIndex:1]uppercaseString];

        if (i==0) { //si es el primero
            [arrayLetters addObject:firstLetter];
            contadorArrayLetters++;

        }else{
            if ([[arrayLetters objectAtIndex:contadorArrayLetters] isEqualToString:firstLetter]){ 
                
            }else{
                contadorArrayLetters++;
                [arrayLetters addObject:firstLetter];

            }
        }
    }
    
  //  NSLog(@"arrayLetters: %@", arrayLetters);
    return arrayLetters;
}




- (void) addList:(NSString *)nombreListaNueva comments:(NSString *)comments lenguaLista:(NSString*)lenguaLista lenguaMaster:(NSString *)lenguaMaster languageID:(NSInteger)languageID {
	NSString *ubicacionDB = [self getPathDataBase];
	
	if(!(sqlite3_open([ubicacionDB UTF8String], &dataBase) == SQLITE_OK)){
		NSLog(@"No se puede conectar con la BD");
		return;
	} else {
		NSString *sqlInsert = [NSString stringWithFormat:@"INSERT INTO lists (language, nameList, commets, languageMaster, languageID) VALUES ('%@', '%@','%@','%@', '%d')", lenguaLista, nombreListaNueva, comments, lenguaMaster, languageID];
		const char *sql = [sqlInsert UTF8String];
		sqlite3_stmt *sqlStatement;
		
		if(sqlite3_prepare_v2(dataBase, sql, -1, &sqlStatement, NULL) != SQLITE_OK){
			NSLog(@"Problema al preparar el statement");
			return;
		} else {
			if(sqlite3_step(sqlStatement) == SQLITE_DONE){
				sqlite3_finalize(sqlStatement);
				sqlite3_close(dataBase);
			}
		}
		
	}
    
}

- (void) modList:(NSString *)nombreLista comments:(NSString *)comments listID:(NSInteger)listID {
    
    // NSLog(@"HOLA");
    // NSLog(@"%d", wordID);
    
    NSString *ubicacionBD = [self getPathDataBase];
	
	if(!(sqlite3_open([ubicacionBD UTF8String], &dataBase) == SQLITE_OK)){
		NSLog(@"No se puede conectar con la BD");
		return;
	} else {
		NSString *sqlUpdate = [NSString stringWithFormat:@"UPDATE lists SET nameList = '%@', commets = '%@' WHERE rowid = %d", nombreLista, comments, listID];
		const char *sql = [sqlUpdate UTF8String];
		sqlite3_stmt *sqlStatement;
		
		if(sqlite3_prepare_v2(dataBase, sql, -1, &sqlStatement, NULL) != SQLITE_OK){
			NSLog(@"Problema al preparar el statement.");
			return;
		} else {
			if(sqlite3_step(sqlStatement) == SQLITE_DONE){
				sqlite3_finalize(sqlStatement);
				sqlite3_close(dataBase);
			}
		}
	}
}

- (void) deleteList:(NSInteger) listID{
	//NSLog(@"a borrar");
    
    NSString *ubicacionBD = [self getPathDataBase];
    
	
	if(!(sqlite3_open([ubicacionBD UTF8String], &dataBase) == SQLITE_OK)){
		NSLog(@"No se puede conectar con la BD");
		return;
	} else {
        
        NSLog(@"lista a eliminar: %d", listID);
		NSString *sqlDelete = [NSString stringWithFormat:@"DELETE FROM lists WHERE rowid = %d", listID];
		const char *sql = [sqlDelete UTF8String];
		sqlite3_stmt *sqlStatement;
		
		if(sqlite3_prepare_v2(dataBase, sql, -1, &sqlStatement, NULL) != SQLITE_OK){
			NSLog(@"Problema al preparar el statement.");
			return;
		} else {
            
                        
            
            if(sqlite3_step(sqlStatement) == SQLITE_DONE){
                sqlite3_finalize(sqlStatement);
                sqlite3_close(dataBase);
                
                [self deleteWordsOfList:listID];
                
            }
        }
    }
}

- (void) deleteWordsOfList:(NSInteger) listID{
    
    NSString *ubicacionBD = [self getPathDataBase];
    
	
	if(!(sqlite3_open([ubicacionBD UTF8String], &dataBase) == SQLITE_OK)){
		NSLog(@"No se puede conectar con la BD");
		return;
	} else {
        
        NSLog(@"lista a eliminar: %d", listID);
		NSString *sqlDelete = [NSString stringWithFormat:@"DELETE FROM words WHERE listOriginId = %d", listID];
		const char *sql = [sqlDelete UTF8String];
		sqlite3_stmt *sqlStatement;
		
		if(sqlite3_prepare_v2(dataBase, sql, -1, &sqlStatement, NULL) != SQLITE_OK){
			NSLog(@"Problema al preparar el statement.");
			return;
		} else {
            
            
            
            if(sqlite3_step(sqlStatement) == SQLITE_DONE){
                sqlite3_finalize(sqlStatement);
                sqlite3_close(dataBase);
                
            }
		}
	}
    
}

- (void) modWord:(NSString *)word1 word2:(NSString *)word2 lengua:(NSString *)lengua comments:(NSString *)comments wordID:(NSInteger)wordID{
    
    // NSLog(@"HOLA");
    // NSLog(@"%d", wordID);
    
    NSString *ubicacionBD = [self getPathDataBase];
	
	if(!(sqlite3_open([ubicacionBD UTF8String], &dataBase) == SQLITE_OK)){
		NSLog(@"No se puede conectar con la BD");
		return;
	} else {
		NSString *sqlUpdate = [NSString stringWithFormat:@"UPDATE words SET word1 = '%@', word2 = '%@', comments ='%@' WHERE rowid = %d", word1, word2, comments, wordID];
		const char *sql = [sqlUpdate UTF8String];
		sqlite3_stmt *sqlStatement;
		
		if(sqlite3_prepare_v2(dataBase, sql, -1, &sqlStatement, NULL) != SQLITE_OK){
			NSLog(@"Problema al preparar el statement.");
			return;
		} else {
			if(sqlite3_step(sqlStatement) == SQLITE_DONE){
				sqlite3_finalize(sqlStatement);
				sqlite3_close(dataBase);
			}
		}
	}
}

- (NSMutableDictionary *) getDictionarForSearch{
    
  //  - (NSMutableDictionary *) getDictionarForSearch: (NSInteger)listOriginId{
	NSMutableDictionary *diccionaryWords = [[NSMutableDictionary alloc] init];
    //NSMutableArray *arrayWordsOfAList = [[NSMutableArray alloc]init];
    NSString *ubicacionDB = [self getPathDataBase];
	
	if(!(sqlite3_open([ubicacionDB UTF8String], &dataBase) == SQLITE_OK)){
		NSLog(@"No se puede conectar con la BD");
	}
    
   NSMutableArray *arrayListOfWordsForSearch = [self getListOfLists:listaNumber];
    
    for (int cont=0; cont<[arrayListOfWordsForSearch count]; cont++) {
        
        NSMutableArray *arrayList = [[NSMutableArray alloc]init];
       
        NSString *pepe = [[arrayListOfWordsForSearch objectAtIndex:cont]valueForKey:@"listId"];
        NSInteger listaIdentidad = [pepe integerValue];
        
        NSString *sentenciaSQL = [NSString stringWithFormat:@"SELECT word1, word2, comments, rowid, languageMaster, language FROM words WHERE listOriginId = '%d'", listaIdentidad];
        
        const char *sql = [sentenciaSQL UTF8String];
        
        sqlite3_stmt *sqlStatement;
        
        if(sqlite3_prepare_v2(dataBase, sql, -1, &sqlStatement, NULL) != SQLITE_OK){
            NSLog(@"Problema al preparar el statement");
            //  NSLog(@"HOLA");
        }
        
        [arrayList removeObjectsInArray:arrayList];

        while(sqlite3_step(sqlStatement) == SQLITE_ROW){
            
            objectWord *word = [[objectWord alloc] init];
            word.word1 = [NSString stringWithUTF8String:(char *) sqlite3_column_text(sqlStatement, 0)];
            word.word2 = [NSString stringWithUTF8String:(char *) sqlite3_column_text(sqlStatement, 1)];
            word.comments = [NSString stringWithUTF8String:(char *) sqlite3_column_text(sqlStatement, 2)];
            word.wordId = sqlite3_column_int(sqlStatement, 3);
            word.languageMaster = [NSString stringWithUTF8String:(char *) sqlite3_column_text(sqlStatement, 4)];
            word.languageOrigin = [NSString stringWithUTF8String:(char *) sqlite3_column_text(sqlStatement, 5)];
            
            [arrayList addObject:word];
            
        }//end while
        
        NSString *nombreLista = [[NSString alloc]init];
        nombreLista = [[arrayListOfWordsForSearch objectAtIndex:cont]valueForKey:@"listaDeTipos"];

        [diccionaryWords setObject:arrayList forKey: nombreLista];
        
    }//end for
    
    
  //  NSLog(@"dictionaryWords: %@", diccionaryWords.allKeys);
    
  //  NSLog(@"Dictionary; %@", [[[diccionaryWords objectForKey:@"Adjetivos"]objectAtIndex:0]valueForKey:@"word1"]);

	
	return diccionaryWords;
}

- (void) deleteWordSearch:(NSInteger)wordID{
    
    // NSLog(@"HOLA");
    // NSLog(@"%d", wordID);
    
    NSString *ubicacionBD = [self getPathDataBase];
	
	if(!(sqlite3_open([ubicacionBD UTF8String], &dataBase) == SQLITE_OK)){
		NSLog(@"No se puede conectar con la BD");
		return;
	} else {
		NSString *sqlUpdate = [NSString stringWithFormat:@"DELETE FROM words WHERE rowid = %d", wordID];
		const char *sql = [sqlUpdate UTF8String];
		sqlite3_stmt *sqlStatement;
		
		if(sqlite3_prepare_v2(dataBase, sql, -1, &sqlStatement, NULL) != SQLITE_OK){
			NSLog(@"Problema al preparar el statement.");
			return;
		} else {
			if(sqlite3_step(sqlStatement) == SQLITE_DONE){
				sqlite3_finalize(sqlStatement);
				sqlite3_close(dataBase);
			}
		}
	}
}

@end
