//
//  objectLengua.h
//  Vocabulario
//
//  Created by Alejandro Delgado Diaz on 28/03/13.
//  Copyright (c) 2013 Alejandro. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface objectLengua : NSObject{
    NSString *language;
    NSString *languageMaster;
    NSString *comments;
    NSInteger languageId;
}

@property (nonatomic, retain) NSString *language;
@property (nonatomic, retain) NSString *languageMaster;
@property (nonatomic, retain) NSString *comments;
@property (nonatomic, readwrite) NSInteger languageId;


@end
