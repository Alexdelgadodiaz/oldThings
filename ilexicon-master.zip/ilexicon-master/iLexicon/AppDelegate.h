//
//  AppDelegate.h
//  iLexicon
//
//  Created by Alejandro Delgado Diaz on 03/06/13.
//  Copyright (c) 2013 Alejandro. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
