//
//  listaLenguas.m
//  Vocabulario
//
//  Created by Alejandro Delgado Diaz on 28/03/13.
//  Copyright (c) 2013 Alejandro. All rights reserved.
//

#import "lenguaDAO.h"
#import "objectLengua.h"
#import "objectWord.h"



@implementation lenguaDAO

- (NSString *) getPathDataBase{
    NSString *dirDocs;
    NSArray *rutas;
    NSString *rutaBD;
    
    rutas = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    dirDocs = [rutas objectAtIndex:0];
    
    NSFileManager *fileMgr = [NSFileManager defaultManager];
    rutaBD = [[NSString alloc] initWithString:[dirDocs stringByAppendingPathComponent:@"myVocabulario.sqlite"]];
    
    if([fileMgr fileExistsAtPath:rutaBD] == NO){
        [fileMgr copyItemAtPath:[[[NSBundle mainBundle] resourcePath] stringByAppendingPathComponent:@"myVocabulario.sqlite"] toPath:rutaBD error:NULL];
    }
    
    return rutaBD;
}

- (NSMutableArray *) getListLanguage{
	NSMutableArray *listaLenguas = [[NSMutableArray alloc] init];
	NSString *ubicacionDB = [self getPathDataBase];
	
	if(!(sqlite3_open([ubicacionDB UTF8String], &dataBase) == SQLITE_OK)){
		NSLog(@"No se puede conectar con la BD");
	}
	
	const char *sentenciaSQL = "SELECT language, commets, languageMaster, rowid FROM languages";
	sqlite3_stmt *sqlStatement;
	
	if(sqlite3_prepare_v2(dataBase, sentenciaSQL, -1, &sqlStatement, NULL) != SQLITE_OK){
		NSLog(@"Problema al preparar el statement");
        //NSLog(@"HOLA");
	}
	
	while(sqlite3_step(sqlStatement) == SQLITE_ROW){
		objectLengua *lengua = [[objectLengua alloc] init];
		lengua.language = [NSString stringWithUTF8String:(char *) sqlite3_column_text(sqlStatement, 0)];
		lengua.comments = [NSString stringWithUTF8String:(char *) sqlite3_column_text(sqlStatement, 1)];
        lengua.languageMaster = [NSString stringWithUTF8String:(char *) sqlite3_column_text(sqlStatement, 2)];
        lengua.languageId= sqlite3_column_int(sqlStatement, 3);

		
		[listaLenguas addObject:lengua];
	}
	
	return listaLenguas;
}


- (void) addLanguage:(NSString *)lengua comments:(NSString *)comments lenguaMaster:(NSString *)lenguaMaster {
    
	NSString *ubicacionDB = [self getPathDataBase];
	
	if(!(sqlite3_open([ubicacionDB UTF8String], &dataBase) == SQLITE_OK)){
		NSLog(@"No se puede conectar con la BD");
		return;
	} else {
		NSString *sqlInsert = [NSString stringWithFormat:@"INSERT INTO languages (language, commets, languageMaster) VALUES ('%@', '%@','%@')", lengua, comments, lenguaMaster];
		const char *sql = [sqlInsert UTF8String];
		sqlite3_stmt *sqlStatement;
		
		if(sqlite3_prepare_v2(dataBase, sql, -1, &sqlStatement, NULL) != SQLITE_OK){
			NSLog(@"Problema al preparar el statement");
			return;
		} else {
			if(sqlite3_step(sqlStatement) == SQLITE_DONE){
				sqlite3_finalize(sqlStatement);
				sqlite3_close(dataBase);
			}
		}
		
	}
    
}

- (void) modLanguage:(NSString *)nombreLanguage comments:(NSString *)comments languageMaster:(NSString *) languageMaster languageID:(NSInteger)languageID {
    
    // NSLog(@"HOLA");
    // NSLog(@"%d", wordID);
    
    NSString *ubicacionBD = [self getPathDataBase];
	
	if(!(sqlite3_open([ubicacionBD UTF8String], &dataBase) == SQLITE_OK)){
		NSLog(@"No se puede conectar con la BD");
		return;
	} else {
		NSString *sqlUpdate = [NSString stringWithFormat:@"UPDATE languages SET language = '%@', commets = '%@', languageMaster ='%@' WHERE rowid = %d", nombreLanguage, comments, languageMaster, languageID];
		const char *sql = [sqlUpdate UTF8String];
		sqlite3_stmt *sqlStatement;
		
		if(sqlite3_prepare_v2(dataBase, sql, -1, &sqlStatement, NULL) != SQLITE_OK){
			NSLog(@"Problema al preparar el statement.");
			return;
		} else {
			if(sqlite3_step(sqlStatement) == SQLITE_DONE){
				sqlite3_finalize(sqlStatement);
				sqlite3_close(dataBase);
			}
		}
	}
}


- (void) deleteLanguage:(NSInteger) languageID { //borrando lenguage senialado
	//NSLog(@"a borrar");
    
    NSString *ubicacionBD = [self getPathDataBase];
    
	
	if(!(sqlite3_open([ubicacionBD UTF8String], &dataBase) == SQLITE_OK)){
		NSLog(@"No se puede conectar con la BD");
		return;
	} else {
        
        //NSLog(@"lista a eliminar: %d", languageID);
		NSString *sqlDelete = [NSString stringWithFormat:@"DELETE FROM languages WHERE rowid = %d", languageID];
		const char *sql = [sqlDelete UTF8String];
		sqlite3_stmt *sqlStatement;
		
		if(sqlite3_prepare_v2(dataBase, sql, -1, &sqlStatement, NULL) != SQLITE_OK){
			NSLog(@"Problema al preparar el statement.");
			return;
		} else {
            
            
            
            if(sqlite3_step(sqlStatement) == SQLITE_DONE){
                sqlite3_finalize(sqlStatement);
                sqlite3_close(dataBase);
                
                [self deleteListsOf:languageID];
                
            }
        }
    }
}


- (void) deleteListsOf:(NSInteger) languageID{ //borrando todas las listas del lenguage senialado
	//NSLog(@"a borrar");
    
    NSString *ubicacionBD = [self getPathDataBase];
    
	
	if(!(sqlite3_open([ubicacionBD UTF8String], &dataBase) == SQLITE_OK)){
		NSLog(@"No se puede conectar con la BD");
		return;
	} else {
        
        //NSLog(@"lista a eliminar: %d", languageID);
		NSString *sqlDelete = [NSString stringWithFormat:@"DELETE FROM lists WHERE languageID = %d", languageID];
		const char *sql = [sqlDelete UTF8String];
		sqlite3_stmt *sqlStatement;
		
		if(sqlite3_prepare_v2(dataBase, sql, -1, &sqlStatement, NULL) != SQLITE_OK){
			NSLog(@"Problema al preparar el statement.");
			return;
		} else {
            
            
            
            if(sqlite3_step(sqlStatement) == SQLITE_DONE){
                sqlite3_finalize(sqlStatement);
                sqlite3_close(dataBase);
                
                [self deleteWordsOfList:languageID];
                
            }
        }
    }
}



- (void) deleteWordsOfList:(NSInteger) languageID{ //borrando todas las palabras del lenguage senialado
    
    NSString *ubicacionBD = [self getPathDataBase];
    
	
	if(!(sqlite3_open([ubicacionBD UTF8String], &dataBase) == SQLITE_OK)){
		NSLog(@"No se puede conectar con la BD");
		return;
	} else {
        
        //NSLog(@"lista a eliminar: %d", languageID);
		NSString *sqlDelete = [NSString stringWithFormat:@"DELETE FROM words WHERE languageID = %d", languageID];
		const char *sql = [sqlDelete UTF8String];
		sqlite3_stmt *sqlStatement;
		
		if(sqlite3_prepare_v2(dataBase, sql, -1, &sqlStatement, NULL) != SQLITE_OK){
			NSLog(@"Problema al preparar el statement.");
			return;
		} else {
            
            
            
            if(sqlite3_step(sqlStatement) == SQLITE_DONE){
                sqlite3_finalize(sqlStatement);
                sqlite3_close(dataBase);
                
            }
		}
	}
    
}



- (NSMutableDictionary *) getDictionarForSearch{
    
    //  - (NSMutableDictionary *) getDictionarForSearch: (NSInteger)listOriginId{
	NSMutableDictionary *diccionaryWords = [[NSMutableDictionary alloc] init];
    //NSMutableArray *arrayWordsOfAList = [[NSMutableArray alloc]init];
    NSString *ubicacionDB = [self getPathDataBase];
	
	if(!(sqlite3_open([ubicacionDB UTF8String], &dataBase) == SQLITE_OK)){
		NSLog(@"No se puede conectar con la BD");
	}
    
    NSMutableArray *arrayListOfWordsForSearch = [self getListLanguage];
    
    //NSLog(@"arraylist %@", arrayListOfWordsForSearch);

    
    for (int cont=0; cont<[arrayListOfWordsForSearch count]; cont++) {
        
        NSMutableArray *arrayList = [[NSMutableArray alloc]init];
        
        
        NSString *pepe = [[arrayListOfWordsForSearch objectAtIndex:cont]valueForKey:@"languageId"];
        NSInteger idLanguage = [pepe integerValue];
        
        NSString *sentenciaSQL = [NSString stringWithFormat:@"SELECT word1, word2, comments, rowid, languageMaster, language FROM words WHERE languageID = '%d'", idLanguage];
        
        const char *sql = [sentenciaSQL UTF8String];
        
        sqlite3_stmt *sqlStatement;
        
        if(sqlite3_prepare_v2(dataBase, sql, -1, &sqlStatement, NULL) != SQLITE_OK){
            NSLog(@"Problema al preparar el statement");
            //  NSLog(@"HOLA");
        }
        
        [arrayList removeObjectsInArray:arrayList];
        
        while(sqlite3_step(sqlStatement) == SQLITE_ROW){
            
            objectWord *word = [[objectWord alloc] init];
            word.word1 = [NSString stringWithUTF8String:(char *) sqlite3_column_text(sqlStatement, 0)];
            word.word2 = [NSString stringWithUTF8String:(char *) sqlite3_column_text(sqlStatement, 1)];
            word.comments = [NSString stringWithUTF8String:(char *) sqlite3_column_text(sqlStatement, 2)];
            word.wordId = sqlite3_column_int(sqlStatement, 3);
            word.languageMaster = [NSString stringWithUTF8String:(char *) sqlite3_column_text(sqlStatement, 4)];
            word.languageOrigin = [NSString stringWithUTF8String:(char *) sqlite3_column_text(sqlStatement, 5)];

            [arrayList addObject:word];
            
            //NSLog(@"Word1 : %@", word.word1);
            
        }//end while
        
        NSString *nombreLista = [[NSString alloc]init];
        nombreLista = [[arrayListOfWordsForSearch objectAtIndex:cont]valueForKey:@"language"];
        
        //NSLog(@"nombreLista que guardo: %@", nombreLista);
        
        /************************************************************************************
         *
         * i should introduce here what languages i am using for showing them in the header
         *
         ************************************************************************************/
        
        
        [diccionaryWords setObject:arrayList forKey: nombreLista];
        
    }//end for
    
    
    //  NSLog(@"dictionaryWords: %@", diccionaryWords.allKeys);
    
   /* for (int u = 0; u<=50; u++) {
        NSLog(@"Dictionary; %@", [[[diccionaryWords objectForKey:@"Griego\n"]objectAtIndex:u]valueForKey:@"word1"]);

    }*/
    
    
    
    
	
	return diccionaryWords;
}

- (void) modWord:(NSString *)word1 word2:(NSString *)word2 comments:(NSString *)comments wordID:(NSInteger)wordID{
    
    // NSLog(@"HOLA");
    // NSLog(@"%d", wordID);
    
    NSString *ubicacionBD = [self getPathDataBase];
	
	if(!(sqlite3_open([ubicacionBD UTF8String], &dataBase) == SQLITE_OK)){
		NSLog(@"No se puede conectar con la BD");
		return;
	} else {
		NSString *sqlUpdate = [NSString stringWithFormat:@"UPDATE words SET word1 = '%@', word2 = '%@', comments ='%@' WHERE rowid = %d", word1, word2, comments, wordID];
		const char *sql = [sqlUpdate UTF8String];
		sqlite3_stmt *sqlStatement;
		
		if(sqlite3_prepare_v2(dataBase, sql, -1, &sqlStatement, NULL) != SQLITE_OK){
			NSLog(@"Problema al preparar el statement.");
			return;
		} else {
			if(sqlite3_step(sqlStatement) == SQLITE_DONE){
				sqlite3_finalize(sqlStatement);
				sqlite3_close(dataBase);
			}
		}
	}
}


- (void) deleteWordSearch:(NSInteger)wordID{
    
    // NSLog(@"HOLA");
    // NSLog(@"%d", wordID);
    
    NSString *ubicacionBD = [self getPathDataBase];
	
	if(!(sqlite3_open([ubicacionBD UTF8String], &dataBase) == SQLITE_OK)){
		NSLog(@"No se puede conectar con la BD");
		return;
	} else {
		NSString *sqlUpdate = [NSString stringWithFormat:@"DELETE FROM words WHERE rowid = %d", wordID];
		const char *sql = [sqlUpdate UTF8String];
		sqlite3_stmt *sqlStatement;
		
		if(sqlite3_prepare_v2(dataBase, sql, -1, &sqlStatement, NULL) != SQLITE_OK){
			NSLog(@"Problema al preparar el statement.");
			return;
		} else {
			if(sqlite3_step(sqlStatement) == SQLITE_DONE){
				sqlite3_finalize(sqlStatement);
				sqlite3_close(dataBase);
			}
		}
	}
}

@end


