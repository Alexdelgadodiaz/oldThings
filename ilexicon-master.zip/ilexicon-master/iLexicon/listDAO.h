//
//  listDAO.h
//  Vocabulario
//
//  Created by Alejandro Delgado Diaz on 30/03/13.
//  Copyright (c) 2013 Alejandro. All rights reserved.
//


#import <Foundation/Foundation.h>
#import <sqlite3.h>

@interface listDAO : NSObject{
    sqlite3 *dataBase;
    
    NSInteger listaNumber;

}

- (NSString *) getPathDataBase;
- (NSMutableArray *) getListOfLists: (NSInteger)languageID;
- (NSMutableDictionary *) getingDirectListas:(NSInteger)languageID;
- (NSArray*) getAlphabet:(NSInteger)languageID;



- (void) addList:(NSString *)nombreListaNueva comments:(NSString *)comments lenguaLista:(NSString*)lenguaLista lenguaMaster:(NSString *)lenguaMaster languageID:(NSInteger)languageID;
- (void) modList:(NSString *)nombreLista comments:(NSString *)comments listID:(NSInteger)listID;
- (void) deleteList:(NSInteger) listID;

- (NSMutableDictionary *) getDictionarForSearch; //(NSInteger)listOriginId;
- (void) modWord:(NSString *)word1 word2:(NSString *)word2 lengua:(NSString *)lengua comments:(NSString *)comments wordID:(NSInteger)wordID;
- (void) deleteWordSearch:(NSInteger)wordID;



//@property (nonatomic, retain) NSString *languageLista;


@end