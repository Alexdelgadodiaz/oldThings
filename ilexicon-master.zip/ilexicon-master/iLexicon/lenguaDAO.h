//
//  listaLenguas.h
//  Vocabulario
//
//  Created by Alejandro Delgado Diaz on 28/03/13.
//  Copyright (c) 2013 Alejandro. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <sqlite3.h>


@interface lenguaDAO : NSObject{
    sqlite3 *dataBase;
}

- (NSString *) getPathDataBase;
- (NSMutableArray *) getListLanguage;
- (void) addLanguage:(NSString *)lengua comments:(NSString *)comments lenguaMaster:(NSString *)lenguaMaster;
- (void) modLanguage:(NSString *)nombreLanguage comments:(NSString *)comments languageMaster:(NSString *) languageMaster languageID:(NSInteger)languageID;
- (void) deleteLanguage:(NSInteger) languageID;
- (NSMutableDictionary *) getDictionarForSearch;
- (void) modWord:(NSString *)word1 word2:(NSString *)word2 comments:(NSString *)comments wordID:(NSInteger)wordID;
- (void) deleteWordSearch:(NSInteger)wordID;




@end
