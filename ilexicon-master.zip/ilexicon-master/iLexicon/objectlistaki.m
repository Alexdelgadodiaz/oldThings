//
//  objectlistaki.m
//  Vocabulario
//
//  Created by Alejandro Delgado Diaz on 30/03/13.
//  Copyright (c) 2013 Alejandro. All rights reserved.
//

#import "objectlistaki.h"

@implementation objectlistaki

@synthesize listaDeTipos;
@synthesize comentarios;
@synthesize listId;

@end
