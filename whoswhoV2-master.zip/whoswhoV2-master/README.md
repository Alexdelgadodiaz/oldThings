whoswhoV2 With json and storing images
======================================

This a new version of this "test" where I use a json file to persist information and storing the images for not being
downloading the images everytime. 

Cheers!
