//
//  ADDViewController.m
//  Whoiswho V2 with json and storing images
//
//  Created by Alejandro Delgado Diaz on 10/12/13.
//  Copyright (c) 2013 Alejandro Delgado Diaz. All rights reserved.
//

#import <QuartzCore/QuartzCore.h>
#import "ADDViewController.h"
#import "ADDFriendDetailsViewController.h"
#import "TFHpple.h"

@interface ADDViewController ()

@end

@implementation ADDViewController{
    NSMutableArray *_photos;
    BOOL _firstTime;
}


- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    super.title = @"Who's Who!?";
    
    
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES); //1
    NSString *documentsDirectory = [paths objectAtIndex:0]; //2
    NSString *path = [documentsDirectory stringByAppendingPathComponent:@"data.json"]; //3
    
    NSFileManager *fileManager = [NSFileManager defaultManager];
    
    if (![fileManager fileExistsAtPath: path]) //4
    {
        _firstTime = YES;
        
    }else{
        _firstTime = NO;
        NSData *json=[NSData dataWithContentsOfFile:path];
        [self loadFromDisk:json];
    }
    
    [self loadFutureFriends];
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



-(IBAction)refreshFriends:(id)sender{
    
    [self loadFutureFriends];
    NSLog(@"refreshhing!");
    
}


- (void)loadFromDisk:(NSData *)json{
    
    NSError* error;
    _myFriendsOnDict = [NSJSONSerialization JSONObjectWithData:json //1
                                                         options:kNilOptions
                                                           error:&error];
    [_friendTable reloadData];
}


- (void)loadFutureFriends{
    
    NSLog(@"IN");
    
    //Crear una cola, PILA
    dispatch_queue_t newFriends = dispatch_queue_create("Friends", 0);
    
    __block NSMutableDictionary *newList = [[NSMutableDictionary alloc]initWithCapacity:0];
    __block NSMutableArray *photosList = [[NSMutableArray alloc]init];

    
    //Mandar bloque a la cola
    dispatch_async(newFriends, ^{
        
        NSURL *ourTeamURL = [NSURL URLWithString:@"http://www.theappbusiness.com/our-team"];
        NSData *ourTeamHTMLData = [NSData dataWithContentsOfURL:ourTeamURL];
        
        TFHpple *ourParser = [TFHpple hppleWithHTMLData:ourTeamHTMLData];
        
        NSString *namesXpathQueryString = @"//div[@class='col col2']/h3";
        NSArray *nameNodes = [ourParser searchWithXPathQuery:namesXpathQueryString];
        
        NSString *photosXpathQueryString = @"//div[@class='col col2']/div[@class='title']/img";
        NSArray *photoNodes = [ourParser searchWithXPathQuery:photosXpathQueryString];
        
        NSString *areaAndBioXpathQueryString = @"//div[@class='col col2']/p";
        NSArray *areaAndBioNodes = [ourParser searchWithXPathQuery:areaAndBioXpathQueryString]; //yes, I don't know (yet) how to make the xpath for the area without taking also de bio, I used this to get only the bio: @"//div[@class='col col2']/p[@class='user-description']".
        
        
        for (int i = 0; i < [nameNodes count]; i++){
            
            TFHppleElement *name = [nameNodes objectAtIndex:i];
            TFHppleElement *photo = [photoNodes objectAtIndex:i];
            TFHppleElement *area = [areaAndBioNodes objectAtIndex:i*2];
            TFHppleElement *bio = [areaAndBioNodes objectAtIndex:i*2+1];
            
            NSString *photoUrl = [photo objectForKey:@"src"];
            NSURL *url = [NSURL URLWithString:photoUrl];
            
            NSString *docDir = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0];
            NSString *pngFilePath = [NSString stringWithFormat:@"%@/%@.png",docDir,[[name firstChild]content]];
            
            NSDictionary *photoOfOne = [[NSDictionary alloc]initWithObjectsAndKeys:
            url, @"url", pngFilePath, @"path", nil];
            
            [photosList addObject:photoOfOne];

            NSDictionary *dictFriend = [[NSDictionary alloc] initWithObjectsAndKeys:
                                       [[name firstChild]content], @"name",
                                        pngFilePath, @"photo",
                                        [[area firstChild]content], @"area",
                                        [[bio firstChild]content], @"bio",
                                        nil];
            
            [newList setObject:dictFriend forKey:[NSString stringWithFormat:@"%i", i]];
        }
        
        NSError *error;
        NSData* jsonData = [NSJSONSerialization dataWithJSONObject:newList
                                                           options:NSJSONWritingPrettyPrinted
                                                             error:&error];
        
        NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES); //1
        NSString *documentsDirectory = [paths objectAtIndex:0]; //2
        NSString *path = [documentsDirectory stringByAppendingPathComponent:@"data.json"]; //3

        
        if (_firstTime ==YES) {
            
            NSLog(@"IN");
            _myFriendsOnDict = newList;
            
            [jsonData writeToFile: path atomically:YES];
            [self downloadPhotos: photosList];
            
            NSLog(@"It's first time");

        }else{
            
            NSError* error;
            NSDictionary *oldVersion = [[NSDictionary alloc]init];
            NSData *json=[NSData dataWithContentsOfFile:path];
            oldVersion = [NSJSONSerialization JSONObjectWithData:json //1
                                                        options:kNilOptions
                                                          error:&error];
            
            if (oldVersion.count != newList.count) {                 //borrar lista vieja y meter el nuevo.
                _myFriendsOnDict = newList;
                [newList writeToFile:path atomically:YES];
                [self downloadPhotos: photosList];
                
                NSLog(@"Second time and different, number of friends change");


            }else{
                
                for (int i =0; i<newList.count; i++) {
                    if (![[[newList objectForKey:[NSString stringWithFormat:@"%i", i]]objectForKey:@"name"] isEqualToString:
                        [[oldVersion objectForKey:[NSString stringWithFormat:@"%i", i]]objectForKey:@"name"]] ) {
                     
                        _myFriendsOnDict = newList;
                        [newList writeToFile:path atomically:YES];
                        
                        NSLog(@"Second time and different, same number, someone is new");
                        
                        break;
                        
                    }
                }//end FOR
                NSLog(@"Same list");
            }
            
        }
        
        //saltamos a la cola principal
        dispatch_async(dispatch_get_main_queue(), ^{

            [_friendTable reloadData];
        
            NSLog(@"Data done");
        
        });
        
    });

}

- (void)downloadPhotos: (NSMutableArray *)photosList{
    
    for (NSDictionary *photoOfOne in photosList){
        
        NSData *dataPhoto = [NSData dataWithContentsOfURL:[photoOfOne objectForKey:@"url"]];
        NSFileManager *fileManager = [NSFileManager defaultManager];
        
        if (![fileManager fileExistsAtPath: [photoOfOne objectForKey:@"path"]]){
            
            [dataPhoto writeToFile:[photoOfOne objectForKey:@"path"] atomically:YES];
        }
    }
    
    [_friendTable reloadData];
    
    NSLog(@"Photos done");

}


#pragma mark - Table View

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _myFriendsOnDict.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    static NSString *CellIdentifier = @"Cell";

    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier];
        cell.imageView.layer.cornerRadius = 21;
        cell.imageView.layer.masksToBounds = YES;
        cell.imageView.layer.borderWidth = 0.1;
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    }
    
    NSData *img = [NSData dataWithContentsOfFile:[[_myFriendsOnDict objectForKey:[NSString stringWithFormat:@"%li", (long)indexPath.row]]objectForKey:@"photo"]];

    cell.imageView.image = [UIImage imageWithData:img];
    cell.textLabel.text = [[_myFriendsOnDict objectForKey:[NSString stringWithFormat:@"%li", (long)indexPath.row]]objectForKey:@"name"];
    
    return cell;
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the specified item to be editable.
    return YES;
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    ADDFriendDetailsViewController *friendDetails = [self.storyboard instantiateViewControllerWithIdentifier:@"Details"];
    NSData *img = [NSData dataWithContentsOfFile:[[_myFriendsOnDict objectForKey:[NSString stringWithFormat:@"%li", (long)indexPath.row]]objectForKey:@"photo"]];
    
    friendDetails.photo = img;
    friendDetails.name = [[_myFriendsOnDict objectForKey:[NSString stringWithFormat:@"%i", indexPath.row]]objectForKey:@"name"];;
    friendDetails.bio = [[_myFriendsOnDict objectForKey:[NSString stringWithFormat:@"%i", indexPath.row]]objectForKey:@"bio"];
    friendDetails.areaG = [[_myFriendsOnDict objectForKey:[NSString stringWithFormat:@"%i", indexPath.row]]objectForKey:@"area"];
    
    [self.navigationController pushViewController:friendDetails animated:YES];
}

@end
