//
//  ADDViewController.h
//  Whoiswho V2 with json and storing images
//
//  Created by Alejandro Delgado Diaz on 10/12/13.
//  Copyright (c) 2013 Alejandro Delgado Diaz. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ADDFriendDetailsViewController;

@interface ADDViewController : UIViewController <UITableViewDelegate>

@property NSDictionary *myFriendsOnDict;

@property (weak, nonatomic) IBOutlet UITableView *friendTable;

-(IBAction)refreshFriends:(id)sender;

@end
