//
//  ADDFriendDetailsViewController.m
//  Whoiswho V2 with json and storing images
//
//  Created by Alejandro Delgado Diaz on 11/12/13.
//  Copyright (c) 2013 Alejandro Delgado Diaz. All rights reserved.
//

#import <QuartzCore/QuartzCore.h>
#import "ADDFriendDetailsViewController.h"

@interface ADDFriendDetailsViewController ()

@end

@implementation ADDFriendDetailsViewController


- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];

    NSLog(@"%@", _name);
    
    [_imagenView setImage:[UIImage imageWithData:_photo]];
    _imagenView.layer.cornerRadius = 65;
    _imagenView.layer.masksToBounds = YES;
    [_nameLabel setText:_name];
    [_area setText:_areaG];
    [_bioText setText:_bio];
    
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
