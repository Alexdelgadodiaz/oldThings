//
//  ADDFriendDetailsViewController.h
//  Whoiswho V2 with json and storing images
//
//  Created by Alejandro Delgado Diaz on 11/12/13.
//  Copyright (c) 2013 Alejandro Delgado Diaz. All rights reserved.
//

#import <UIKit/UIKit.h>
//#import "FutureFriend.h"

@interface ADDFriendDetailsViewController : UIViewController

@property (weak, nonatomic) IBOutlet UIImageView *imagenView;
@property (weak, nonatomic) IBOutlet UILabel *nameLabel;
@property (weak, nonatomic) IBOutlet UILabel *area;
@property (weak, nonatomic) IBOutlet UITextView *bioText;

//@property (nonatomic, retain) FutureFriend *friend;
@property (nonatomic, retain) NSData *photo;
@property (nonatomic, retain) NSString *name;
@property (nonatomic, retain) NSString *bio;
@property (nonatomic, retain) NSString *areaG;

@end
